'use strict';

jQuery(function ($) {

    var $window = $(window),
        $body = $('body'),
        screenWidth = $window.width(),
        screenHeight = $window.height(),
        scrollBarWidth = 0;

    $window.on('resize orientationchange', function () {
        screenWidth = $window.width();
        screenHeight = $window.height();
    });

    $window.on('load', function () {
        $window.resize();
    });

    window.fly = {
        init: function () {
            this.resizedEvent(400); // Trigger Event after Window is Resized
            this.ieWarning(); // IE<9 Warning
            this.disableEmptyLinks(); // Disable Empty Links
            this.toolTips(); // ToolTips Init
            this.placeHolders(); // PlaceHolders Init
            this.checkBoxes(); // Styled CheckBoxes, RadioButtons
            this.scrollToAnchors(); // Smooth Scroll to Anchors
            this.scrollBarWidthDetection(); // ScrollBar Width Detection
            this.videoPlayerRatio(); // Video Player Ratio
            this.fullHeight(); // Set full window height to the Blocks
            this.dropDownMenu(); // Dropdown Menu in Header
            this.stickyMenu(); // Sticky Menu
            this.stickySideBar(); // Sticky SideBar
            this.mainCarousel(); // Main Carousel
            this.flySlider(); // Fly Slider
            this.lastItemLabel('.post-meta'); // Post Meta First Item
            this.parallaxInit(); // Parallax
            this.headerSearchForm(); // Search Form in Header
            this.portfolioInit(); // Portfolio Filtering
            this.postListMasonry(); // PostList Masonry Layout
            this.galleryInit(); // Gallery shortcode init
            this.lightBox(); // LightBox (swipeBox)
            this.owlSlidersInit(); // Owl Carousels
            this.skillsCounter(); // Skills Animation
            this.headerVideo(); // Video in Header
            this.thumbnailSlider(); // Thumbnail Slider in Portfolio Details
            this.linkActionDelay(); // Delays Link Actions for Mobile Devices
			this.selectsInit(); // Select2
        },

        resizedEvent: function (delay) {
            var resizeTimerId;

            $window.on('resize orientationchange', function () {
                clearTimeout(resizeTimerId);

                resizeTimerId = setTimeout(function () {
                    $window.trigger('resized');
                }, delay);
            });
        },

        ieWarning: function () {
            if ($('html').hasClass('oldie')) {
                $body.empty().html('Please, Update your Browser to at least IE9');
            }
        },

        disableEmptyLinks: function () {
            $('[href="#"], .btn.disabled').on('click', function (event) {
                event.preventDefault();
            });
        },

        toolTips: function () {
            $('[data-toggle="tooltip"]').tooltip();
        },

        placeHolders: function () {
            if ($('[placeholder]').length) {
                $.Placeholder.init();
            }
        },

        checkBoxes: function () {
            $.fn.customInput = function () {
                $(this).each(function () {
                    var container = $(this),
                        input = container.find('input'),
                        label = container.find('label');

                    input.on('update', function () {
                        input.is(':checked') ? label.addClass('checked') : label.removeClass('checked');
                    })
                        .trigger('update')
                        .on('click', function () {
                            $('input[name=' + input.attr('name') + ']').trigger('update');
                        });
                });
            };

            $('.checkbox, .radio').customInput();
        },

        scrollToAnchors: function () {
            //$('a[href*="#"]').on('click', function (e) {
            $('a[href*="#"]').each(function () {
                $(this).click(function (e) {
                    e.preventDefault();
                    var thisPath = filterPath(this.pathname) || locationPath;
                    if (locationPath == thisPath
                        && (location.hostname == this.hostname || !this.hostname)
                        && this.hash.replace(/#/, '')) {
                        var $target = $(this.hash), target = this.hash;

                    } else {
                        var target = $(this).attr('href');
                    }

                    var speed = 1,
                        boost = 1,
                        offset = 110,
                        currPos = parseInt($window.scrollTop(), 10),
                        targetPos = target != "#" && $(target).length == 1 ? parseInt($(target).offset().top, 10) - offset : currPos,
                        distance = targetPos - currPos;

                    boost = Math.abs(distance * boost / 1000);

                    $("html, body").animate({scrollTop: targetPos}, parseInt(Math.abs(distance / (speed + boost)), 10));
                });
            });
        },

        scrollBarWidthDetection: function () {
            $body.append('<div class="scrollbar-detect"><span></span></div>');

            var scrollBarDetect = $('.scrollbar-detect');

            scrollBarWidth = scrollBarDetect.width() - scrollBarDetect.find('span').width();

            scrollBarDetect.remove();
        },

        videoPlayerRatio: function () {
            function setRatio() {
                $('.video-player').each(function () {
                    var self = $(this),
                        ratio = self.attr('width') && self.attr('height') ? self.attr('width') / self.attr('height') : 16 / 9,
                        videoWidth = self.width();

                    self.css({height: parseInt(videoWidth / ratio)});

                    self.trigger('videoPlayerRatioSet');
                });
            }

            setRatio();

            $window.on('resized', function () {
                setRatio();
            });
        },

        fullHeight: function () {
            var blocks = $('.full-height');

            $window.on('resized', function () {
                blocks.css({
                    height: screenHeight
                });
            });
        },

        dropDownMenu: function () {
            var navContainer = $('.nav-menu'),
                navItems = navContainer.find('li'),
                animationIn = 'growIn',
                animationOut = 'growOut',
                breakPoint = 767;

            $window.on('load', function () {
                navContainer.removeClass('invisible');
                navContainer.addClass('loaded');
            });

            navContainer.find('ul').addClass('hidden');
            navItems.has('ul').addClass('parent');
            navItems.children('a').addClass('menu-link');

            navItems.hover(function () {
                if (screenWidth > breakPoint) {
                    var self = $(this),
                        dropdown = self.children('ul');

                    if (dropdown.length) {
                        dropdown.removeClass('hidden');

                        // Move Dropdown (Level 2+) to the left side of its Parent if it doesn't fit to screen
                        var dropdownWidth = dropdown.outerWidth(),
                            dropdownOffset = parseInt(dropdown.offset().left, 10);

                        if (dropdownWidth + dropdownOffset > screenWidth - 5) {
                            dropdown.addClass('left');
                        }
                        /////////////////////////////////////////////////////////////////

                        if (Modernizr.cssanimations) {
                            dropdown.addClass(animationIn + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                                dropdown.removeClass(animationIn + ' animated hidden');
                                dropdown.off('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend');
                            });
                        }
                    }
                }
            }, function () {
                if (screenWidth > breakPoint) {
                    var self = $(this),
                        dropdown = self.children('ul');

                    if (Modernizr.cssanimations) {
                        dropdown.removeClass(animationIn + ' animated hidden').addClass(animationOut + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
                            dropdown.removeClass(animationOut + ' animated').addClass('hidden');
                            dropdown.off('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend');
                        });
                    } else {
                        dropdown.addClass('hidden');
                    }
                }
            });

            // Dropdown Menu for Mobiles
            var menuButton = $('.hamburger').find('a'),
                isAnimating = false;

            menuButton.on('click', function () {
                if (isAnimating) return;

                isAnimating = true;

                if (navContainer.hasClass('active')) {
                    menuButton.parent().removeClass('active');
                    navContainer.removeClass('active');
                    $body.removeClass('overflow-hidden');

                    if (Modernizr.csstransitions && screenWidth < breakPoint + 1) {
                        navContainer.one('webkitTransitionEnd mozTransitionEnd MSTransitionEnd otransitionend transitionend', function () {
                            isAnimating = false;
                            navContainer.off('webkitTransitionEnd mozTransitionEnd MSTransitionEnd otransitionend transitionend');

                            navContainer.css({
                                height: 'auto'
                            });
                        });
                    } else {
                        isAnimating = false;

                        navContainer.css({
                            height: 'auto'
                        });
                    }

                } else {
                    menuButton.parent().addClass('active');
                    navContainer.addClass('active');
                    $body.addClass('overflow-hidden');

                    navContainer.css({
                        height: screenHeight - navContainer.parent().outerHeight()
                    });

                    $window.on('resized', function () {
                        navContainer.css({
                            height: screenHeight - navContainer.parent().outerHeight()
                        });
                    });

                    if (Modernizr.csstransitions && screenWidth < breakPoint + 1) {
                        navContainer.one('webkitTransitionEnd mozTransitionEnd MSTransitionEnd otransitionend transitionend', function () {
                            isAnimating = false;
                            navContainer.off('webkitTransitionEnd mozTransitionEnd MSTransitionEnd otransitionend transitionend');
                        });
                    } else {
                        isAnimating = false;
                    }
                }
            });

            navContainer.find('a.menu-link').on('click', function (event) {
                if (screenWidth < breakPoint + 1) {
                    var self = $(this),
                        menuItem = self.parent('li'),
                        dropdown = self.siblings('ul');

					if (menuItem.hasClass('parent')) {
						event.preventDefault();
					}

                    if (menuItem.hasClass('active')) {
                        dropdown.addClass('hidden');
                        menuItem.removeClass('active');
                    } else {
                        dropdown.removeClass('hidden');
                        menuItem.addClass('active');
                    }
                }
            });

            $window.on('resized', function () {
                if (screenWidth > breakPoint) {
                    navItems.removeClass('active');
                    navItems.find('ul').addClass('hidden');
                    $body.removeClass('overflow-hidden');

                    setTimeout(function () {
                        navContainer.css({
                            height: 'auto'
                        });
                    }, 0);
                }
            });
        },

        stickyMenu: function () {
            $.fn.stickyMenu = function () {
                var stickyMenu = $(this),
                    stickyHeight = stickyMenu.outerHeight(true),
                    becomeSticky = stickyMenu.data('become-sticky'),
                    stickyOffset = stickyMenu.offset().top,
                    scrollTop = $window.scrollTop(),
                    placeholder = $('<div/>'),
                    isPlaceholder = stickyMenu.is('[data-no-placeholder]') ? false : true;

                $window.on('load', function () {
                    stickyHeight = stickyMenu.outerHeight(true);
                });

                function runStickyMenu() {
                    scrollTop = $window.scrollTop();

                    if (isPlaceholder) {
                        placeholder.css({
                            height: stickyHeight
                        });
                    }

                    if (scrollTop > stickyHeight + stickyOffset) {
                        stickyMenu.addClass('sticky');
                        if (isPlaceholder) placeholder.insertAfter(stickyMenu);
                    } else {
                        stickyMenu.removeClass('sticky');
                        if (isPlaceholder) placeholder.detach();
                    }

                    if (scrollTop > stickyHeight + stickyOffset + becomeSticky) {
                        stickyMenu.addClass('sticky-moved');
                    } else {
                        stickyMenu.removeClass('sticky-moved');
                    }
                }

                $window.on('load scroll resized', function () {
                    runStickyMenu();
                });
            };

            $('[data-become-sticky]').each(function () {
                $(this).stickyMenu();
            });
        },

        stickySideBar: function () {
            $('.sidebar-sticky').each(function () {
                var sidebar = $(this);

                if ($window.width() > 767 - scrollBarWidth) {
                    sidebar.stick_in_parent();
                }

                $window.on('resized', function () {
                    if ($window.width() > 767 - scrollBarWidth) {
                        sidebar.stick_in_parent();
                    } else {
                        sidebar.trigger('sticky_kit:detach');
                    }
                });
            });
        },

        mainCarousel: function () {
            var mainCarouselContainer = $('.main-carousel'),
                mainCarousel = mainCarouselContainer.find('ul'),
                prev = mainCarouselContainer.find('.prev'),
                next = mainCarouselContainer.find('.next'),
                interval = mainCarouselContainer.data('interval') ? mainCarouselContainer.data('interval') : 10000;

            mainCarousel.find('.carousel-item').removeClass('current');
            mainCarousel.find('.carousel-item').eq(1).addClass('current');

            function mainCarouselInit() {
                if (!mainCarousel.length) return;

                mainCarousel.carouFredSel({
                    width: '100%',
                    prev: prev,
                    next: next,
                    swipe: {
                        onTouch: true
                    },
                    items: {
                        visible: 3
                    },
                    auto: {
                        play: true,
                        timeoutDuration: interval
                    },
                    scroll: {
                        pauseOnHover: true,
                        items: 1,
                        duration: 500,
                        easing: 'swing',
                        onBefore: function (data) {
                            data.items.old.removeClass('current');
                            data.items.visible.eq(1).addClass('current');
                        }
                    }
                });
            }

            mainCarouselInit();

            $window.on('load', function () {
                mainCarouselContainer.removeClass('hidden');

                setTimeout(function () {
                    mainCarouselInit();
                }, 1000);
            });

            $window.on('resized', function () {
                mainCarouselInit();
            });

            mainCarousel.swipe({
                excludedElements: '',
                swipeLeft: function () {
                    next.trigger('click');
                },
                swipeRight: function () {
                    prev.trigger('click');
                },
                threshold: 80
            });
        },

        flySlider: function () {
            var IE = false;

            if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > 0) {
                IE = true;
            }

            var flySlider = $('.fly-slider'),
                cube = flySlider.find('.cube'),
                slides = flySlider.find('.slide'),
                slidesContent = flySlider.find('.slide-content'),
                slidesContentRotationDelay = 0,
                slidesQt = slides.length,
                sliderControls = flySlider.find('.slider-control'),
                rotationCounter = 0,
                slideOffset = 50 / Math.tan(Math.PI / slidesQt),
                rotationDuration = flySlider.data('rotation-duration') ? flySlider.data('rotation-duration') : 1000,
                autoInterval = flySlider.data('rotation-interval') ? flySlider.data('rotation-interval') : 10000,
                autoRotationInterval,
                isAnimating = false,
                isFrozen = false;

            $window.on('resize', function () {
                cube.css({
                    height: screenHeight
                });
            });

            if (slidesQt < 2) {
                sliderControls.addClass('hidden');
                flySlider.removeClass('invisible');
                slides.addClass('active');

                return;
            }

            flySlider.addClass('slides' + slidesQt);

            slidesContent.css({
                transition: 'transform ' + (rotationDuration / 1000 + slidesContentRotationDelay) + 's ease'
            });

            $window.on('resize', function () {
                if (!IE) {
                    slides.each(function (index) {
                        $(this).css({
                            transform: 'rotate3d(1, 0, 0, ' + (index * 360 / slidesQt) + 'deg) translate3d(0, 0, ' + parseInt(slideOffset * screenHeight / 100) + 'px)',
                            transition: 'all ' + rotationDuration / 1000 + 's ease'
                        });
                    });

                    cube.css({
                        transition: 'all ' + rotationDuration / 1000 + 's ease' // 'transition: all' - needed for IOS
                    });
                } else {
                    slides.css({
                        transformOrigin: '50% 50% -' + parseInt(slideOffset * screenHeight / 100) + 'px',
                        transition: 'all ' + rotationDuration / 1000 + 's ease'
                    });
                }
            });

            function rotateCube(count) {
                var counter = count % slidesQt;

                flySlider.trigger('fly.transition.start');

                if (!IE) {
                    cube.css({
                        transform: 'translate3d(0,0, -' + parseInt(slideOffset * screenHeight / 100) + 'px) rotate3d(1, 0, 0, ' + (-count * 360 / slidesQt) + 'deg)'
                    });
                } else {
                    slides.each(function (index) {
                        $(this).css({
                            transform: 'rotate3d(1, 0, 0, ' + (index - count) * (360 / slidesQt) + 'deg)'
                        });
                    });
                }

                slides.removeClass('active prev next').eq(counter).addClass('active');
                slides.eq(counter - 1).addClass('prev');

                if (counter + 1 === slidesQt) {
                    slides.eq(0).addClass('next');
                } else {
                    slides.eq(counter + 1).addClass('next');
                }

                setTimeout(function () {
                    isAnimating = false;

                    flySlider.trigger('fly.transition.end');
                }, rotationDuration);
            }

            rotateCube(rotationCounter);

            setTimeout(function () {
                flySlider.removeClass('invisible');
            }, rotationDuration);

            //Click Event
            sliderControls.on('click', function () {
                if (isAnimating) return;

                clearInterval(autoRotationInterval);
                setAutoRotationInterval();

                isAnimating = true;

                if ($(this).hasClass('prev')) {
                    rotationCounter--;
                } else {
                    rotationCounter++;
                }

                rotateCube(rotationCounter);
            });

            //KeyDown Event
            if (flySlider.length) {
                $window.on('keydown', function (event) {
                    if (isAnimating) return;

                    clearInterval(autoRotationInterval);
                    setAutoRotationInterval();

                    isAnimating = true;

                    if (event.keyCode === 37) {
                        rotationCounter--;
                    } else if (event.keyCode === 39) {
                        rotationCounter++;
                    }

                    rotateCube(rotationCounter);
                });
            }

            //Swipe Event
            flySlider.swipe({
                swipeStatus: function (event, phase, direction, distance, duration, fingers) {
                    if (isAnimating) return;

                    if (direction === 'left' && distance > 100) {
                        clearInterval(autoRotationInterval);
                        setAutoRotationInterval();

                        isAnimating = true;

                        rotationCounter--;

                        rotateCube(rotationCounter);
                    }

                    if (direction === 'right' && distance > 100) {
                        clearInterval(autoRotationInterval);
                        setAutoRotationInterval();

                        isAnimating = true;

                        rotationCounter++;

                        rotateCube(rotationCounter);
                    }
                },
                fingers: 'all'
            });

            //AutoAdvance
            $window.on('blur', function () {
                isFrozen = true;
            });

            $window.on('focus', function () {
                isFrozen = false;
            });

            function setAutoRotationInterval() {
                autoRotationInterval = setInterval(function () {
                    if (isFrozen) return;

                    isAnimating = true;

                    rotationCounter++;

                    rotateCube(rotationCounter);
                }, autoInterval);
            }

            setAutoRotationInterval();
        },

        lastItemLabel: function (selector) {
            $(selector).each(function () {
                $(this).children().eq(-1).addClass('last');
            });
        },

        parallaxInit: function () {
            $.fn.parallax = function () {
                var parallax = $(this),
                    xPos = parallax.data('parallax-position') ? parallax.data('parallax-position') : 'center',
                    speed = parallax.data('parallax-speed') || parallax.data('parallax-speed') == 0 ? parallax.data('parallax-speed') : .1;

                function runParallax() {
                    var scrollTop = $window.scrollTop(),
                        offsetTop = parallax.offset().top,
                        parallaxHeight = parallax.outerHeight();

                    if (scrollTop + screenHeight > offsetTop && offsetTop + parallaxHeight > scrollTop) {
                        var yPos = parseInt((offsetTop - scrollTop) * speed, 10);

                        parallax.css({
                            backgroundPosition: xPos + ' ' + yPos + 'px'
                        });
                    }
                }

                if (screenWidth > 1000 && !parallax.hasClass('parallax-disabled')) {
                    parallax.css({
                        backgroundAttachment: 'fixed'
                    });
                    runParallax();
                }
                $window.on('scroll', function () {
                    if (screenWidth > 1000 && !parallax.hasClass('parallax-disabled')) {
                        parallax.css({
                            backgroundAttachment: 'fixed'
                        });
                        runParallax();
                    }
                });
                $window.on('resized', function () {
                    if (screenWidth > 1000 && !parallax.hasClass('parallax-disabled')) {
                        parallax.css({
                            backgroundAttachment: 'fixed'
                        });
                        runParallax();
                    } else {
                        parallax.css({
                            backgroundPosition: '50% 0',
                            backgroundAttachment: 'scroll'
                        });
                    }
                });
            };

            $('.parallax').each(function () {
                $(this).parallax();
            });
        },

        headerSearchForm: function () {
            var form = $('.form-search-header'),
                formButton = $('.form-search-open');

            formButton.on('click', function () {
                form.toggleClass('active');
            });

            $body.on('click', function (event) {
                var element = $(event.target);

                if (!element.hasClass('form-search-header') && !element.hasClass('form-search-open') && !element.closest('.form-search-header').length) {
                    form.removeClass('active');
                }
            });

            $window.on('keydown', function (event) {
                if (event.keyCode === 27) {
                    form.removeClass('active');
                }
            });
        },

        portfolioInit: function () {
            var portfolio = $('.portfolio-items'),
                portfolioItems = portfolio.children('.portfolio-item'),
                filters = $('.masonry-filter.portfolio-filter li'),
                gridSize = 10000,
                gridSizeIndex = 0,
                gridSizeItem,
                ratio = portfolio.data('ratio') ? portfolio.data('ratio').split('/') : [4, 3];

            ratio = ratio[1] / ratio[0];

            if (!portfolio.length) return false;

            portfolioItems.each(function (index) {
                if ($(this).outerWidth() < gridSize) {
                    gridSize = $(this).outerWidth();
                    gridSizeIndex = index;
                }
            });

            gridSizeItem = portfolioItems.eq(gridSizeIndex);
            gridSizeItem.addClass('grid-sizer');

            $window.on('resized', function () {
                gridSize = gridSizeItem.outerWidth();

                portfolioItems.each(function () {
                    var self = $(this);

                    self.css({height: gridSize * ratio});

                    if (self.hasClass('height2')) {
                        self.css({height: gridSize * ratio * 2});
                    }

                    if (self.hasClass('height3')) {
                        self.css({height: gridSize * ratio * 3});
                    }

                    if (self.hasClass('height4')) {
                        self.css({height: gridSize * ratio * 4});
                    }

                    if (self.hasClass('height5')) {
                        self.css({height: gridSize * ratio * 5});
                    }
                });

                portfolio.isotope('layout');
            });

            portfolio.isotope({
                layoutMode: 'packery',
                transitionDuration: '1s',
                getSortData: {
                    category: '[data-category]'
                },
                packery: {
                    columnWidth: '.grid-sizer'
                },
                percentPosition: true
            });

            portfolio.imagesLoaded().progress(function () {
                portfolio.isotope('layout');
            });

            filters.on('click', function (e) {
                e.preventDefault();

                var self = $(this),
                    option = self.data('category');

                filters.removeClass('active');
                self.addClass('active');

                var search = option ? function () {
                    var $item = $(this),
                        name = $item.data('category') ? $item.data('category') : '';
                    return name.match(new RegExp(option));
                } : '*';

                portfolio.isotope({filter: search});
            });
        },

        postListMasonry: function () {
            var postlist = $('.postlist-masonry');

            if (!postlist.length) return false;

            postlist.find('.article').eq(0).addClass('grid-sizer');

            postlist.isotope({
                itemSelector: '.article',
                masonry: {
                    columnWidth: '.grid-sizer'
                }
            });

            postlist.imagesLoaded().progress(function () {
                postlist.isotope('layout');
            });

            $('.video-player').on('videoPlayerRatioSet', function () {
                postlist.isotope('layout');
            });

            $window.on('resized', function () {
                postlist.isotope('layout');
            });
        },

        galleryInit: function () {
            var gallery = $('.fly-gallery-items'),
                galleryItems = gallery.children('.fly-gallery-item'),
                filters = $('.fly-gallery-filter li'),
                gridSize = 10000,
                gridSizeIndex = 0,
                gridSizeItem;

            if (!gallery.length) return false;

            galleryItems.each(function (index) {
                if ($(this).outerWidth() < gridSize) {
                    gridSize = $(this).outerWidth();
                    gridSizeIndex = index;
                }
            });

            gridSizeItem = galleryItems.eq(gridSizeIndex);
            gridSizeItem.addClass('grid-sizer');

            $window.on('resize', function () {
                gridSize = gridSizeItem.outerWidth();

                galleryItems.each(function () {
                    var self = $(this);

                    self.css({height: gridSize});

                    if (self.hasClass('height2')) {
                        self.css({height: gridSize * 2});
                    }

                    if (self.hasClass('height3')) {
                        self.css({height: gridSize * 3});
                    }

                    if (self.hasClass('height4')) {
                        self.css({height: gridSize * 4});
                    }

                    if (self.hasClass('height5')) {
                        self.css({height: gridSize * 5});
                    }
                });

                gallery.isotope('layout');
            });

            gallery.isotope({
                layoutMode: 'packery',
                transitionDuration: '1s',
                getSortData: {
                    category: '[data-category]'
                },
                packery: {
                    columnWidth: '.grid-sizer'
                },
                percentPosition: true
            });

            gallery.imagesLoaded().progress(function () {
                gallery.isotope('layout');
            });

            filters.on('click', function (e) {
                e.preventDefault();

                var self = $(this),
                    option = self.data('category');

                filters.removeClass('active');
                self.addClass('active');

                var search = option ? function () {
                    var $item = $(this),
                        name = $item.data('category') ? $item.data('category') : '';
                    return name.match(new RegExp(option));
                } : '*';

                gallery.isotope({filter: search});
            });
        },

        lightBox: function () {
            $('.swipebox, .swipebox-video').swipebox({
                removeBarsOnMobile: false,
                autoplayVideos: true
            });
        },

        owlSlidersInit: function () {
            // Slider on Gallery Post Type
            $('.post-slider').owlCarousel({
                singleItem: true,
                navigation: true,
                navigationText: ['', ''],
                pagination: true
            });

            // Related Posts Slider
            $('.related-posts-slider').owlCarousel({
                items: 3,
                itemsDesktop: [1359, 3],
                itemsDesktopSmall: [1229, 2],
                itemsTablet: [767, 2],
                itemsMobile: [479, 1],
                navigation: false,
                navigationText: false,
                pagination: false
            });

            // Related Posts Slider
            $('.related-posts-slider2').owlCarousel({
                items: 4,
                itemsDesktop: [1359, 4],
                itemsDesktopSmall: [1229, 3],
                itemsTablet: [767, 2],
                itemsMobile: [479, 1],
                navigation: true,
                navigationText: false,
                pagination: false
            });

            // Instagram Slider
            $('.instagram-slider').owlCarousel({
                items: 9,
                itemsDesktop: [1599, 7],
                itemsDesktopSmall: [1229, 6],
                itemsTablet: [991, 5],
                itemsMobile: [767, 3],
                navigation: false,
                navigationText: false,
                pagination: false
            });

            // Twitter Slider
            $('.twitter-slider').owlCarousel({
                singleItem: true,
                navigation: true,
                navigationText: ['', ''],
                pagination: false
            });
        },

        skillsCounter: function () {
            $('.skill').each(function () {
                var self = $(this),
                    percent = self.data('percentage'),
                    percentage = self.find('.skill-percentage'),
                    progress = self.find('.progress-bar'),
                    progressAnimated = false;

                percentage.text('0%');
                progress.css({width: 0 + '%'});

                $window.on('scroll', function () {
                    if (progressAnimated) return;

                    if (self.offset().top < $window.scrollTop() + screenHeight) {
                        progressAnimated = true;

                        for (var i = 1; i < 21; i++) {
                            var timeOuted = function (i) {
                                return setTimeout(function () {
                                    percentage.text(parseInt(percent * i / 20) + '%');
                                    progress.css({width: percent * i / 20 + '%'});
                                }, i * 200);
                            };

                            timeOuted(i);
                        }
                    }
                });
            });
        },

        headerVideo: function () {
            function resizeVideo() {
                $('.video-container').each(function () {
                    var container = $(this),
                        video = container.find('.video'),
                        ratio = video.attr('width') / video.attr('height'),
                        containerWidth = container.width(),
                        containerHeight = container.height();

                    if (containerWidth / containerHeight < ratio) {
                        video.css({
                            width: containerHeight * ratio,
                            height: containerHeight
                        });

                        var videoWidth = video.width();

                        video.css({
                            marginLeft: (containerWidth - videoWidth) / 2
                        });
                    } else {
                        video.css({
                            width: containerWidth,
                            height: containerWidth / ratio,
                            marginLeft: 0
                        });
                    }
                });
            }

            $window.on('resized', function () {
                resizeVideo();
            });

            $('.fly-slider').on('fly.transition.end', function () {
                resizeVideo();
            });
        },

        thumbnailSlider: function () {
            $.fn.imageSliderApi = function () {
                var slider = $(this),
                    imagesWrap = slider.find('.slider-images-wrap'),
                    images = slider.find('.slider-images'),
                    thumbsWrap = slider.find('.slider-thumbs-wrap'),
                    thumbs = slider.find('.slider-thumbs'),
                    prev = slider.find('.prev'),
                    next = slider.find('.next'),
                    description = images.find('.description'),
                    descriptionOpen = slider.find('.description-open'),
                    sliderHeight = slider.data('height') ? slider.data('height') : 400;

                if (screenWidth < 1024) {
                    sliderHeight = sliderHeight / 1.4;
                }

                if (screenWidth < 480) {
                    sliderHeight = sliderHeight / 1.6;
                }

                images.trigger('destroy');
                thumbs.trigger('destroy');

                images.find('li').removeClass().css({
                    width: imagesWrap.width(),
                    height: sliderHeight
                });

                thumbsWrap.css({
                    height: sliderHeight + 2
                });

                thumbs.find('li').removeClass().css({
                    width: thumbsWrap.width(),
                    height: (sliderHeight + 2) / 3 - 2
                });

                images.carouFredSel({
                    prev: prev,
                    next: next,
                    circular: false,
                    infinite: false,
                    items: 1,
                    auto: false,
                    scroll: {
                        fx: 'quadratic',
                        onBefore: function () {
                            var pos = $(this).triggerHandler('currentPosition');

                            thumbs.find('li').removeClass('active');
                            thumbs.find('li.item' + pos).addClass('active');

                            if (pos < 1) {
                                thumbs.trigger('slideTo', [pos, true]);
                            } else {
                                thumbs.trigger('slideTo', [pos - 1, true]);
                            }
                        }
                    },
                    onCreate: function () {
                        images.find('li').each(function (i) {
                            $(this).addClass('item' + i);
                        });
                    }
                }).trigger('slideTo', [0, true]);

                thumbs.carouFredSel({
                    direction: 'up',
                    auto: false,
                    infinite: false,
                    circular: false,
                    scroll: {
                        items: 1
                    },
                    onCreate: function () {
                        thumbs.find('li').each(function (i) {
                            $(this).addClass('item' + i).on('click', function () {
                                images.trigger('slideTo', [i, true]);
                            });
                        });
                        thumbs.find('.item0').addClass('active');
                    }
                });

                images.swipe({
                    swipeLeft: function () {
                        images.trigger('next');
                    },
                    swipeRight: function () {
                        images.trigger('prev');
                    },
                    threshold: 30,
                    excludedElements: ''
                });

                description.find('.description-close').on('click', function () {
                    description.removeClass('active');
                    descriptionOpen.addClass('active');
                });

                descriptionOpen.on('click', function () {
                    description.addClass('active');
                    descriptionOpen.removeClass('active');
                });
            };

            var imageSlider = $('.thumbnail-slider');

            if (imageSlider.length) {
                $window.on('load resized', function () {
                    imageSlider.each(function () {
                        $(this).imageSliderApi();
                    });
                });
            }
        },

        linkActionDelay: function () {
            if (Modernizr.touchevents) {
                var delayedLinks = $('.js-action-delay');

                if (!delayedLinks.length) return false;

                var delayTimerId;

                $body.on('click', function (event) {
                    var element = $(event.target);

                    if (!element.hasClass('js-action-delay') && !element.closest('.js-action-delay').length) {
                        clearTimeout(delayTimerId);
                        delayedLinks.removeClass('active');
                    }
                });

                delayedLinks.on('click', function (event) {
                    event.preventDefault();
                    clearTimeout(delayTimerId);

                    var self = $(this),
                        path = self.attr('href');

                    delayedLinks.removeClass('active');

                    self.addClass('active');

                    delayTimerId = setTimeout(function () {
                        window.location.href = path;

                    }, 4000);
                });
            }
        },

		selectsInit : function() {
			$('.select2, .fly-form-contact .select-field').select2({
				minimumResultsForSearch: Infinity
			});
		}
    };

    fly.init();
});

jQuery(document).ready(function () {
    // like to a post
    jQuery('.fly-love-it').on('click', function () {
        if (jQuery(this).hasClass('fly_loved')) {
            return false;
        }

        jQuery(this).addClass('fly_loved');
        var id = jQuery(this).attr('data-id');
        var datasend = 'action=flyfood_like_post_action&id=' + id;
        jQuery.ajax({
            type: "POST",
            url: FlyPhpVars.ajax_url,
            data: datasend, // data to be send
            dataType: "html"
        });
        return false;
    });
});

// Smooth Scroling of ID anchors
function filterPath(string) {
	return string
		.replace(/^\//, '')
		.replace(/(index|default).[a-zA-Z]{3,4}$/, '')
		.replace(/\/$/, '');
}

var locationPath = filterPath(location.pathname);

var $ = jQuery;

/**
 * Forms
 */
jQuery(function ($) {
	"use strict";
	var formErrorMessageClass = 'form-error',
		formErrorHideEventNamespace = '.form-error-hide',
		errorTemplate = '<p class="' + formErrorMessageClass + '" style="color: red;">{message}</p>'; // todo: customize this (add class="" instead of style="")

	function showFormError($form, inputName, message) {
		var inputSelector = '[name="' + inputName + '"]',
			$input = $form.find(inputSelector).last(),
			$message = $(errorTemplate.replace('{message}', message));

		if ($input.length) {
			$input.parent().after($message);

			$form.one('focusout' + formErrorHideEventNamespace, inputSelector, function () {
				$message.slideUp(function () {
					$(this).remove();
				});
			});
		} else {
			// if input not found, show message in form
			$form.prepend($message);
		}
	}

	function themeGenerateFlashMessagesHtml(types) {
		var html = [], typeHtml = [];

		$.each(types, function (type, messages) {
			typeHtml = [];

			$.each(messages, function (messageId, messageData) {
				/*typeHtml.push(messageData.message);*/
				typeHtml.push(messageData);
			});

			if (typeHtml.length) {
				html.push(
					'<ul class="flash-messages-' + type + '">' +
					'    <li>' + typeHtml.join('</li><li>') + '</li>' +
					'</ul>'
				);
			}
		});

		if (html.length) {
			return html.join('');
		} else {
			return '<p>Success</p>';
		}
	}

	/**
	 * Display FW_Form errors
	 */
	do {
		if (typeof _fw_form_invalid == 'undefined') {
			break;
		}

		var $form = $('form.fw_form_' + _fw_form_invalid.id).first();

		if (!$form.length) {
			console.error('Form not found on the page');
			break;
		}

		$.each(_fw_form_invalid.errors, function (inputName, message) {
			showFormError($form, inputName, message);
		});
	} while (false);

	/**
	 * Ajax submit
	 */
	{
		$(document.body).on('submit', 'form[data-fw-ext-forms-type="contact-forms"]', function (e) {
			e.preventDefault();

			var $form = $(this);

			// todo: show loading
			jQuery.ajax({
				type: "POST",
				url: FlyPhpVars.ajax_url,
				data: $(this).serialize(),
				dataType: 'json'
			}).done(function (r) {
				if (r.success) {
					// prevent multiple submit
					$form.on('submit', function (e) {
						e.preventDefault();
						e.stopPropagation();
					});

					$form.html(
						themeGenerateFlashMessagesHtml(r.data.flash_messages)
					);

					// if form has a redirect page, redirect the form to this URL
					var redirect_page = $form.parents('.fw-contact-form').data('redirect-page');
					// if has a success message & a not empty redirect page
					if( r.data.flash_messages.success.fw_ext_contact_form_process != undefined && redirect_page != '' ) {
						window.location.href = redirect_page;
					}
				} else {
					// hide all current error messages
					$form.off(formErrorHideEventNamespace)
						.find('.' + formErrorMessageClass).remove();

					// add new error messages
					$.each(r.data.errors, function (inputName, message) {
						showFormError($form, inputName, message);
					});
				}
			}).fail(function () {
				// show fail error message
				$form.html(FlyPhpVars.fail_form_error);
				// todo: show server error
			});
		});
	}
});

