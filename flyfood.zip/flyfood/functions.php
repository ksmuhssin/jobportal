<?php

/**
 * Include Theme Includes
 */
require_once get_template_directory() . '/theme-includes/init.php';


require_once get_template_directory() . '/theme-includes/tgm-activation/class-tgm-plugin-activation.php';


