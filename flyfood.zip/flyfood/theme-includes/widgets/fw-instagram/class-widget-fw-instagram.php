<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class flyfood_Widget_FW_Instagram extends WP_Widget {

	function __construct() {
		$widget_ops = array( 'description' => esc_html__( 'Instagram widget', 'flyfood' ) );
		parent::__construct( false, esc_html__( 'Fly Instagram', 'flyfood' ), $widget_ops );
	}

	function widget( $args, $instance ) {
		extract( $args );
		$params = array();

		foreach ( $instance as $key => $value ) {
			$params[ $key ] = $value;
		}

		$before_widget = '<div class="widget widget-sidebar widget-instagram">';
		$after_widget  = '</div>';

		$title = '<h4 class="widget-title"><span>' . $params['title'] . '</span></h4>';
		unset( $params['title'] );

		$filepath = get_template_directory() . '/theme-includes/widgets/fw-instagram/views/widget.php';

		$data = array(
			'instance'      => $params,
			'title'         => $title,
			'before_widget' => $before_widget,
			'after_widget'  => $after_widget,
		);

		echo fw_render_view( $filepath, $data );
	}

	function update( $new_instance, $old_instance ) {
		return $new_instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title'         => '',
			'user'          => '',
			'number'        => '',
			'follow_button' => '',
		) );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'flyfood' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
				   value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'user' ) ); ?>"><?php esc_html_e( 'Username:', 'flyfood' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'user' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'user' ) ); ?>" type="text"
				   value="<?php echo esc_attr( $instance['user'] ); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of images:', 'flyfood' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text"
				   value="<?php echo esc_attr( $instance['number'] ); ?>"/>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'follow_button' ) ); ?>"><?php esc_html_e( 'Follow button title:', 'flyfood' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'follow_button' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'follow_button' ) ); ?>" type="text"
				   value="<?php echo esc_attr( $instance['follow_button'] ); ?>"/>
		</p>
		<?php
	}
}