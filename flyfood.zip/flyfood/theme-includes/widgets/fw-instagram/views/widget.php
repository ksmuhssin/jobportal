<?php
/**
 * @var $instance
 * @var $before_widget
 * @var $after_widget
 * @var $title
 */

if ( ! empty( $instance ) ) :
	$instagram_photos = flyfood_get_instagram_photos( $instance['user'], $instance['number'] );
	echo( $before_widget );
	echo( $title );

	if ( ! empty( $instagram_photos ) && ! isset( $instagram_photos->errors ) ) : ?>
		<div class="fly-instagram-wrap">
			<ul>
				<?php foreach ( $instagram_photos as $image ) : ?>
					<li><a target="_blank" href="https://www.instagram.com/p/<?php echo esc_attr( $image['code'] ); ?>/"><img
									src="<?php echo esc_url( $image['link'] ); ?>" alt=""/></a></li>
				<?php endforeach; ?>
			</ul>
			<?php if ( $instance['follow_button'] != '' ) : ?>
				<div class="fly-btn-instagram">
					<a class="btn btn-small" target="_blank"
					   href="https://www.instagram.com/p/<?php echo $image['code']; ?>/"><?php echo( $instance['follow_button'] ); ?></a>
				</div>
			<?php endif; ?>
		</div>
		<div class="clearfix"></div>
	<?php else :
		esc_html_e( 'Please check the widget data', 'flyfood' );
	endif;

	echo( $after_widget );
endif;