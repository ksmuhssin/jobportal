<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Filters and Actions
 */

if ( ! function_exists( 'flyfood_action_theme_setup' ) ) :
	/**
	 * Theme setup.
	 *
	 * Set up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support post thumbnails.
	 * @internal
	 */
	function flyfood_action_theme_setup() {
		/*
		 * Make Theme available for translation.
		 */
		load_theme_textdomain( 'flyfood', get_template_directory() . '/languages' );

		// Add RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption'
		) );

		// Add support for featured content.
		add_theme_support( 'featured-content', array(
			'featured_content_filter' => 'flyfood_theme_get_featured_posts',
			'max_posts'               => 6,
		) );

		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );

		add_theme_support( 'post-thumbnails', array( 'post', 'fw-portfolio', 'product' ) );

		add_theme_support( "title-tag" );

		// Theme support woocommerce plugin
		add_theme_support('woocommerce');

		add_theme_support( 'wc-product-gallery-lightbox' );

		// Add favicon
		add_theme_support('favicon');
	}
endif;
add_action( 'after_setup_theme', 'flyfood_action_theme_setup' );


if ( ! function_exists( 'flyfood_action_add_editor_styles' ) ) :
	/**
	 * Apply theme's stylesheet to the visual editor.
	 *
	 * @uses add_editor_style() Links a stylesheet to visual editor
	 * @uses get_stylesheet_uri() Returns URI of theme stylesheet
	 */
	function flyfood_action_add_editor_styles() {
		add_editor_style( get_stylesheet_uri() );
	}
	add_action( 'init', 'flyfood_action_add_editor_styles' );
endif;


/**
 * Adjust content_width value for image attachment template.
 * @internal
 */
function flyfood_action_theme_content_width() {
	if ( is_attachment() && wp_attachment_is_image() ) {
		$GLOBALS['content_width'] = 810;

		if ( ! isset( $content_width ) ) {
			$content_width = 810;
		}
	}
}
add_action( 'template_redirect', 'flyfood_action_theme_content_width' );


if ( ! function_exists( 'flyfood_theme_action_functions' ) ) :
	function flyfood_theme_action_functions() {
		the_post_thumbnail();
	}
endif;


/**
 * Extend the default WordPress post classes.
 *
 * Adds a post class to denote:
 * Non-password protected page with a post thumbnail.
 *
 * @param array $classes A list of existing post class values.
 *
 * @return array The filtered post class list.
 * @internal
 */
function flyfood_filter_theme_post_classes( $classes ) {
	if ( ! post_password_required() && ! is_attachment() && has_post_thumbnail() ) {
		$classes[] = 'has-post-thumbnail';
	}

	return $classes;
}

add_filter( 'post_class', 'flyfood_filter_theme_post_classes' );


/**
 * Create a nicely formatted and more specific title element text for output
 * in head of document, based on current view.
 *
 * @param string $title Default title text for current view.
 * @param string $sep Optional separator.
 *
 * @return string The filtered title.
 * @internal
 */
function flyfood_filter_theme_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() ) {
		return $title;
	}

	// Add the site name.
	$title .= get_bloginfo( 'name', 'display' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title = "$title $sep $site_description";
	}

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 ) {
		$title = "$title $sep " . sprintf( esc_html__( 'Page %s', 'flyfood' ), max( $paged, $page ) );
	}

	return $title;
}

add_filter( 'wp_title', 'flyfood_filter_theme_wp_title', 10, 2 );


/**
 * remove sidebars for portfolio taxonomy
 */
function flyfood_filter_remove_taxonomy_from_sidebars( $taxonomy_list ) {
	unset( $taxonomy_list['fw-portfolio-category'] );

	return $taxonomy_list;
}

add_filter( 'fw_ext_sidebars_taxonomies', 'flyfood_filter_remove_taxonomy_from_sidebars' );


function flyfood_filter_remove_post_type_from_sidebars( $post_types_list ) {
	//unset($post_types_list['fw-portfolio']);
	return $post_types_list;
}

add_filter( 'fw_ext_sidebars_post_types', 'flyfood_filter_remove_post_type_from_sidebars' );


function flyfood_filter_add_span_cat_count( $links ) {
	$links = str_replace( '</a> (', '<span>(', $links );
	$links = str_replace( ')', ')</span></a>', $links );

	return $links;
}

add_filter( 'wp_list_categories', 'flyfood_filter_add_span_cat_count' );


if ( ! function_exists( 'flyfood_filter_archive_link' ) ) :
	function flyfood_filter_archive_link( $url ) {
		$url = str_replace( '</a>&nbsp;(', '<span>(', $url );
		$url = str_replace( ')</li>', ')</span></a></li>', $url );

		return $url;
	}
endif;
add_filter( 'get_archives_link', 'flyfood_filter_archive_link', 99 );


if ( ! function_exists( 'flyfood_action_theme_count_post_visits' ) ) :
	/**
	 * Count posts visits
	 */
	function flyfood_action_theme_count_post_visits() {
		if ( ! is_single() ) {
			return;
		}
		global $post;
		$views = get_post_meta( $post->ID, 'fly_post_views', true );
		$views = intval( $views );
		update_post_meta( $post->ID, 'fly_post_views', ++ $views );
	}
endif;
add_action( 'wp_head', 'flyfood_action_theme_count_post_visits' );


if ( ! function_exists( 'flyfood_like_post' ) ) :
	/**
	 * Set like to a post
	 */
	function flyfood_like_post() {
		// todo: de vazut de ce nu merge aici pina la capat cu cookie
		if ( isset( $_POST['id'] ) ) {
			$id = $_POST['id'];
		} else {
			return;
		}

		$count = get_post_meta( $id, 'fly_post_likes', true );
		$count = intval( $count );
		$count ++;

		$loves = array();
		if ( isset( $_COOKIE['fly_post_likes'] ) ) {
			$loves = explode( ";", $_COOKIE['fly_post_likes'] );

			if ( ! in_array( $id, $loves ) ) {
				$loves[] = $id;
				update_post_meta( $id, 'fly_post_likes', $count );
			}
		} else {
			$loves[] = $id;
			update_post_meta( $id, 'fly_post_likes', $count );
		}

		$result  = setcookie( 'fly_post_likes', implode( ";", $loves ), time() + 3600 * 24 * 60, '/' );
		$success = false;
		if ( $result ) {
			$success = true;
		}

		$response = array( 'success' => $success, 'fly_post_likes' => $count );
		$response = json_encode( $response );
		echo( $response );
		die();
	}

	add_action( "wp_ajax_flyfood_like_post_action", "flyfood_like_post" );
	add_action( "wp_ajax_nopriv_flyfood_like_post_action", "flyfood_like_post" );
endif;


if ( ! function_exists( 'flyfood_action_theme_footer_widgets_init' ) ) :
	/**
	 * Register widget areas
	 * @internal
	 */
	function flyfood_action_theme_footer_widgets_init() {
		register_sidebar( array(
			'name'          => esc_html__( 'General Widget', 'flyfood' ),
			'id'            => 'sidebar-1',
			'description'   => '',
			'before_widget' => '<div id="%1$s" class="widget-sidebar widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title"><span>',
			'after_title'   => '</span></h4>',
		) );
	}
endif;
add_action( 'widgets_init', 'flyfood_action_theme_footer_widgets_init' );


if ( ! function_exists( 'flyfood_filter_active_slider' ) ) :
	/**
	 * Filter for disable framework sliders
	 *
	 * @param array $sliders
	 */
	function flyfood_filter_active_slider( $sliders ) {
		$sliders = array_diff( $sliders, array( 'nivo-slider', 'bx-slider', 'owl-carousel' ) );

		return $sliders;
	}

	add_filter( 'fw_ext_slider_activated', 'flyfood_filter_active_slider' );
endif;


function flyfood_filter_theme_change_submenu_class( $menu ) {
	$menu = preg_replace( '/ class="sub-menu"/', ' class="child" ', $menu );

	return $menu;
}

add_filter( 'wp_nav_menu', 'flyfood_filter_theme_change_submenu_class' );


if ( ! function_exists( 'flyfood_action_print_fonts' ) ) :
	/**
	 * print theme general fonts
	 */
	function flyfood_action_print_fonts() {
		if ( defined( 'FW' ) ) {
			$styling = '';
			$font1   = fw_get_db_settings_option( 'font1' );
			$font2   = fw_get_db_settings_option( 'font2' );
			$font3   = fw_get_db_settings_option( 'font3' );
			$font4   = fw_get_db_settings_option( 'font4' );
			$font5   = fw_get_db_settings_option( 'font5' );
			$h1_font = fw_get_db_settings_option( 'h1_font' );
			$h2_font = fw_get_db_settings_option( 'h2_font' );
			$h3_font = fw_get_db_settings_option( 'h3_font' );
			$h4_font = fw_get_db_settings_option( 'h4_font' );
			$h5_font = fw_get_db_settings_option( 'h5_font' );
			$h6_font = fw_get_db_settings_option( 'h6_font' );

			// get font 1
			if ( isset( $font1['font1'] ) && $font1['font1'] == 'yes' ) {
				$font1   = flyfood_get_shortcode_advanced_styles( $font1['yes']['general_font_family'] );
				$styling .= 'body, .nav-menu li a.menu-link {' . $font1 . '}' . "\n";
			}

			// get font 2
			if ( isset( $font2['font2'] ) && $font2['font2'] == 'yes' ) {
				$font2   = flyfood_get_shortcode_advanced_styles( $font2['yes']['general_font_family'] );
				$styling .= '.form-group label, .form-login .checkbox, .form-login .submit, .tab-header a, .panel-title, .related-posts .title, .post-category, .project-info .item > strong, .comments .title, .comment-author, .widget-sidebar .widget-title, .fly-accordion .widget-title, .widget_categories a, .widget_calendar table, #swipebox-top-bar, .comment-reply-title, .widget_pages a, .widget_nav_menu a, .widget_meta a, .widget_archive a, .widget_recent_entries a {' . $font2 . '}' . "\n";
			}

			// get font 3
			if ( isset( $font3['font3'] ) && $font3['font3'] == 'yes' ) {
				$font3   = flyfood_get_shortcode_advanced_styles( $font3['yes']['general_font_family'] );
				$styling .= 'h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6, .page-title, .btn, .wpcf7-submit, .comment-form #submit, .thumbnail-slider .description .title, .post-media blockquote, .widget-posts .article .post-title, .post-taglist a, .widget_tag_cloud a, .widget-author .name, .widget-sidebar .mc4wp-form input[type="submit"], .section .title, .widget_search .search-submit, .post-password-form input[type="submit"] {' . $font3 . '}' . "\n";
			}

			// get font 4
			if ( isset( $font4['font4'] ) && $font4['font4'] == 'yes' ) {
				$font4   = flyfood_get_shortcode_advanced_styles( $font4['yes']['general_font_family'] );
				$styling .= '.post-meta.font2, .blockquote, .post-content blockquote, .comment-date, .widget-author .job, .section-author .job, .author-job {' . $font4 . '}' . "\n";
			}

			// get font 5
			if ( isset( $font5['font5'] ) && $font5['font5'] == 'yes' ) {
				$font5   = flyfood_get_shortcode_advanced_styles( $font5['yes']['general_font_family'] );
				$styling .= 'a.post-read-more, a.comment-reply, .section-author .link, a.comment-reply-link, .fly-basic-information .link {' . $font5 . '}' . "\n";
			}

			// get h1 font
			if ( isset( $h1_font['h1_font'] ) && $h1_font['h1_font'] == 'yes' ) {
				$h1_style = flyfood_get_shortcode_advanced_styles( $h1_font['yes']['h1_font'] );
				$styling  .= 'h1, .h1 {' . $h1_style . '}' . "\n";

				// responsive h1 styling
				$responsive_h1_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h1_font['yes']['h1_font'],
				                                                                   'selector' => 'h1, .h1'
				) );
				if ( ! empty( $responsive_h1_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h1_styling . '}';
				}
			}
			// get h2 font
			if ( isset( $h2_font['h2_font'] ) && $h2_font['h2_font'] == 'yes' ) {
				$h2_style = flyfood_get_shortcode_advanced_styles( $h2_font['yes']['h2_font'] );
				$styling  .= 'h2, .h2 {' . $h2_style . '}' . "\n";
				// responsive h2 styling
				$responsive_h2_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h2_font['yes']['h2_font'],
				                                                                   'selector' => 'h2, .h2'
				) );
				if ( ! empty( $responsive_h2_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h2_styling . '}';
				}
			}
			// get h3 font
			if ( isset( $h3_font['h3_font'] ) && $h3_font['h3_font'] == 'yes' ) {
				$h3_style = flyfood_get_shortcode_advanced_styles( $h3_font['yes']['h3_font'] );
				$styling  .= 'h3, .h3 {' . $h3_style . '}' . "\n";
				// responsive h3 styling
				$responsive_h3_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h3_font['yes']['h3_font'],
				                                                                   'selector' => 'h3, .h3'
				) );
				if ( ! empty( $responsive_h3_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h3_styling . '}';
				}
			}
			// get h4 font
			if ( isset( $h4_font['h4_font'] ) && $h4_font['h4_font'] == 'yes' ) {
				$h4_style = flyfood_get_shortcode_advanced_styles( $h4_font['yes']['h4_font'] );
				$styling  .= 'h4, .h4 {' . $h4_style . '}' . "\n";
				// responsive h4 styling
				$responsive_h4_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h4_font['yes']['h4_font'],
				                                                                   'selector' => 'h4, .h4'
				) );
				if ( ! empty( $responsive_h4_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h4_styling . '}';
				}
			}
			// get h5 font
			if ( isset( $h5_font['h5_font'] ) && $h5_font['h5_font'] == 'yes' ) {
				$h5_style = flyfood_get_shortcode_advanced_styles( $h5_font['yes']['h5_font'] );
				$styling  .= 'h5, .h5 {' . $h5_style . '}' . "\n";
				// responsive h5 styling
				$responsive_h5_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h5_font['yes']['h5_font'],
				                                                                   'selector' => 'h5, .h5'
				) );
				if ( ! empty( $responsive_h5_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h5_styling . '}';
				}
			}
			// get h6 font
			if ( isset( $h6_font['h6_font'] ) && $h6_font['h6_font'] == 'yes' ) {
				$h6_style = flyfood_get_shortcode_advanced_styles( $h6_font['yes']['h6_font'] );
				$styling  .= 'h6, .h6 {' . $h6_style . '}' . "\n";
				// responsive h6 styling
				$responsive_h6_styling = flyfood_responsive_heading_styles( array( 'styles'   => $h6_font['yes']['h6_font'],
				                                                                   'selector' => 'h6, .h6'
				) );
				if ( ! empty( $responsive_h6_styling ) ) {
					$styling .= '@media(max-width:767px){' . $responsive_h6_styling . '}';
				}
			}

			// include after parent style if is child theme active
			$file_style = is_child_theme() ? 'parent-style' : 'style';
			if ( ! empty( $styling ) ) {
				wp_add_inline_style( $file_style, $styling );
			}
		}
	}
endif;
add_action( 'wp_enqueue_scripts', 'flyfood_action_print_fonts', 998 );


if ( ! function_exists( 'flyfood_action_theme_print_google_fonts_link' ) ) :
	/**
	 * Print google fonts link
	 */
	function flyfood_action_theme_print_google_fonts_link() {
		global $flyfood_google_fonts_list_general;

		$flyfood_google_fonts_list = array(
			'Open Sans'       => array(
				'variation' => array(
					'300'       => '300',
					'300italic' => '300italic',
					'400'       => '400',
					'400italic' => '400italic',
					'600'       => '700',
					'600italic' => '600italic',
					'700'       => '700',
					'700italic' => '700italic',
				),
				'subset'    => array(
					'latin' => 'latin'
				),
			),
			'Montserrat'      => array(
				'variation' => array(
					'400' => '400',
					'700' => '700',
				),
				'subset'    => array(
					'latin' => 'latin'
				),
			),
			'Muli'            => array(
				'variation' => array(
					'300'       => '300',
					'300italic' => '300italic',
					'400'       => '400',
					'400italic' => '400italic',
				),
				'subset'    => array(
					'latin' => 'latin'
				),
			),
			'Roboto Slab' => array(
				'variation' => array(
					'100' => '100',
					'300' => '300',
					'400' => '400',
					'700' => '700',
				),
				'subset'    => array(
					'latin' => 'latin'
				),
			),
			'Cookie'          => array(
				'variation' => array(
					'400' => '400',
				),
				'subset'    => array(
					'latin' => 'latin'
				),
			),
		);

		// merge recursive with general google fonts
		$flyfood_google_fonts_list = flyfood_theme_array_merge_recursive( $flyfood_google_fonts_list, $flyfood_google_fonts_list_general );

		wp_register_style( 'google-fonts', flyfood_theme_get_remote_fonts( $flyfood_google_fonts_list ) );
		wp_enqueue_style( 'google-fonts' );
	}
endif;
add_action( 'wp_enqueue_scripts', 'flyfood_action_theme_print_google_fonts_link', 999 );


function flyfood_filter_mime_types( $mimes ) {
	$mimes['svg'] = 'image/svg+xml';

	return $mimes;
}

add_filter( 'upload_mimes', 'flyfood_filter_mime_types' );


function flyfood_change_site_color() {
	if ( ! defined( 'FW' ) ) {
		return;
	}

	$color   = fw_get_db_settings_option( 'site_color', '' );
	$color_2 = fw_get_db_settings_option( 'color_2', '' );
	$css     = '';

	// color from get parameter
	if ( isset( $_GET['color'] ) ) {
		$color = '#' . strip_tags( $_GET['color'] );
	}

	if ( ! empty( $color ) ) {
		// color
		$css .= 'a,
a:focus,
.color-brown,
.link-brown,
.nav-menu li:hover > a.menu-link,
.nav-menu li:active > a.menu-link,
.nav-menu li.active > a.menu-link,
.nav-menu li.current-menu-item > a.menu-link,
.nav-menu li ul li:hover > a.menu-link,
.nav-menu li ul li:active > a.menu-link,
nav-menu > li:hover > a.menu-link,
.nav-menu > li:active > a.menu-link,
.nav-menu > li.active > a.menu-link,
.nav-menu > li.current-menu-item > a.menu-link,
.nav-menu li.current-menu-item > a.menu-link,
.navigation-wrapper .nav-menu > li:hover > a.menu-link,
.navigation-wrapper .nav-menu > li:active > a.menu-link,
.navigation-wrapper .nav-menu > li.active > a.menu-link,
.navigation-wrapper .nav-menu > li.current-menu-item > a.menu-link,
.sticky.navigation-wrapper .nav-menu > li:hover > a.menu-link,
.sticky.navigation-wrapper .nav-menu > li:active > a.menu-link,
.sticky.navigation-wrapper .nav-menu > li.active > a.menu-link,
.sticky.navigation-wrapper .nav-menu > li.current-menu-item > a.menu-link,
.pagination > li > a:hover,
.pagination > li > span:hover,
.pagination > li > a:focus,
.pagination > li > span:focus,
.pagination > li > a:active,
.pagination > li > span:active,
.pagination > li.active > a,
.pagination > li.active > span,
.pagination > li.active > a:hover,
.pagination > li.active > span:hover,
.pagination > li.active > a:focus,
.pagination > li.active > span:focus,
.pagination > li.active > a:active,
.pagination > li.active > span:active,
.pager a:hover,
.pager a:active,
a.panel-toggle,
a.panel-toggle:focus,
a.panel-toggle.collapsed:hover,
a.panel-toggle.collapsed:active,
.thumbnail-slider .prev:hover,
.thumbnail-slider .next:hover,
.thumbnail-slider .prev:active,
.thumbnail-slider .next:active,
.thumbnail-slider .description-open:hover,
.thumbnail-slider .description-open:active,
.thumbnail-slider .description-close,
.post-category:before,
.post-category:after,
a.post-read-more,
.post-social a:hover,
.post-social a:active,
.comment-author:hover,
.comment-author:active,
.widget_categories a:hover,
.widget_categories a:active,
#swipebox-prev:hover,
#swipebox-next:hover,
#swipebox-close:hover,
#swipebox-prev:active,
#swipebox-next:active,
#swipebox-close:active,
.post-social a.fly_loved ,
.widget_pages a:hover,
.widget_pages a:active,
.widget_nav_menu a:hover,
.widget_nav_menu a:active,
.widget_meta a:hover,
.widget_meta a:active,
.widget_archive a:hover,
.widget_archive a:active,
.widget_recent_comments a:hover,
.widget_recent_comments a:active,
.widget_recent_entries a:hover,
.widget_recent_entries a:active,
.widget_recent_comments a,
.fly-tabs-container .client-logo .fly-tab-title,
.fly-header-image .post-category,
.fly-slider .post-category,
.main-carousel .post-category
{color: ' . $color . ';}';

		// border color
		$css .= '
.post-slider .owl-controls .owl-page:hover span,
.post-slider .owl-controls .owl-page:active span,
.post-slider .owl-controls .owl-page.active span,
.post-taglist a:hover,
.post-taglist a:active,
.widget-sidebar .widget-title span,
.fly-accordion .widget-title span,
.widget_tag_cloud a:hover,
.widget_tag_cloud a:active,
#swipebox-prev:hover,
#swipebox-next:hover,
#swipebox-close:hover,
#swipebox-prev:active,
#swipebox-next:active,
#swipebox-close:active,
.fly-team-member .avatar
{ border-color: ' . $color . '; }';

		// border left color
		$css .= '
.blockquote,
.post-content blockquote
{ border-left-color: ' . $color . '; }';

		// border bottom color
		$css .= '
.back-to-top:after,
nav-menu > li:hover > a.menu-link,
.nav-menu > li:active > a.menu-link,
.nav-menu > li.active > a.menu-link,
.nav-menu > li.current-menu-item > a.menu-link,
.nav-menu > li:hover > a.menu-link
{ border-bottom-color: ' . $color . ';}';

		// background color
		$css .= '
.back-to-top,
.hamburger.active a:before,
.hamburger.active a:after,
a.panel-toggle:before,
a.panel-toggle:after,
.post-slider .owl-controls .owl-page.active span,
.post-label,
a.post-read-more:before,
a.post-read-more:after,
.post-taglist a:hover,
.post-taglist a:active,
.portfolio-filter a:before,
.widget_tag_cloud a:hover,
.widget_tag_cloud a:active,
.widget_calendar table #today:before,
.widget-skills .skill .progress-bar,
#swipebox-top-bar,
.related-posts-slider2 .owl-controls .owl-buttons .owl-prev:before,
.related-posts-slider2 .owl-controls .owl-buttons .owl-next:before,
.related-posts-slider2 .owl-controls .owl-buttons .owl-prev:hover:before,
.related-posts-slider2 .owl-controls .owl-buttons .owl-next:hover:before,
.related-posts-slider2 .owl-controls .owl-buttons .owl-prev:active:before,
.related-posts-slider2 .owl-controls .owl-buttons .owl-next:active:before,
.main-carousel .prev:hover i, .main-carousel .next:hover i,
.main-carousel .prev:active i, .main-carousel .next:active i,
.owl-carousel .owl-controls .owl-buttons .owl-prev:hover:before,
.owl-carousel .owl-controls .owl-buttons .owl-next:hover:before,
.owl-carousel .owl-controls .owl-buttons .owl-prev:active:before,
.owl-carousel .owl-controls .owl-buttons .owl-next:active:before,
.fly-slider .slider-control:hover i,
.fly-slider .slider-control:active i
{ background-color: ' . $color . '; }';

		$css .= '::-moz-selection{ background-color: ' . $color . '; }';
		$css .= '::selection{ background-color: ' . $color . '; }';
	}

	if ( ! empty( $color_2 ) ) {
		$css .= '
h1 a:hover,
h2 a:hover,
h3 a:hover,
h4 a:hover,
h5 a:hover,
h6 a:hover,
.h1 a:hover,
.h2 a:hover,
.h3 a:hover,
.h4 a:hover,
.h5 a:hover,
.h6 a:hover,
h1 a:active,
h2 a:active,
h3 a:active,
h4 a:active,
h5 a:active,
h6 a:active,
.h1 a:active,
.h2 a:active,
.h3 a:active,
.h4 a:active,
.h5 a:active,
.h6 a:active,
a:hover,
a:active,
.color-red,
.link-red,
.link-red:hover,
.link-brown:hover,
.link-red:active,
.link-brown:active,
.footer-social li a:hover,
.footer-social li a:active,
.footer-copyright a:hover,
.footer-copyright a:active,
.form-group.required label:after,
.form-search .form-control:focus + .submit:hover,
.form-search .form-control:focus + .submit:active,
.form-login .submit:hover,
.form-login .submit:active,
.top-menu li a:hover,
.top-menu li a:active,
.top-menu .social:hover .social-toggle,
.top-menu .social:active .social-toggle,
.post-meta.font2 a:hover,
.post-meta.font2 a:active,
.post-meta.font2 .post-author a:hover,
.post-meta.font2 .post-author a:active,
.widget-posts .article .post-title a:hover,
.widget-posts .article .post-title a:active,
.portfolio .item-link .item-description span,
.widget_categories li.active a,
.widget_calendar table tfoot tr td#prev a:hover,
.widget_calendar table tfoot tr td#next a:hover,
.widget_calendar table tfoot tr td#prev a:active,
.widget_calendar table tfoot tr td#next a:active,
.fly-tabs-container .nav-text > li > a:hover .fly-tab-title,
.fly-tabs-container .active .client-logo .fly-tab-title,
.fly-tabs-container .active .client-logo,
.article.content-blog > a[rel="tag"]:hover,
.article.content-blog > a[rel="tag"]:active
{ color: ' . $color_2 . '; }';

		$css .= '
.back-to-top:hover,
.back-to-top:active
{ background-color: ' . $color_2 . '; }';

		$css .= '
.back-to-top:hover:after,
.back-to-top:active:after
{ border-bottom-color: ' . $color_2 . '; }';
	}

	if ( ! empty( $css ) ) {
		$file_style = is_child_theme() ? 'parent-style' : 'style';
		wp_add_inline_style( $file_style, $css );
	}
}

add_filter( 'wp_enqueue_scripts', 'flyfood_change_site_color', 99 );


if ( ! function_exists( 'flyfood_action_tracking_script' ) ) {
	/**
	 * Display theme tracking script
	 */
	function flyfood_action_tracking_script() {
		$tracking_script = function_exists( 'fw_get_db_settings_option' ) ? fw_get_db_settings_option( 'tracking_script', '' ) : '';
		if ( ! empty( $tracking_script ) ) {
			flyfood_theme_print( $tracking_script );
		}
	}
}
add_action( 'wp_footer', 'flyfood_action_tracking_script' );


function flyfood_add_custom_css() {
	if ( ! defined( 'FW' ) ) {
		return;
	}

	$css = fw_get_db_settings_option( 'quick_css' );

	if ( ! empty( $css ) ) {
		wp_add_inline_style( 'style', $css );
	}
}
add_filter( 'wp_enqueue_scripts', 'flyfood_add_custom_css', 99 );


if ( ! function_exists( 'flyfood_action_save_fw_portfolio_post' ) ) :
	/**
	 * Set post terms to portfolio on save
	 */
	function flyfood_action_save_fw_portfolio_post() {
		$post_id = @$_POST['post_ID'];
		if ( ! flyfood_is_real_post_save( $post_id ) ) {
			return;
			die();
		}
		$taxonomy = 'fw-portfolio-category';
		$terms    = wp_get_post_terms( $post_id, $taxonomy );

		$parrents_ids = array();
		foreach ( $terms as $term ) {
			if ( $term->parent != 0 ) {
				if ( ! in_array( $term->parent, $parrents_ids ) ) {
					$parrents_ids[] = $term->parent;
				}
			}
		}

		foreach ( $parrents_ids as $term_id ) {
			wp_set_post_terms( $post_id, $term_id, $taxonomy, true );
		}
	}
endif;
add_action( 'save_post_fw-portfolio', 'flyfood_action_save_fw_portfolio_post' );


/**
 * @param FW_Ext_Backups_Demo[] $demos
 *
 * @return FW_Ext_Backups_Demo[]
 */
function flyfood_filter_fw_ext_backups_demos( $demos ) {
	$demos_array = array(
		'flyfood' => array(
			'title'        => esc_html__( 'FlyFood', 'flyfood' ),
			'screenshot'   => '//flytemplates.com/demo-themes/images/flyfood.png',
			'preview_link' => '//demo.flytemplates.com/flyfood/',
		),
		'flydesign' => array(
			'title'        => esc_html__( 'FlyDesign', 'flyfood' ),
			'screenshot'   => '//flytemplates.com/demo-themes/images/flydesign.png',
			'preview_link' => '//demo.flytemplates.com/flydesign/',
		),
	);

	foreach ( $demos_array as $id => $data ) {
		$demo = new FW_Ext_Backups_Demo( $id, 'piecemeal', array(
			'url'     => 'https://flytemplates.com/demo-themes/',
			'file_id' => $id,
		) );
		$demo->set_title( $data['title'] );
		$demo->set_screenshot( $data['screenshot'] );
		$demo->set_preview_link( $data['preview_link'] );

		$demos[ $demo->get_id() ] = $demo;

		unset( $demo );
	}

	return $demos;
}

add_filter( 'fw:ext:backups-demo:demos', 'flyfood_filter_fw_ext_backups_demos' );


if ( ! function_exists( 'flyfood_filter_excerpt_length' ) ) :
	/**
	 * Set the theme excerpt length
	 */
	function flyfood_filter_excerpt_length( $length ) {
		return 30;
	}
endif;
add_filter( 'excerpt_length', 'flyfood_filter_excerpt_length', 999 );


if ( ! function_exists( 'flyfood_filter_special_navigation_class' ) ):
	/**
	 * @$classes array of classes for special menu elements
	 *
	 * @param array $classes
	 * @param object $item
	 */
	function flyfood_filter_special_navigation_class( $classes, $item ) {
		if ( $item->type == 'custom' && strpos( $item->url, "#" ) !== false && strlen( $item->url ) > 1 ) {
			$classes[] = 'anchor';
		}

		return $classes;
	}

	add_filter( 'nav_menu_css_class', 'flyfood_filter_special_navigation_class', 10, 2 );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_button_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_button_enqueue_dynamic_css( $data ) {
		$shortcode = 'button';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['type']['selected'] == 'btn-fill' ) {
			// bg color for fill button
			if ( ! empty( $atts['type']['btn-fill']['bg_color'] ) ) {
				$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':before, .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':after, .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover, .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':focus{ background-color: ' . $atts['type']['btn-fill']['bg_color'] . ';}';

				$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . '{ border: none; }';
			}
		} elseif ( $atts['type']['selected'] == 'btn-transparent' ) {
			// border color
			if ( ! empty( $atts['label_color'] ) ) {
				$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ' { border-color: ' . $atts['label_color'] . ';}';
			}
			// border hover color
			if ( ! empty( $atts['bg_hover_color'] ) ) {
				$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover { border-color: ' . $atts['bg_hover_color'] . ';}';
			}
		}

		// label color
		if ( ! empty( $atts['label_color'] ) ) {
			$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ', .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover, .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':focus { color: ' . $atts['label_color'] . ';}';
		}

		// label hover color
		if ( ! empty( $atts['label_hover_color'] ) ) {
			$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover { color: ' . $atts['label_hover_color'] . ';}';
		}

		// bg hover color
		if ( ! empty( $atts['bg_hover_color'] ) ) {
			$final_styles .= '.btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover, .btn.' . $atts['type']['selected'] . '.sh-' . $atts['unique_id'] . ':hover:after { background-color: ' . $atts['bg_hover_color'] . ';}';
		}

		// label styling
		if ( $atts['label_styling']['selected'] == 'yes' ) {
			// label styling
			$label_styling = flyfood_get_shortcode_advanced_styles( $atts['label_styling']['yes']['font'] );
			if ( ! empty( $label_styling ) ) {
				$final_styles .= '.btn.' . $atts['type']['selected'] . '.' . $atts['size'] . '.sh-' . $atts['unique_id'] . '{' . $label_styling . '}';
			}

			// responsive label styling
			$responsive_label_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['label_styling']['yes']['font'],
			                                                                      'selector' => '.btn.' . $atts['type']['selected'] . '.' . $atts['size'] . '.sh-' . $atts['unique_id']
			) );
			if ( ! empty( $responsive_label_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_label_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:button', 'flyfood_action_shortcode_button_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_section_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_section_enqueue_dynamic_css( $data ) {
		$shortcode = 'section';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';

		// full width
		if ( $atts['is_fullwidth']['selected'] == 'yes' ) {
			$container_class = '.container-fluid';
		} else {
			$container_class = '.container';
		}

		// border
		if ( isset( $atts['border']['selected'] ) && $atts['border']['selected'] == 'yes' ) {
			$final_styles .= '.section.sh-' . $atts['unique_id'] . ' ' . $container_class . '{ border-width: ' . (int) $atts['border']['yes']['width'] . 'px; border-color: ' . $atts['border']['yes']['color'] . '; border-style: solid; padding: 40px 30px;}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:section', 'flyfood_action_shortcode_section_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_divider_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_divider_enqueue_dynamic_css( $data ) {
		$shortcode = 'divider';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		// color
		if ( ! empty( $atts['color'] ) ) {
			$final_styles .= '.separator.sh-' . $atts['unique_id'] . ' { color: ' . $atts['color'] . ';}';
			$final_styles .= '.separator.sh-' . $atts['unique_id'] . ':before, .separator.sh-' . $atts['unique_id'] . ':after { border-color: ' . $atts['color'] . ';}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:divider', 'flyfood_action_shortcode_divider_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_special_heading_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_special_heading_enqueue_dynamic_css( $data ) {
		$shortcode = 'special_heading';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fw-heading.sh-' . $atts['unique_id'] . ' .fw-special-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fw-heading.sh-' . $atts['unique_id'] . ' .fw-special-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['subtitle_styling']['selected'] == 'yes' ) {
			// subtitle styling
			$subtitle_styling = flyfood_get_shortcode_advanced_styles( $atts['subtitle_styling']['yes']['font'] );
			if ( ! empty( $subtitle_styling ) ) {
				$final_styles .= '.fw-heading.sh-' . $atts['unique_id'] . ' .description {' . $subtitle_styling . '}';
			}

			// responsive subtitle styling
			$responsive_subtitle_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['subtitle_styling']['yes']['font'],
			                                                                         'selector' => '.fw-heading.sh-' . $atts['unique_id'] . ' .description'
			) );
			if ( ! empty( $responsive_subtitle_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_subtitle_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:special_heading', 'flyfood_action_shortcode_special_heading_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_fly_experience_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_fly_experience_enqueue_dynamic_css( $data ) {
		$shortcode = 'fly_experience';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-experince.sh-' . $atts['unique_id'] . ' .title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-experince.sh-' . $atts['unique_id'] . ' .title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['period_styling']['selected'] == 'yes' ) {
			// period styling
			$period_styling = flyfood_get_shortcode_advanced_styles( $atts['period_styling']['yes']['font'] );
			if ( ! empty( $period_styling ) ) {
				$final_styles .= '.fly-experince.sh-' . $atts['unique_id'] . ' .widget-info strong {' . $period_styling . '}';
			}

			// responsive period styling
			$responsive_period_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['period_styling']['yes']['font'],
			                                                                       'selector' => '.fly-experince.sh-' . $atts['unique_id'] . ' .widget-info strong'
			) );
			if ( ! empty( $responsive_period_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_period_styling . '}';
			}
		}

		if ( $atts['description_styling']['selected'] == 'yes' ) {
			// description styling
			$description_styling = flyfood_get_shortcode_advanced_styles( $atts['description_styling']['yes']['font'] );
			if ( ! empty( $description_styling ) ) {
				$final_styles .= '.fly-experince.sh-' . $atts['unique_id'] . ' .widget-info span {' . $description_styling . '}';
			}

			// responsive description styling
			$responsive_description_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['description_styling']['yes']['font'],
			                                                                            'selector' => '.fly-experince.sh-' . $atts['unique_id'] . ' .widget-info span'
			) );
			if ( ! empty( $responsive_description_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_description_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:fly_experience', 'flyfood_action_shortcode_fly_experience_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_fly_basic_information_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_fly_basic_information_enqueue_dynamic_css( $data ) {
		$shortcode = 'fly_basic_information';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-basic-information.sh-' . $atts['unique_id'] . ' .title {' . $title_styling . '; margin-bottom: 1em;}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-basic-information.sh-' . $atts['unique_id'] . ' .title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['label_styling']['selected'] == 'yes' ) {
			// label styling
			$label_styling = flyfood_get_shortcode_advanced_styles( $atts['label_styling']['yes']['font'] );
			if ( ! empty( $label_styling ) ) {
				$final_styles .= '.fly-basic-information.sh-' . $atts['unique_id'] . ' .widget-info strong {' . $label_styling . '}';
			}

			// responsive label styling
			$responsive_label_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['label_styling']['yes']['font'],
			                                                                      'selector' => '.fly-basic-information.sh-' . $atts['unique_id'] . ' .widget-info strong'
			) );
			if ( ! empty( $responsive_label_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_label_styling . '}';
			}
		}

		if ( $atts['text_styling']['selected'] == 'yes' ) {
			// text styling
			$text_styling = flyfood_get_shortcode_advanced_styles( $atts['text_styling']['yes']['font'] );
			if ( ! empty( $text_styling ) ) {
				$final_styles .= '.fly-basic-information.sh-' . $atts['unique_id'] . ' .widget-info span {' . $text_styling . '}';
			}

			// responsive text styling
			$responsive_text_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['text_styling']['yes']['font'],
			                                                                     'selector' => '.fly-basic-information.sh-' . $atts['unique_id'] . ' .widget-info span'
			) );
			if ( ! empty( $responsive_text_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_text_styling . '}';
			}
		}

		if ( $atts['link_styling']['selected'] == 'yes' ) {
			// link styling
			$link_styling = flyfood_get_shortcode_advanced_styles( $atts['link_styling']['yes']['font'] );
			if ( ! empty( $link_styling ) ) {
				$final_styles .= '.fly-basic-information.sh-' . $atts['unique_id'] . ' .link {' . $link_styling . '}';
			}

			// responsive description styling
			$responsive_link_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['link_styling']['yes']['font'],
			                                                                     'selector' => '.fly-basic-information.sh-' . $atts['unique_id'] . ' .link'
			) );
			if ( ! empty( $responsive_link_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_link_styling . '}';
			}

			if ( ! empty( $atts['link_styling']['yes']['hover'] ) ) {
				$final_styles .= '.fly-basic-information.sh-' . $atts['unique_id'] . ' .link:hover {color:' . $atts['link_styling']['yes']['hover'] . ';}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:fly_basic_information', 'flyfood_action_shortcode_fly_basic_information_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_service_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_service_enqueue_dynamic_css( $data ) {
		$shortcode = 'service';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fw-service.sh-' . $atts['unique_id'] . ' .fw-service-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fw-service.sh-' . $atts['unique_id'] . ' .fw-service-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['description_styling']['selected'] == 'yes' ) {
			// description styling
			$description_styling = flyfood_get_shortcode_advanced_styles( $atts['description_styling']['yes']['font'] );
			if ( ! empty( $description_styling ) ) {
				$final_styles .= '.fw-service.sh-' . $atts['unique_id'] . ' .description, .fw-service.sh-' . $atts['unique_id'] . ' .description p {' . $description_styling . '}';
			}

			// responsive description styling
			$responsive_description_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['description_styling']['yes']['font'],
			                                                                            'selector' => '.fw-service.sh-' . $atts['unique_id'] . ' .description, .fw-service.sh-' . $atts['unique_id'] . ' .description p'
			) );
			if ( ! empty( $responsive_description_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_description_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:service', 'flyfood_action_shortcode_service_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_skills_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_skills_enqueue_dynamic_css( $data ) {
		$shortcode = 'skills';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-skills.sh-' . $atts['unique_id'] . ' .title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-skills.sh-' . $atts['unique_id'] . ' .title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['skill_title_styling']['selected'] == 'yes' ) {
			// skill title styling
			$skill_title_styling = flyfood_get_shortcode_advanced_styles( $atts['skill_title_styling']['yes']['font'] );
			if ( ! empty( $skill_title_styling ) ) {
				$final_styles .= '.fly-skills.sh-' . $atts['unique_id'] . ' .widget-skills .skill-title, .fly-skills.sh-' . $atts['unique_id'] . ' .widget-skills .skill-percentage {' . $skill_title_styling . '}';
			}

			// responsive skill title styling
			$responsive_skill_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['skill_title_styling']['yes']['font'],
			                                                                            'selector' => '.fly-skills.sh-' . $atts['unique_id'] . ' .widget-skills .skill-title, .fly-skills.sh-' . $atts['unique_id'] . ' .widget-skills .skill-percentage'
			) );
			if ( ! empty( $responsive_skill_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_skill_title_styling . '}';
			}
		}

		if ( ! empty( $atts['progress_color'] ) ) {
			$final_styles .= '.fly-skills.sh-' . $atts['unique_id'] . ' .widget-skills .skill .progress-bar{ background-color: ' . $atts['progress_color'] . '}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:skills', 'flyfood_action_shortcode_skills_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_tabs_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_tabs_enqueue_dynamic_css( $data ) {
		$shortcode = 'tabs';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-tabs-container.sh-' . $atts['unique_id'] . ' .fly-tab-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-tabs-container.sh-' . $atts['unique_id'] . ' .fly-tab-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['content_styling']['selected'] == 'yes' ) {
			// content styling
			$content_styling = flyfood_get_shortcode_advanced_styles( $atts['content_styling']['yes']['font'] );
			if ( ! empty( $content_styling ) ) {
				$final_styles .= '.fly-tabs-container.sh-' . $atts['unique_id'] . ' .description, .fly-tabs-container.sh-' . $atts['unique_id'] . ' .description p {' . $content_styling . '}';
			}

			// responsive content styling
			$responsive_content_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['content_styling']['yes']['font'],
			                                                                        'selector' => '.fly-tabs-container.sh-' . $atts['unique_id'] . ' .description, .fly-tabs-container.sh-' . $atts['unique_id'] . ' .description p'
			) );
			if ( ! empty( $responsive_content_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_content_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:tabs', 'flyfood_action_shortcode_tabs_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_team_member_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_team_member_enqueue_dynamic_css( $data ) {
		$shortcode = 'team_member';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['name_styling']['selected'] == 'yes' ) {
			// name styling
			$name_styling = flyfood_get_shortcode_advanced_styles( $atts['name_styling']['yes']['font'] );
			if ( ! empty( $name_styling ) ) {
				$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .big-text {' . $name_styling . '}';
			}

			// responsive name styling
			$responsive_name_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['name_styling']['yes']['font'],
			                                                                     'selector' => '.fly-team-member.sh-' . $atts['unique_id'] . ' .big-text'
			) );
			if ( ! empty( $responsive_name_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_name_styling . '}';
			}
		}

		if ( $atts['position_styling']['selected'] == 'yes' ) {
			// position styling
			$position_styling = flyfood_get_shortcode_advanced_styles( $atts['position_styling']['yes']['font'] );
			if ( ! empty( $position_styling ) ) {
				$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .small-text {' . $position_styling . '}';
			}

			// responsive position styling
			$responsive_position_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['position_styling']['yes']['font'],
			                                                                         'selector' => '.fly-team-member.sh-' . $atts['unique_id'] . ' .small-text'
			) );
			if ( ! empty( $responsive_position_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_position_styling . '}';
			}
		}

		if ( $atts['content_styling']['selected'] == 'yes' ) {
			// content styling
			$content_styling = flyfood_get_shortcode_advanced_styles( $atts['content_styling']['yes']['font'] );
			if ( ! empty( $content_styling ) ) {
				$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .description, .fly-team-member.sh-' . $atts['unique_id'] . ' .description p {' . $content_styling . '}';
			}

			// responsive content styling
			$responsive_content_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['content_styling']['yes']['font'],
			                                                                        'selector' => '.fly-team-member.sh-' . $atts['unique_id'] . ' .description, .fly-team-member.sh-' . $atts['unique_id'] . ' .description p'
			) );
			if ( ! empty( $responsive_content_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_content_styling . '}';
			}
		}

		if ( $atts['border']['selected'] == 'yes' ) {
			if ( ! empty( $atts['border']['yes']['border_width'] ) ) {
				$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .avatar {border-width: ' . (int) $atts['border']['yes']['border_width'] . 'px;}';
			}
			if ( ! empty( $atts['border']['yes']['border_color'] ) ) {
				$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .avatar {border-color: ' . $atts['border']['yes']['border_color'] . ';}';
			}
		} else {
			$final_styles .= '.fly-team-member.sh-' . $atts['unique_id'] . ' .avatar {border: none;}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:team_member', 'flyfood_action_shortcode_team_member_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_testimonials_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_testimonials_enqueue_dynamic_css( $data ) {
		$shortcode = 'testimonials';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}

			// color for title separator
			if ( ! empty( $atts['title_styling']['yes']['font']['color'] ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-title:after { border-top: 2px solid ' . $atts['title_styling']['yes']['font']['color'] . '; }';
			}
		}

		if ( $atts['text_styling']['selected'] == 'yes' ) {
			// text styling
			$text_styling = flyfood_get_shortcode_advanced_styles( $atts['text_styling']['yes']['font'] );
			if ( ! empty( $text_styling ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-text, .fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-text p {' . $text_styling . '}';
			}

			// responsive text styling
			$responsive_text_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['text_styling']['yes']['font'],
			                                                                     'selector' => '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-text, .fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-text p'
			) );
			if ( ! empty( $responsive_text_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_text_styling . '}';
			}
		}

		if ( $atts['name_styling']['selected'] == 'yes' ) {
			// name styling
			$name_styling = flyfood_get_shortcode_advanced_styles( $atts['name_styling']['yes']['font'] );
			if ( ! empty( $name_styling ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .author-name {' . $name_styling . '}';
			}

			// responsive name styling
			$responsive_name_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['name_styling']['yes']['font'],
			                                                                     'selector' => '.fw-testimonials.sh-' . $atts['unique_id'] . ' .author-name'
			) );
			if ( ! empty( $responsive_name_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_name_styling . '}';
			}
		}

		if ( $atts['position_styling']['selected'] == 'yes' ) {
			// position styling
			$position_styling = flyfood_get_shortcode_advanced_styles( $atts['position_styling']['yes']['font'] );
			if ( ! empty( $position_styling ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-author em {' . $position_styling . '}';
			}

			// responsive position styling
			$responsive_position_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['position_styling']['yes']['font'],
			                                                                         'selector' => '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-author em'
			) );
			if ( ! empty( $responsive_position_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_position_styling . '}';
			}
		}

		if ( $atts['website_styling']['selected'] == 'yes' ) {
			// website styling
			$website_styling = flyfood_get_shortcode_advanced_styles( $atts['website_styling']['yes']['font'] );
			if ( ! empty( $website_styling ) ) {
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-url a {' . $website_styling . '}';
				$final_styles .= '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-url a:hover { opacity: 0.8; }';
			}

			// responsive website styling
			$responsive_website_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['website_styling']['yes']['font'],
			                                                                        'selector' => '.fw-testimonials.sh-' . $atts['unique_id'] . ' .fw-testimonials-url a'
			) );
			if ( ! empty( $responsive_website_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_website_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:testimonials', 'flyfood_action_shortcode_testimonials_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_text_block_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_text_block_enqueue_dynamic_css( $data ) {
		$shortcode = 'text_block';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['content_styling']['selected'] == 'yes' ) {
			// content styling
			$content_styling = flyfood_get_shortcode_advanced_styles( $atts['content_styling']['yes']['font'] );
			if ( ! empty( $content_styling ) ) {
				$final_styles .= '.text-block.sh-' . $atts['unique_id'] . ', .text-block.sh-' . $atts['unique_id'] . ' p {' . $content_styling . '}';
			}

			// responsive content styling
			$responsive_content_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['content_styling']['yes']['font'],
			                                                                        'selector' => '.text-block.sh-' . $atts['unique_id'] . ', .text-block.sh-' . $atts['unique_id'] . ' p'
			) );
			if ( ! empty( $responsive_content_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_content_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:text_block', 'flyfood_action_shortcode_text_block_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_icon_box_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_icon_box_enqueue_dynamic_css( $data ) {
		$shortcode = 'icon_box';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fw-iconbox.sh-' . $atts['unique_id'] . ' .title-info {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fw-iconbox.sh-' . $atts['unique_id'] . ' .title-info'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['content_styling']['selected'] == 'yes' ) {
			// content styling
			$content_styling = flyfood_get_shortcode_advanced_styles( $atts['content_styling']['yes']['font'] );
			if ( ! empty( $content_styling ) ) {
				$final_styles .= '.fw-iconbox.sh-' . $atts['unique_id'] . ' .text-description, .fw-iconbox.sh-' . $atts['unique_id'] . ' .info-pricing .text-description p {' . $content_styling . '}';
			}

			// responsive content styling
			$responsive_content_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['content_styling']['yes']['font'],
			                                                                        'selector' => '.fw-iconbox.sh-' . $atts['unique_id'] . ' .text-description, .fw-iconbox.sh-' . $atts['unique_id'] . ' .info-pricing .text-description p'
			) );
			if ( ! empty( $responsive_content_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_content_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:icon_box', 'flyfood_action_shortcode_icon_box_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_performance_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_performance_enqueue_dynamic_css( $data ) {
		$shortcode = 'performance';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-performance.sh-' . $atts['unique_id'] . ' .performance-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-performance.sh-' . $atts['unique_id'] . ' .performance-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['subtitle_styling']['selected'] == 'yes' ) {
			// subtitle styling
			$subtitle_styling = flyfood_get_shortcode_advanced_styles( $atts['subtitle_styling']['yes']['font'] );
			if ( ! empty( $subtitle_styling ) ) {
				$final_styles .= '.fly-performance.sh-' . $atts['unique_id'] . ' .text-gray {' . $subtitle_styling . '}';
			}

			// responsive subtitle styling
			$responsive_subtitle_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['subtitle_styling']['yes']['font'],
			                                                                         'selector' => '.fly-performance.sh-' . $atts['unique_id'] . ' .text-gray'
			) );
			if ( ! empty( $responsive_subtitle_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_subtitle_styling . '}';
			}
		}

		if ( $atts['number_styling']['selected'] == 'yes' ) {
			// number styling
			$number_styling = flyfood_get_shortcode_advanced_styles( $atts['number_styling']['yes']['font'] );
			if ( ! empty( $number_styling ) ) {
				$final_styles .= '.fly-performance.sh-' . $atts['unique_id'] . ' .number {' . $number_styling . '}';
			}

			// responsive subtitle styling
			$responsive_number_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['number_styling']['yes']['font'],
			                                                                       'selector' => '.fly-performance.sh-' . $atts['unique_id'] . ' .number'
			) );
			if ( ! empty( $responsive_number_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_number_styling . '}';
			}
		}

		// icon color
		if ( ! empty( $atts['icon_color'] ) ) {
			$final_styles .= '.fly-performance.sh-' . $atts['unique_id'] . ' .icon i { color : ' . $atts['icon_color'] . '}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:performance', 'flyfood_action_shortcode_performance_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_fly_gallery_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_fly_gallery_enqueue_dynamic_css( $data ) {
		$shortcode = 'fly_gallery';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-gallery.sh-' . $atts['unique_id'] . ' .item-link .item-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-gallery.sh-' . $atts['unique_id'] . ' .item-link .item-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:fly_gallery', 'flyfood_action_shortcode_fly_gallery_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_accordion_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_accordion_enqueue_dynamic_css( $data ) {
		$shortcode = 'accordion';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		// general title styling
		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fly-accordion.sh-' . $atts['unique_id'] . ' .widget-title {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fly-accordion.sh-' . $atts['unique_id'] . ' .widget-title'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		// tab title styling
		if ( $atts['tab_title_styling']['selected'] == 'yes' ) {
			// title styling
			$tab_title_styling = flyfood_get_shortcode_advanced_styles( $atts['tab_title_styling']['yes']['font'] );
			if ( ! empty( $tab_title_styling ) ) {
				$final_styles .= '.fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle, .fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle.collapsed {' . $tab_title_styling . '}';
			}

			// responsive title styling
			$responsive_tab_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['tab_title_styling']['yes']['font'],
			                                                                          'selector' => '.fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle'
			) );
			if ( ! empty( $responsive_tab_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_tab_title_styling . '}';
			}

			// hover color
			if ( ! empty( $atts['tab_title_styling']['yes']['hover_color'] ) ) {
				$final_styles .= '.fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle, .fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle.collapsed:hover, .fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle.collapsed:active, .fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle[aria-expanded="true"] {color: ' . $atts['tab_title_styling']['yes']['hover_color'] . ';}';
				$final_styles .= '.fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle:before, .fly-accordion.sh-' . $atts['unique_id'] . ' a.panel-toggle:after {background-color: ' . $atts['tab_title_styling']['yes']['hover_color'] . ';}';
			}
		}

		// tab content styling
		if ( $atts['tab_content_styling']['selected'] == 'yes' ) {
			// title styling
			$tab_content_styling = flyfood_get_shortcode_advanced_styles( $atts['tab_content_styling']['yes']['font'] );
			if ( ! empty( $tab_content_styling ) ) {
				$final_styles .= '.fly-accordion.sh-' . $atts['unique_id'] . ' .panel-body, .fly-accordion.sh-' . $atts['unique_id'] . ' .panel-body p {' . $tab_content_styling . '}';
			}

			// responsive title styling
			$responsive_tab_content_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['tab_content_styling']['yes']['font'],
			                                                                            'selector' => '.fly-accordion.sh-' . $atts['unique_id'] . ' .panel-body, .fly-accordion.sh-' . $atts['unique_id'] . ' .panel-body p'
			) );
			if ( ! empty( $responsive_tab_content_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_tab_content_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:accordion', 'flyfood_action_shortcode_accordion_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_pricing_table_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_pricing_table_enqueue_dynamic_css( $data ) {
		$shortcode = 'pricing_table';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( $atts['button']['yes']['button_options']['type']['selected'] == 'btn-fill' ) {
			// bg color for fill button
			if ( ! empty( $atts['button']['yes']['button_options']['type']['btn-fill']['bg_color'] ) ) {
				$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ', .sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':hover, .sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':focus{ background-color: ' . $atts['button']['yes']['button_options']['type']['btn-fill']['bg_color'] . ';}';
			}
		} elseif ( $atts['button']['yes']['button_options']['type']['selected'] == 'btn-transparent' ) {
			// border color
			if ( ! empty( $atts['button']['yes']['button_options']['label_color'] ) ) {
				$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . '{ border-color: ' . $atts['button']['yes']['button_options']['label_color'] . ';}';
			}
			// border hover color
			if ( ! empty( $atts['button']['yes']['button_options']['bg_hover_color'] ) ) {
				$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':hover { border-color: ' . $atts['button']['yes']['button_options']['bg_hover_color'] . ';}';
			}
		}

		// label color
		if ( ! empty( $atts['button']['yes']['button_options']['label_color'] ) ) {
			$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ', .sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':hover, .sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':focus { color: ' . $atts['button']['yes']['button_options']['label_color'] . ';}';
		}

		// label hover color
		if ( ! empty( $atts['button']['yes']['button_options']['label_hover_color'] ) ) {
			$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':hover { color: ' . $atts['button']['yes']['button_options']['label_hover_color'] . ';}';
		}

		// bg hover color
		if ( ! empty( $atts['button']['yes']['button_options']['bg_hover_color'] ) ) {
			$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . ':hover { background-color: ' . $atts['button']['yes']['button_options']['bg_hover_color'] . ';}';
		}

		// btn label styling
		if ( isset( $atts['button']['yes']['button_options']['label_styling']['selected'] ) && $atts['button']['yes']['button_options']['label_styling']['selected'] == 'yes' ) {
			// label styling
			$label_styling = flyfood_get_shortcode_advanced_styles( $atts['button']['yes']['button_options']['label_styling']['yes']['font'] );
			if ( ! empty( $label_styling ) ) {
				$final_styles .= '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . '.' . $atts['button']['yes']['button_options']['size'] . '{' . $label_styling . '}';
			}

			// responsive label styling
			$responsive_label_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['button']['yes']['button_options']['label_styling']['yes']['font'],
			                                                                      'selector' => '.sh-' . $atts['unique_id'] . ' .btn.' . $atts['button']['yes']['button_options']['type']['selected'] . '.' . $atts['button']['yes']['button_options']['size']
			) );
			if ( ! empty( $responsive_label_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_label_styling . '}';
			}
		}

		if ( $atts['title_styling']['selected'] == 'yes' ) {
			// title styling
			$title_styling = flyfood_get_shortcode_advanced_styles( $atts['title_styling']['yes']['font'] );
			if ( ! empty( $title_styling ) ) {
				$final_styles .= '.fw-pricing.sh-' . $atts['unique_id'] . ' .title-header {' . $title_styling . '}';
			}

			// responsive title styling
			$responsive_title_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['title_styling']['yes']['font'],
			                                                                      'selector' => '.fw-pricing.sh-' . $atts['unique_id'] . ' .title-header'
			) );
			if ( ! empty( $responsive_title_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_title_styling . '}';
			}
		}

		if ( $atts['time_styling']['selected'] == 'yes' ) {
			// time styling
			$time_styling = flyfood_get_shortcode_advanced_styles( $atts['time_styling']['yes']['font'] );
			if ( ! empty( $time_styling ) ) {
				$final_styles .= '.fw-pricing.sh-' . $atts['unique_id'] . ' .subtitle-header {' . $time_styling . '}';
			}

			// responsive time styling
			$responsive_time_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['time_styling']['yes']['font'],
			                                                                     'selector' => '.fw-pricing.sh-' . $atts['unique_id'] . ' .subtitle-header'
			) );
			if ( ! empty( $responsive_time_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_time_styling . '}';
			}
		}

		if ( $atts['price_styling']['selected'] == 'yes' ) {
			// price styling
			$price_styling = flyfood_get_shortcode_advanced_styles( $atts['price_styling']['yes']['font'] );
			if ( ! empty( $price_styling ) ) {
				$final_styles .= '.fw-pricing.sh-' . $atts['unique_id'] . ' .price .number {' . $price_styling . '}';
			}

			// responsive price styling
			$responsive_price_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['price_styling']['yes']['font'],
			                                                                      'selector' => '.fw-pricing.sh-' . $atts['unique_id'] . ' .price .number'
			) );
			if ( ! empty( $responsive_price_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_price_styling . '}';
			}
		}

		if ( $atts['currency_styling']['selected'] == 'yes' ) {
			// currency styling
			$currency_styling = flyfood_get_shortcode_advanced_styles( $atts['currency_styling']['yes']['font'] );
			if ( ! empty( $currency_styling ) ) {
				$final_styles .= '.fw-pricing.sh-' . $atts['unique_id'] . ' .price .price-currency {' . $currency_styling . '}';
			}

			// responsive currency styling
			$responsive_currency_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['currency_styling']['yes']['font'],
			                                                                         'selector' => '.fw-pricing.sh-' . $atts['unique_id'] . ' .price .price-currency'
			) );
			if ( ! empty( $responsive_currency_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_currency_styling . '}';
			}
		}

		if ( $atts['rows_styling']['selected'] == 'yes' ) {
			// rows styling
			$rows_styling = flyfood_get_shortcode_advanced_styles( $atts['rows_styling']['yes']['font'] );
			if ( ! empty( $rows_styling ) ) {
				$final_styles .= '.fw-pricing.sh-' . $atts['unique_id'] . '.card-price .text-description {' . $rows_styling . '}';
			}

			// responsive rows styling
			$responsive_rows_styling = flyfood_responsive_heading_styles( array( 'styles'   => $atts['rows_styling']['yes']['font'],
			                                                                     'selector' => '.fw-pricing.sh-' . $atts['unique_id'] . '.card-price .text-description'
			) );
			if ( ! empty( $responsive_rows_styling ) ) {
				$final_styles .= '@media(max-width:767px){' . $responsive_rows_styling . '}';
			}
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:pricing_table', 'flyfood_action_shortcode_pricing_table_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_action_shortcode_column_enqueue_dynamic_css' ) ) :
	/**
	 * @internal
	 *
	 * @param array $data
	 */
	function flyfood_action_shortcode_column_enqueue_dynamic_css( $data ) {
		$shortcode = 'column';
		$atts      = shortcode_parse_atts( $data['atts_string'] );
		$atts      = fw_ext_shortcodes_decode_attr( $atts, $shortcode, $data['post']->ID );

		$final_styles = '';
		if ( ! empty( $atts['margin'] ) ) {
			$final_styles .= '.sh-' . $atts['unique_id'] . ' .fly-col-inner { margin: ' . $atts['margin'] . ';}';
		}

		if ( empty( $final_styles ) ) {
			return;
		}

		wp_add_inline_style( 'style', $final_styles );
	}

	add_action( 'fw_ext_shortcodes_enqueue_static:column', 'flyfood_action_shortcode_column_enqueue_dynamic_css' );
endif;


if ( ! function_exists( 'flyfood_body_class' ) ) :
	/**
	 * @internal
	 *
	 * @param array $classes
	 */
	function flyfood_body_class( $classes ) {
		$classes[] = function_exists( 'fw_get_db_settings_option' ) ? fw_get_db_settings_option( 'header_type/selected', 'header-1' ) : 'header-1';

		$classes[] = flyfood_theme_header_class();

		return $classes;
	}
endif;
add_filter( 'body_class', 'flyfood_body_class' );


function flyfood_register_required_plugins() {

	/**
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(
		array(
			'name'     => esc_html__( 'Unyson Framework', 'flyfood' ),
			'slug'     => 'unyson',
			'required' => true,

		),
		array(
			'name'     => 'Unyson WooComerce Shortcodes',
			'slug'     => 'uws-unyson-woocommerce-shortcodes',
			'required' => false,
		),
		// This is an example of how to include a plugin from the WordPress Plugin Repository.
		array(
			'name'     => esc_html__( 'Mailchimp', 'flyfood' ),
			'slug'     => 'mailchimp-for-wp',
			'required' => false,
		),
		array(
			'name'     => esc_html__( 'WooCommerce', 'flyfood' ),
			'slug'     => 'woocommerce',
			'required' => false,
		),
		array(
			'name'     => 'Contact Form 7',
			'slug'     => 'contact-form-7',
			'required' => false,
		),
	);

	/**
	 * Array of configuration settings. Amend each line as needed.
	 * If you want the default strings to be available under your own theme domain,
	 * leave the strings uncommented.
	 * Some of the strings are added into a sprintf, so see the comments at the
	 * end of each line for what each argument will be.
	 */
	$config = array(
		'id'           => 'tgmpa',
		// Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',
		// Default absolute path to pre-packaged plugins.
		'menu'         => 'tgmpa-install-plugins',
		// Menu slug.
		'has_notices'  => true,
		// Show admin notices or not.
		'dismissable'  => true,
		// If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',
		// If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,
		// Automatically activate plugins after installation or not.
		'message'      => '',
		// Message to output right before the plugins table.
		'strings'      => array(
			'page_title'                      => esc_html__( 'Install Required Plugins', 'flyfood' ),
			'menu_title'                      => esc_html__( 'Install Plugins', 'flyfood' ),
			'installing'                      => esc_html__( 'Installing Plugin: %s', 'flyfood' ),
			// %s = plugin name.
			'oops'                            => esc_html__( 'Something went wrong with the plugin API.', 'flyfood' ),
			'notice_can_install_required'     => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'flyfood' ),
			// %1$s = plugin name(s).
			'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'flyfood' ),
			// %1$s = plugin name(s).
			'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'flyfood' ),
			'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'flyfood' ),
			'return'                          => esc_html__( 'Return to Required Plugins Installer', 'flyfood' ),
			'plugin_activated'                => esc_html__( 'Plugin activated successfully.', 'flyfood' ),
			'complete'                        => esc_html__( 'All plugins installed and activated successfully. %s', 'flyfood' ),
			// %s = dashboard link.
			'nag_type'                        => esc_html__( 'updated', 'flyfood' )
			// Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
		)
	);

	tgmpa( $plugins, $config );
}

add_action( 'tgmpa_register', 'flyfood_register_required_plugins' );


/* filters for woocommerce */
add_filter( 'loop_shop_per_page', 'flyfood_loop_shop_per_page', 20 );
function flyfood_loop_shop_per_page() {
	return 8;
}


if ( ! function_exists( 'flyfood_filter_woocommerce_related_products_filter' ) ) :
	/**
	 * Woocomerce related products filter
	 */
	function flyfood_filter_woocommerce_related_products_filter( $args ) {
		$args['posts_per_page'] = 4; // 4 related products
		$args['columns']        = 4; // arranged in 4 columns

		return $args;
	}

	add_filter( 'woocommerce_output_related_products_args', 'flyfood_filter_woocommerce_related_products_filter' );
endif;


if ( ! function_exists( 'flyfood_action_woocommerce_output_upsells' ) ) {
	/**
	 * Woocomerce upsell output action
	 */
	function flyfood_action_woocommerce_output_upsells() {
		woocommerce_upsell_display( 4, 4 ); // Display 4 products in rows of 4
	}
}
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
add_action( 'woocommerce_after_single_product_summary', 'flyfood_action_woocommerce_output_upsells', 15 );


if ( ! function_exists( 'flyfood_action_woocommerce_output_content_wrapper' ) ) :
	/**
	 * Woocomerce output content wrapper before
	 */
	function flyfood_action_woocommerce_output_content_wrapper() {
		$flyfood_sidebar_position = function_exists( 'fw_ext_sidebars_get_current_position' ) ? fw_ext_sidebars_get_current_position() : 'right';
		ob_start();
		?>
		<div class="page-wrapper <?php flyfood_theme_get_sidebar_class( $flyfood_sidebar_position ); ?>">
		<div class="container">
		<div class="row">
		<!-- Content -->
		<main class="fly-content">

		<?php
		echo ob_get_clean();
	}
endif;


if ( ! function_exists( 'flyfood_action_woocommerce_output_content_wrapper_end' ) ):
	/**
	 * Woocomerce output content wrapper after
	 */
	function flyfood_action_woocommerce_output_content_wrapper_end() {
		ob_start(); ?>
		</main>
		<?php get_sidebar(); ?>
		</div>
		</div>
		</div>
		<?php
		echo ob_get_clean();
	}

endif;


remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

add_action( 'woocommerce_before_main_content', 'flyfood_action_woocommerce_output_content_wrapper', 10 );
add_action( 'woocommerce_after_main_content', 'flyfood_action_woocommerce_output_content_wrapper_end', 10 );