<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

/**
 * Include static files: javascript and css
 */

$template_directory_uri = get_template_directory_uri();
$flyfood_version        = defined( 'FW' ) ? fw()->theme->manifest->get_version() : '1.0';

/**
 * Enqueue scripts and styles for the front end.
 */

/* deregister unyson styles */
wp_deregister_style( 'fw-ext-forms-default-styles' );
wp_deregister_style( 'fw-ext-builder-frontend-grid' );

wp_enqueue_style(
	'font-awesome',
	flyfood_include_file_from_child( '/css/font-awesome.css' ),
	array(),
	$flyfood_version
);

wp_enqueue_style(
	'bootstrap',
	flyfood_include_file_from_child( '/css/bootstrap.css' ),
	array(),
	$flyfood_version
);

wp_enqueue_style(
	'style',
	esc_url( get_stylesheet_uri() ),
	array(),
	$flyfood_version
);

wp_enqueue_style(
	'animate',
	flyfood_include_file_from_child( '/css/animate.css' ),
	array(),
	$flyfood_version
);

/* include theme js files */
if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

wp_enqueue_script(
	'modernizr',
	flyfood_include_file_from_child( '/js/libs/modernizr-3.3.1.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	false
);

wp_enqueue_script(
	'bootstrap',
	flyfood_include_file_from_child( '/js/libs/bootstrap-3.3.6.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'powerful-placeholder',
	flyfood_include_file_from_child( '/js/jquery.powerful-placeholder.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

// possible only on specific pages
wp_enqueue_script(
	'isotope',
	flyfood_include_file_from_child( '/js/isotope.pkgd.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'packery-mode',
	flyfood_include_file_from_child( '/js/packery-mode.pkgd.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script( 'imagesloaded' );

wp_enqueue_script(
	'swipebox',
	flyfood_include_file_from_child( '/js/jquery.swipebox.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'select2',
	flyfood_include_file_from_child( '/js/select2.full.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

// possible only on specific pages
wp_enqueue_script(
	'owl.carousel',
	flyfood_include_file_from_child( '/js/owl.carousel.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

// possible only on specific pages
wp_enqueue_script(
	'carouFredSel',
	flyfood_include_file_from_child( '/js/jquery.carouFredSel-6.2.1-packed.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'mousewheel',
	flyfood_include_file_from_child( '/js/jquery.mousewheel.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'touchSwipe',
	flyfood_include_file_from_child( '/js/jquery.touchSwipe.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'sticky-kit',
	flyfood_include_file_from_child( '/js/jquery.sticky-kit.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'TweenLite',
	flyfood_include_file_from_child( '/js/TweenLite.min.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'ScrollToPlugin',
	flyfood_include_file_from_child( '/js/ScrollToPlugin.min.js' ),
	array( 'jquery', 'TweenLite' ),
	$flyfood_version,
	true
);

wp_enqueue_script(
	'flyfood-general',
	flyfood_include_file_from_child( '/js/general.js' ),
	array( 'jquery' ),
	$flyfood_version,
	true
);

wp_localize_script( 'flyfood-general', 'FlyPhpVars', array(
	'ajax_url'        => admin_url( 'admin-ajax.php' ),
	'fail_form_error' => esc_html__( 'Sorry you are an error in ajax, please contact the administrator of the website', 'flyfood' ),
) );