<?php
/**
 * The template for displaying sticky posts in the Image post format
 */

$post_id = get_the_ID();
if ( ! isset( $extra_options ) ) {
	$extra_options = array();
}
$flyfood_permalink = get_permalink();

$flyfood_post_view_type = ( defined( 'FW' ) ) ? fw_get_db_post_option( $post_id, 'post_type' ) : '';
if ( ! empty( $extra_options ) ) {
	$post_meta_options = $extra_options;
} else {
	$post_meta_options['enable_post_author']   = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_author' ) : 'yes';
	$post_meta_options['enable_post_date']     = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_date' ) : 'yes';
	$post_meta_options['enable_post_share']    = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_share' ) : 'no';
	$post_meta_options['enable_post_comments'] = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_comments' ) : 'yes';
	$post_meta_options['enable_post_likes']    = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_likes' ) : 'yes';
}

$image = wp_get_attachment_url( get_post_thumbnail_id( $post_id ), 'post-thumbnails' );
?>
<!-- Post -->
<article id="post-<?php the_ID(); ?>" <?php post_class( 'article' ); ?> itemscope itemtype="http://schema.org/Article">
	<?php if ( ! empty( $flyfood_post_view_type ) || ! empty( $image ) ) : ?>
		<div class="post-media">
			<?php if ( ! empty( $flyfood_post_view_type ) ) :
				flyfood_theme_get_post_view_type( $flyfood_post_view_type, $post_id );
			else :
				flyfood_theme_show_default_post_image( $image, $post_id );
			endif; ?>
		</div>
	<?php endif; ?>

	<h3 class="post-title"><a href="<?php echo esc_url( $flyfood_permalink ); ?>"
							  itemprop="name"><?php the_title(); ?></a></h3>

	<?php flyfood_theme_post_meta_1( $post_meta_options ); ?>

	<div class="post-content" itemprop="articleBody">
		<?php if ( get_option( 'rss_use_excerpt' ) == '0' ) {
			the_content();
		} else {
			the_excerpt();
		} ?>
	</div>

	<?php if ( $post_meta_options['enable_post_share'] == 'yes' ) : ?>
		<?php flyfood_theme_share_post(); ?>
	<?php endif; ?>

	<?php flyfood_theme_post_meta_2( $post_meta_options ); ?>

	<div class="post-links">
		<a class="post-read-more" itemprop="url"
		   href="<?php echo esc_url( $flyfood_permalink ); ?>"><?php esc_html_e( 'Continue Reading', 'flyfood' ); ?></a>
	</div>
</article>
<!--/ Post -->