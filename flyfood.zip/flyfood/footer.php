<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content.
 */
?>

<?php flyfood_get_footer_instagram(); ?>

<!-- Footer -->
<footer class="footer" itemprop="WPFooter">
	<?php if ( function_exists( 'fw_get_db_settings_option' ) && fw_get_db_settings_option( 'enable_footer_socials/selected', 'no' ) == 'yes' ) : ?>
		<?php flyfood_socials( array( 'class' => 'footer-social' ) ); ?>
	<?php endif; ?>

	<?php flyfood_get_footer_logo(); ?>

	<div class="footer-copyright">
		<?php echo defined( 'FW' ) ? do_shortcode( flyfood_theme_translate( fw_get_db_settings_option( 'copyright' ) ) ) : ''; ?>
	</div>

	<?php if ( function_exists( 'fw_get_db_settings_option' ) && fw_get_db_settings_option( 'enable_go_to_top', 'no' ) == 'yes' ) : ?>
		<a class="back-to-top anchor" href="#header"></a>
	<?php endif; ?>
</footer>
<!--/ Footer -->
<?php wp_footer(); ?>
</body>
</html>