<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
	'before_title' => array(
		'type'  => 'text',
		'label' => esc_html__( 'Before Title', 'flyfood' ),
		'desc'  => esc_html__( 'Enter the before title text', 'flyfood' )
	),
);