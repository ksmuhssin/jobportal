<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'interval' => array(
		'type'  => 'text',
		'label' => esc_html__( 'Interval', 'flyfood' ),
		'value' => '10000',
		'desc'  => esc_html__( 'Enter slider interval', 'flyfood' )
	)
);