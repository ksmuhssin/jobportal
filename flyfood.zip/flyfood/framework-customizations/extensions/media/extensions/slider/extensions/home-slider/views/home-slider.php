<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

if ( isset( $data['slides'] ) && ! empty( $data['slides'] ) ) :
	$interval = ! empty( $data['settings']['extra']['interval'] ) ? (int) $data['settings']['extra']['interval'] : '10000';
?>
	<!-- Main Slider -->
	<div class="main-carousel" data-interval="<?php echo esc_attr( $interval ); ?>">
		<ul>
			<?php foreach ( $data['slides'] as $slide ) : ?>
				<li class="carousel-item">
					<!-- Post -->
					<article class="article" itemscope itemtype="http://schema.org/Article">
						<div class="post-media">
							<img src="<?php echo flyfood_url_without_protocol(fw_resize( $slide['src'], 830, 500 )); ?>"
								 alt="<?php echo esc_attr( $slide['title'] ); ?>" itemprop="image"/>
						</div>

						<div class="post-content" itemprop="articleBody">
							<?php if ( $data['settings']['population_method'] == 'custom' ) : ?>
								<?php if ( ! empty( $slide['extra']['before_title'] ) ) : ?>
									<div class="post-meta">
										<span class="post-category"><?php echo( $slide['extra']['before_title'] ); ?></span>
									</div>
								<?php endif; ?>

								<h3 class="post-title" itemprop="name"><?php echo esc_attr( $slide['title'] ); ?></h3>

								<?php if ( ! empty( $slide['desc'] ) ) : ?>
									<div class="post-meta font2">
										<span class="post-author">
											<?php echo( $slide['desc'] ); ?>
										</span>
									</div>
								<?php endif; ?>

							<?php else : ?>
								<?php if ( $data['settings']['extra']['enable_category']['selected'] == 'yes' ) : ?>
									<div class="post-meta">
										<?php flyfood_theme_get_one_post_category( $slide['extra']['post_id'] ); ?>
									</div>
								<?php endif; ?>

								<h3 class="post-title"><a
											href="<?php echo esc_url( get_permalink( $slide['extra']['post_id'] ) ); ?>"
											itemprop="name"><?php echo esc_attr( $slide['title'] ); ?></a></h3>

								<div class="post-meta font2">
									<?php if ( $data['settings']['extra']['enable_author']['selected'] == 'yes' ) : ?>
										<?php $author_id = get_post_field( 'post_author', $slide['extra']['post_id'] ); ?>
										<span class="post-author"
											  itemprop="author"><?php esc_html_e( 'by', 'flyfood' ); ?> <a
													href="<?php echo esc_url( get_author_posts_url( 'user_url', $author_id ) ); ?>"><?php the_author_meta( 'display_name', $author_id ); ?></a></span>
									<?php endif; ?>

									<?php if ( $data['settings']['extra']['enable_comments']['selected'] == 'yes' ) : ?>
										<a href="<?php echo esc_url( get_permalink( $slide['extra']['post_id'] ) ); ?>#comments"
										   class="post-comments"><span
													itemprop="commentCount"><?php echo get_comments_number( $slide['extra']['post_id'] ); ?></span> <?php echo flyfood_get_comments_number( $slide['extra']['post_id'] ); ?>
										</a>
									<?php endif; ?>
								</div>
							<?php endif; ?>
						</div>
					</article>
					<!--/ Post -->
				</li>
			<?php endforeach; ?>
		</ul>
		<a class="prev" href="#"><i class="icon-arrow-left"></i></a>
		<a class="next" href="#"><i class="icon-arrow-right"></i></a>
	</div>
	<!--/ Main Slider -->
<?php endif; ?>