<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

if ( isset( $data['slides'] ) && ! empty( $data['slides'] ) ) :
	$version = defined( 'FW' ) ? fw()->theme->manifest->get_version() : '1.0';
	wp_enqueue_script(
		'froogaloop2',
		'https://f.vimeocdn.com/js/froogaloop2.min.js',
		array(),
		$version,
		true
	);

	wp_enqueue_script(
		'flyfood-start-video',
		flyfood_include_file_from_child( '/js/start-video.js' ),
		array( 'jquery' ),
		$version,
		true
	);

	$count    = 0;
	$interval = ! empty( $data['settings']['extra']['interval'] ) ? (int) $data['settings']['extra']['interval'] : '10000';
	?>
	<div class="fly-slider invisible" data-rotation-interval="<?php echo esc_attr( $interval ); ?>"
		 data-rotation-duration="1000">
		<div class="cube">
			<?php foreach ( $data['slides'] as $slide ) : $count ++; ?>
				<section class="slide" style="background-image: url(<?php echo esc_url( $slide['src'] ); ?>);">
					<?php if ( isset( $slide['extra']['video_bg']['selected'] ) && $slide['extra']['video_bg']['selected'] == 'yes' ) : ?>
						<?php if ( $slide['extra']['video_bg']['yes']['video_type']['selected'] == 'uploaded' && isset( $slide['extra']['video_bg']['yes']['video_type']['uploaded']['video']['url'] ) && ! empty( $slide['extra']['video_bg']['yes']['video_type']['uploaded']['video']['url'] ) ) : ?>
							<div class="video-container hidden-xs">
								<video autoplay loop muted width="1920" height="1080">
									<source src="<?php echo esc_url( $slide['extra']['video_bg']['yes']['video_type']['uploaded']['video']['url'] ); ?>" type='video/mp4; codecs="avc1.4D401E, mp4a.40.2"'/>
								</video>
							</div>
						<?php elseif ( $slide['extra']['video_bg']['yes']['video_type']['selected'] == 'youtube' && isset( $slide['extra']['video_bg']['yes']['video_type']['youtube']['video'] ) && ! empty( $slide['extra']['video_bg']['yes']['video_type']['youtube']['video'] ) ) : ?>
						<?php $youtube_id = flyfood_get_youtube_id( $slide['extra']['video_bg']['yes']['video_type']['youtube']['video'] ); ?>
							<div class="video-container hidden-xs">
								<div id="youtube-<?php echo esc_attr( $youtube_id ); ?>" data-id="<?php echo esc_attr( $youtube_id ); ?>" class="video youtube-video"></div>
							</div>
						<?php elseif ( $slide['extra']['video_bg']['yes']['video_type']['selected'] == 'vimeo' && isset( $slide['extra']['video_bg']['yes']['video_type']['vimeo']['video'] ) && ! empty( $slide['extra']['video_bg']['yes']['video_type']['vimeo']['video'] ) ) : ?>
							<div class="video-container hidden-xs">
								<?php $vimeo_id = (int) substr( parse_url( $slide['extra']['video_bg']['yes']['video_type']['vimeo']['video'], PHP_URL_PATH ), 1 ); ?>
								<<?php echo 'i'; ?>frame id="vimeo-<?php echo esc_attr( $vimeo_id ); ?>" class="video vimeo-video" src="https://player.vimeo.com/video/<?php echo esc_attr( $vimeo_id ); ?>?api=1&amp;loop=1&amp;title=0&amp;byline=0&amp;portrait=0&amp;color=d01e2f" width="500" height="281" webkitAllowFullScreen mozallowfullscreen allowFullScreen>
								</iframe>
							</div>
						<?php endif; ?>
					<?php endif; ?>
					<div class="slide-content">
						<!-- Post -->
						<article class="article" itemscope itemtype="http://schema.org/Article">
							<div class="post-content" itemprop="articleBody">
								<?php if ( ! empty( $slide['extra']['before_title'] ) ) : ?>
									<div class="post-meta">
										<span class="post-category"><?php echo( $slide['extra']['before_title'] ); ?></span>
									</div>
								<?php endif; ?>

								<h2 class="post-title">
									<a href="<?php echo esc_url( $slide['extra']['url'] ); ?>"><?php echo( $slide['title'] ); ?></a>
								</h2>

								<?php if ( ! empty( $slide['desc'] ) ) : ?>
									<div class="post-meta font2">
										<span class="post-author">
											<?php echo do_shortcode( $slide['desc'] ); ?>
										</span>
									</div>
								<?php endif; ?>
							</div>
						</article>
						<!--/ Post -->
					</div>
				</section>
			<?php endforeach; ?>
		</div>
		<a class="slider-control prev" href="#"><i class="icon icon-arrow-left"></i></a>
		<a class="slider-control next" href="#"><i class="icon icon-arrow-right"></i></a>
	</div>
<?php endif; ?>