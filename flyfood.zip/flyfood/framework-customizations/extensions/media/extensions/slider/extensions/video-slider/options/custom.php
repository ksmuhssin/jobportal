<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
	'before_title' => array(
		'label' => esc_html__( 'Before Title', 'flyfood' ),
		'desc'  => esc_html__( 'Insert the before title text', 'flyfood' ),
		'type'  => 'text',
	),
	'url'          => array(
		'label' => esc_html__( 'URL', 'flyfood' ),
		'desc'  => esc_html__( 'Insert the URL', 'flyfood' ),
		'type'  => 'text',
		'value' => '#',
	),
	'video_bg'     => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'attr'    => array( 'class' => 'fw-video-background-image' ),
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Video Background', 'flyfood' ),
				'type'         => 'switch',
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'value'        => 'no'
			),
		),
		'choices' => array(
			'yes' => array(
				'video_type' => array(
					'type'         => 'multi-picker',
					'label'        => false,
					'desc'         => false,
					'attr'         => array( 'class' => 'fw-video-background-image' ),
					'picker'       => array(
						'selected' => array(
							'label'   => esc_html__( 'Video Type', 'flyfood' ),
							'desc'    => esc_html__( 'Select the video type', 'flyfood' ),
							'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
							'type'    => 'radio',
							'choices' => array(
								'youtube'  => esc_html__( 'Youtube', 'flyfood' ),
								'vimeo'    => esc_html__( 'Vimeo', 'flyfood' ),
								'uploaded' => esc_html__( 'Upload', 'flyfood' ),
							),
							'value'   => 'youtube'
						),
					),
					'choices'      => array(
						'youtube'  => array(
							'video' => array(
								'label' => esc_html__( '', 'flyfood' ),
								'desc'  => esc_html__( 'Insert a YouTube video URL', 'flyfood' ),
								'type'  => 'text',
							),
						),
						'vimeo'    => array(
							'video' => array(
								'label' => esc_html__( '', 'flyfood' ),
								'desc'  => esc_html__( 'Insert a Vimeo video URL', 'flyfood' ),
								'type'  => 'text',
							),
						),
						'uploaded' => array(
							'video' => array(
								'label'       => esc_html__( '', 'flyfood' ),
								'desc'        => esc_html__( 'Upload a video', 'flyfood' ),
								'help'        => esc_html__( 'Upload a mp4 video', 'flyfood' ),
								'images_only' => false,
								'type'        => 'upload',
							),
						),
					),
					'show_borders' => false,
				),
			)
		)
	),
);