<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$cfg['population_methods'] = array( 'custom' );
$cfg['multimedia_types']   = array( 'image' );
