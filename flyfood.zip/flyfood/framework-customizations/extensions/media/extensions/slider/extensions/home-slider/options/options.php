<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id'       => array(
		'type' => 'unique'
	),
	'interval'        => array(
		'type'  => 'text',
		'label' => esc_html__( 'Interval', 'flyfood' ),
		'value' => '10000',
		'desc'  => esc_html__( 'Enter slider interval', 'flyfood' )
	),
	'enable_category' => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'type'         => 'switch',
				'value'        => 'yes',
				'label'        => esc_html__( 'Enable Category', 'flyfood' ),
				'desc'         => esc_html__( 'Enable the category?', 'flyfood' ),
				'help'         => esc_html__( 'This is available for all method except manually upload', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
			),
		),
		'choices' => array()
	),
	'enable_author'   => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'type'         => 'switch',
				'value'        => 'yes',
				'label'        => esc_html__( 'Enable Author', 'flyfood' ),
				'desc'         => esc_html__( 'Enable the author?', 'flyfood' ),
				'help'         => esc_html__( 'This is available for all method except manually upload', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
			),
		),
		'choices' => array()
	),
	'enable_comments' => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'type'         => 'switch',
				'value'        => 'yes',
				'label'        => esc_html__( 'Enable Comments', 'flyfood' ),
				'desc'         => esc_html__( 'Enable the comments?', 'flyfood' ),
				'help'         => esc_html__( 'This is available for all method except manually upload', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
			),
		),
		'choices' => array()
	),
);