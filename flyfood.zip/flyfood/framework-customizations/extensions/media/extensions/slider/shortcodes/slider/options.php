<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$choices = fw()->extensions->get( 'slider' )->get_populated_sliders_choices();

if ( ! empty( $choices ) ) {
	$options = array(
		'slider_id' => array(
			'type'    => 'select',
			'label'   => esc_html__( 'Select Slider', 'flyfood' ),
			'choices' => fw()->extensions->get( 'slider' )->get_populated_sliders_choices()
		),
	);
} else {
	$options = array(
		'no_sliders' => array(
			'type'  => 'html-full',
			'label' => false,
			'desc'  => false,
			'html'  => '<div style=""><h1 style="font-weight:100; text-align:center; margin-top:80px">' . esc_html__( 'No Sliders Available', 'flyfood' ) . '</h1>' . '<p style="text-align:center"><i>' . esc_html__( 'No Sliders created yet. Please go to the', 'flyfood' ) . ' <br/>' . esc_html__( 'Sliders page and', 'flyfood' ) . ' <a href="' . admin_url( 'post-new.php?post_type=' . fw()->extensions->get( 'slider' )->get_post_type() ) . '">' . esc_html__( 'create a new Slider', 'flyfood' ) . '</a> </i></p></div>'
		)
	);
}