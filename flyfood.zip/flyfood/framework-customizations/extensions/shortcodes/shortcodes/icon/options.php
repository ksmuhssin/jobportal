<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'icon'   => array(
		'type'  => 'icon',
		'label' => esc_html__( 'Icon', 'flyfood' )
	),
	'color'  => array(
		'type'  => 'color-picker',
		'label' => esc_html__( 'Color', 'flyfood' ),
		'desc'  => esc_html__( 'Select the icon color', 'flyfood' ),
	),
	'size'   => array(
		'type'  => 'short-text',
		'label' => esc_html__( 'Size', 'flyfood' ),
		'desc'  => esc_html__( 'Enter the icon size', 'flyfood' ),
	),
	'link'   => array(
		'type'  => 'text',
		'label' => esc_html__( 'Link', 'flyfood' ),
		'desc'  => esc_html__( 'Enter the link', 'flyfood' ),
	),
	'target' => array(
		'type'         => 'switch',
		'label'        => esc_html__( 'Target', 'flyfood' ),
		'desc'         => esc_html__( 'Open link in new window?', 'flyfood' ),
		'value'        => '_self',
		'right-choice' => array(
			'value' => '_blank',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
		'left-choice'  => array(
			'value' => '_self',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
	),
	'class'  => array(
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS.', 'flyfood' ),
		'type'  => 'text',
		'value' => '',
	),
);