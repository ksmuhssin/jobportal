<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'img'             => array(
		'type'  => 'upload',
		'value' => '',
		'label' => esc_html__( 'Header Image', 'flyfood' ),
		'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
	),
	'before_title'    => array(
		'type'  => 'text',
		'value' => '',
		'label' => esc_html__( 'Before title', 'flyfood' ),
		'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
	),
	'title'           => array(
		'type'  => 'text',
		'value' => '',
		'label' => esc_html__( 'Title', 'flyfood' ),
		'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
	),
	'desc'            => array(
		'type'  => 'textarea',
		'value' => '',
		'label' => esc_html__( 'Description', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
	),
	'enable_parallax' => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Parallax', 'flyfood' ),
		'desc'         => esc_html__( 'Enable the parallax effect.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'class'           => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);