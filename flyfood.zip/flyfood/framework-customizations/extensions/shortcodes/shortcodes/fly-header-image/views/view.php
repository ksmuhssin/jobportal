<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$img      = $atts['img'];
$bg_image = ( isset( $img['url'] ) && ! empty( $img['url'] ) ) ? 'style="background-image: url(' . esc_url( $img['url'] ) . ');"' : '';

$class = $atts['class'];
if ( $atts['enable_parallax'] == 'yes' ) {
	$class .= ' parallax';
}
?>
<div class="fly-header fly-header-image fly-header-image-sh full-height <?php echo esc_attr( $class ); ?>" <?php echo( $bg_image ); ?>>
	<div class="fly-header-content">
		<!-- Post -->
		<article class="article">
			<div class="post-content">
				<?php if ( ! empty( $atts['before_title'] ) ) : ?>
					<div class="post-meta">
						<span class="post-category"><?php echo( $atts['before_title'] ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $atts['title'] ) ) : ?>
					<h2 class="post-title"><?php echo( $atts['title'] ); ?></h2>
				<?php endif; ?>

				<?php if ( ! empty( $atts['desc'] ) ) : ?>
					<div class="post-meta font2">
						<span class="post-author"><?php echo do_shortcode( $atts['desc'] ); ?></span>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<!--/ Post -->
	</div>
</div>