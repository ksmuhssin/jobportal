<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

if ( empty( $atts['category'] ) ) {
	return;
}

$posts_per_page = $atts['posts_per_page'];

$the_query = new WP_Query( array(
	'posts_per_page' => $posts_per_page,
	'post_type'      => 'post',
	'tax_query'      => array(
		array(
			'taxonomy' => 'category',
			'field'    => 'id',
			'terms'    => $atts['category'],
		),
	),
) );

// posts display type
$flyfood_posts_view_type = $atts['posts_view_type'];
$flyfood_template_part   = 'list';
$flyfood_aditional_class = '';
if ( $flyfood_posts_view_type == 'grid' ) {
	$flyfood_template_part   = 'grid';
	$flyfood_aditional_class = 'postlist-masonry';
}

$extra_options                                          = array();
$extra_options['extra_options']['enable_post_author']   = $atts['enable_post_author'];
$extra_options['extra_options']['enable_post_date']     = $atts['enable_post_date'];
$extra_options['extra_options']['enable_post_comments'] = $atts['enable_post_comments'];
$extra_options['extra_options']['enable_post_likes']    = $atts['enable_post_likes'];
$extra_options['extra_options']['enable_post_share']    = $atts['enable_post_share'];
?>
<!-- PostList -->
<div class="fly-latest-posts-shortcode <?php echo esc_attr( $flyfood_aditional_class ); ?> <?php echo esc_attr( $atts['class'] ); ?>">
	<?php if ( $the_query->have_posts() ) :
		while ( $the_query->have_posts() ) : $the_query->the_post();
			echo fw_render_view( get_template_directory() . '/templates/blog/' . $flyfood_template_part . '.php', $extra_options );
		endwhile;
	else :
		// If no content, include the "No posts found" template.
		get_template_part( 'content', 'none' );
	endif;
	wp_reset_postdata(); ?>
</div>
<!--/ PostList -->