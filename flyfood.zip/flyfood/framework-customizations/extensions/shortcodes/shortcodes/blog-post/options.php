<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id'            => array(
		'type' => 'unique'
	),
	'category'             => array(
		'type'       => 'multi-select',
		'value'      => array(),
		'label'      => esc_html__( 'Blog Categories', 'flyfood' ),
		'desc'       => esc_html__( 'Select blog categeries by start typing category title', 'flyfood' ),
		/**
		 * Set population method
		 * Are available: 'posts', 'taxonomy', 'users', 'array'
		 */
		'population' => 'taxonomy',
		/**
		 * Set post types, taxonomies, user roles to search for
		 *
		 * 'population' => 'posts'
		 * 'source' => 'page',
		 *
		 * 'population' => 'taxonomy'
		 * 'source' => 'category',
		 *
		 * 'population' => 'users'
		 * 'source' => array( 'editor', 'subscriber', 'author' ),
		 *
		 * 'population' => 'array'
		 * 'source' => '' // will populate with 'choices' array
		 */
		'source'     => 'category',
		//'prepopulate' => 1,
		/**
		 * Set maximum items number that can be selected
		 */
		//'limit' => 1,
	),
	'posts_view_type'      => array(
		'type'    => 'short-select',
		'value'   => 'yes',
		'label'   => esc_html__( 'Posts View Type', 'flyfood' ),
		'desc'    => esc_html__( 'Select the posts view type', 'flyfood' ),
		'choices' => array(
			'list' => esc_html__( 'List', 'flyfood' ),
			'grid' => esc_html__( 'Grid', 'flyfood' ),
		),
	),
	'posts_per_page'       => array(
		'type'  => 'short-text',
		'value' => get_option( 'posts_per_page' ),
		'label' => esc_html__( 'Posts Per Page', 'flyfood' ),
		'desc'  => esc_html__( 'Posts per page to display', 'flyfood' )
	),
	'enable_post_author'   => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Author', 'flyfood' ),
		'desc'         => esc_html__( 'Enable posts author.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'enable_post_date'     => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Date', 'flyfood' ),
		'desc'         => esc_html__( 'Enable posts date.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'enable_post_comments' => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Comments', 'flyfood' ),
		'desc'         => esc_html__( 'Enable posts comments number.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'enable_post_likes'    => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Likes', 'flyfood' ),
		'desc'         => esc_html__( 'Enable posts likes.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'enable_post_share'    => array(
		'type'         => 'switch',
		'value'        => 'yes',
		'label'        => esc_html__( 'Enable Posts Share', 'flyfood' ),
		'desc'         => esc_html__( 'Enable posts share.', 'flyfood' ),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
	),
	'class'                => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);