<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id' => array(
				'type' => 'unique'
			),
			'icon_box'  => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'icon_type' => array(
						'label'   => esc_html__( 'Icon Type', 'flyfood' ),
						'desc'    => esc_html__( 'Choose icon type', 'flyfood' ),
						'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
						'type'    => 'radio',
						'value'   => 'awesome',
						'choices' => array(
							'awesome' => esc_html__( 'Font Awesome', 'flyfood' ),
							'custom'  => esc_html__( 'Custom Icon Class', 'flyfood' )
						)
					),
				),
				'choices' => array(
					'awesome' => array(
						'icon' => array(
							'type'  => 'icon',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose icon', 'flyfood' )
						),
					),
					'custom'  => array(
						'icon' => array(
							'type'  => 'text',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Add custom icon class', 'flyfood' )
						),
					)
				),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Title', 'flyfood' ),
			),
			'content'   => array(
				'type'  => 'wp-editor',
				'label' => esc_html__( 'Content', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the content', 'flyfood' )
			),
			'class'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'title_styling'   => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Title Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'content_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Content Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'icon_color'      => array(
				'type'  => 'color-picker',
				'label' => esc_html__( 'Icon Color', 'flyfood' ),
				'desc'  => esc_html__( 'Select the icon color', 'flyfood' )
			),
		)
	)
);