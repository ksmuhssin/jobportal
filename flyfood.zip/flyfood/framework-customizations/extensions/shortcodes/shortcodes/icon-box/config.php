<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Icon Box', 'flyfood' ),
	'description' => esc_html__( 'Add an Icon Box', 'flyfood' ),
	'tab'         => esc_html__( 'Content Elements', 'flyfood' )
);