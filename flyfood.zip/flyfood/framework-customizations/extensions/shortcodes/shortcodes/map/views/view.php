<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * @var $map_data_attr
 * @var $atts
 * @var $content
 * @var $tag
 */
$class = isset( $atts['class'] ) ? $atts['class'] : '';

if ( ! isset( $atts['map_pin'] ) || empty( $atts['map_pin'] ) ) {
	$map_data_attr['data-map-pin'] = json_encode( array( 'url' => flyfood_include_file_from_child( '/images/marker.png' ) ) );
} elseif ( isset( $atts['map_pin']['url'] ) ) {
	$map_data_attr['data-map-pin'] = json_encode( array( 'url' => $atts['map_pin']['url'] ) );
}

unset( $map_data_attr['data-class'] );
?>
<div class="wrap-map fw-map <?php echo esc_attr( $class ); ?>" <?php echo fw_attr_to_html( $map_data_attr ); ?>>
	<div class="fw-map-canvas map"></div>
</div>