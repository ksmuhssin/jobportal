<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$flyfood_template_directory = get_template_directory_uri();
$map_shortcode              = fw_ext( 'shortcodes' )->get_shortcode( 'map' );

$options = array(
	'unique_id'      => array(
		'type' => 'unique'
	),
	'location_group' => array(
		'type'    => 'group',
		'options' => array(
			'data_provider' => array(
				'type'         => 'multi-picker',
				'label'        => false,
				'desc'         => false,
				'picker'       => array(
					'population_method' => array(
						'label'   => esc_html__( 'Population Method', 'flyfood' ),
						'desc'    => esc_html__( 'Select map population method (Ex: events, custom)', 'flyfood' ),
						'type'    => 'select',
						'choices' => $map_shortcode->_get_picker_dropdown_choices(),
					)
				),
				'choices'      => $map_shortcode->_get_picker_choices(),
				'show_borders' => false,
			),
		)
	),
	'map_type'       => array(
		'label'   => esc_html__( 'Map Type', 'flyfood' ),
		'desc'    => esc_html__( 'Select map type', 'flyfood' ),
		'type'    => 'image-picker',
		'value'   => '',
		'choices' => array(
			'roadmap'   => array(
				'small' => array(
					'height' => 75,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-roadmap.jpg',
				),
				'large' => array(
					'height' => 208,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-roadmap.jpg'
				),
			),
			'terrain'   => array(
				'small' => array(
					'height' => 75,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-terrain.jpg',
				),
				'large' => array(
					'height' => 208,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-terrain.jpg'
				),
			),
			'satellite' => array(
				'small' => array(
					'height' => 75,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-satellite.jpg',
				),
				'large' => array(
					'height' => 208,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-satellite.jpg'
				),
			),
			'hybrid'    => array(
				'small' => array(
					'height' => 75,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-hybrid.jpg',
				),
				'large' => array(
					'height' => 208,
					'src'    => $flyfood_template_directory . '/images/image-picker/map-hybrid.jpg'
				),
			),
		),
	),
	'map_height'     => array(
		'label' => esc_html__( 'Map Height', 'flyfood' ),
		'desc'  => esc_html__( 'Enter the map height in pixels (Ex: 300)', 'flyfood' ),
		'type'  => 'short-text',
		'value' => '400',
	),
	'map_pin'        => array(
		'label' => esc_html__( 'Map Pin', 'flyfood' ),
		'desc'  => esc_html__( 'Upload a pin for your location(s) (64x64)', 'flyfood' ),
		'type'  => 'upload',
	),
	'map_zoom'       => array(
		'type'       => 'short-slider',
		'value'      => 15,
		'properties' => array(
			'min' => 0,
			'max' => 21,
			'sep' => 1,
		),
		'label'      => esc_html__( 'Map Zoom', 'flyfood' ),
		'desc'       => esc_html__( 'Select map zoom', 'flyfood' ),
	),
	'class'          => array(
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS in the <strong>custom.less</strong> file. This file is located on your server in the <strong>/child-theme/styles-less/</strong> folder.', 'flyfood' ),
		'type'  => 'text',
		'value' => '',
	),
);