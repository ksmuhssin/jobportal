<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id'       => array(
		'type' => 'unique'
	),
	'text'            => array(
		'type'  => 'wp-editor',
		'teeny' => true,
		'label' => esc_html__( 'Content', 'flyfood' ),
		'desc'  => esc_html__( 'Enter some content for this texblock', 'flyfood' )
	),
	'content_styling' => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'type'         => 'switch',
				'value'        => 'no',
				'label'        => esc_html__( 'Content Styling', 'flyfood' ),
				'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
			),
		),
		'choices' => array(
			'yes' => array(
				'font' => array(
					'type'  => 'typography-v2',
					'value' => array(
						'family'         => 'Arial',
						'size'           => 16,
						'line-height'    => 26,
						'letter-spacing' => 1,
						'color'          => ''
					),
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
				),
			),
			'no'  => array(),
		),
	),
	'class'           => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);
