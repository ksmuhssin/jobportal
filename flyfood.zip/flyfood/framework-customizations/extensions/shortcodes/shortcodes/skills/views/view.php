<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$skills = $atts['skills'];
if ( empty( $skills ) ) {
	return;
}
?>
<!-- Widget Skills -->
<div class="fly-skills <?php echo esc_attr( $atts['class'] ); ?> sh-<?php echo esc_attr( $atts['unique_id'] ); ?>">
	<?php if ( ! empty( $atts['title'] ) ): ?>
		<h4 class="title"><?php echo esc_html( $atts['title'] ); ?></h4>
	<?php endif; ?>
	<div class="widget-skills">
		<?php foreach ( $skills as $skill ) :
			if ( empty( $skill['content'] ) ) {
				continue;
			}
			$numb = (int) $skill['content'];
			?>
			<!-- Skill -->
			<div class="skill" data-percentage="<?php echo esc_attr( $numb ); ?>">
				<div class="skill-title"><?php echo esc_html( $skill['title'] ); ?></div>
				<div class="progress">
					<div class="progress-bar" style="width: <?php echo esc_attr( $numb ); ?>%;">
						<span class="skill-percentage"><?php echo esc_attr( $numb ); ?>%</span>
					</div>
				</div>
			</div>
			<!--/ Skill -->
		<?php endforeach; ?>
	</div>
</div>
<!--/ Widget Skills -->