<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id'   => array(
				'type' => 'unique'
			),
			'type'        => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'label'   => esc_html__( 'Type', 'flyfood' ),
						'desc'    => esc_html__( 'Choose button type', 'flyfood' ),
						'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
						'type'    => 'radio',
						'value'   => 'btn-fill',
						'choices' => array(
							'btn-fill'        => esc_html__( 'Fill', 'flyfood' ),
							'btn-transparent' => esc_html__( 'Transparent', 'flyfood' )
						)
					),
				),
				'choices' => array(
					'btn-fill'        => array(
						'bg_color' => array(
							'label' => esc_html__( 'BG Color', 'flyfood' ),
							'desc'  => esc_html__( 'Select the BG Color', 'flyfood' ),
							'type'  => 'color-picker',
							'value' => ''
						),
					),
					'btn-transparent' => array()
				)
			),
			'color_group' => array(
				'type'    => 'group',
				'options' => array(
					'label_color'       => array(
						'label' => esc_html__( 'Label Color', 'flyfood' ),
						'desc'  => esc_html__( 'Select the label color', 'flyfood' ),
						'type'  => 'color-picker',
						'value' => ''
					),
					'label_hover_color' => array(
						'label' => esc_html__( 'Label Hover Color', 'flyfood' ),
						'desc'  => esc_html__( 'Select the hover label color', 'flyfood' ),
						'type'  => 'color-picker',
						'value' => ''
					),
					'bg_hover_color'    => array(
						'label' => esc_html__( 'BG Hover Color', 'flyfood' ),
						'desc'  => esc_html__( 'Select the BG Hover Color', 'flyfood' ),
						'type'  => 'color-picker',
						'value' => ''
					),
				)
			),
			'label'       => array(
				'label' => esc_html__( 'Label', 'flyfood' ),
				'desc'  => esc_html__( 'This is the text that appears on your button', 'flyfood' ),
				'type'  => 'text',
				'value' => 'Submit'
			),
			'link'        => array(
				'label' => esc_html__( 'Link', 'flyfood' ),
				'desc'  => esc_html__( 'Where should your button link to?', 'flyfood' ),
				'type'  => 'text',
				'value' => '#'
			),
			'size'        => array(
				'label'   => esc_html__( 'Size', 'flyfood' ),
				'desc'    => esc_html__( 'Choose button size', 'flyfood' ),
				'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
				'type'    => 'radio',
				'value'   => 'btn-md',
				'choices' => array(
					'btn-sm' => esc_html__( 'Small', 'flyfood' ),
					'btn-md' => esc_html__( 'Medium', 'flyfood' ),
					'btn-lg' => esc_html__( 'Large', 'flyfood' ),
				)
			),
			'align'       => array(
				'label'   => esc_html__( 'Alignment', 'flyfood' ),
				'desc'    => esc_html__( 'Choose button alignment', 'flyfood' ),
				'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
				'type'    => 'radio',
				'value'   => 'none',
				'choices' => array(
					'none'        => esc_html__( 'None', 'flyfood' ),
					'text-left'   => esc_html__( 'Left', 'flyfood' ),
					'text-center' => esc_html__( 'Center', 'flyfood' ),
					'text-right'  => esc_html__( 'Right', 'flyfood' ),
				)
			),
			'round'       => array(
				'type'         => 'switch',
				'label'        => esc_html__( 'Round', 'flyfood' ),
				'desc'         => esc_html__( 'Make button round?', 'flyfood' ),
				'value'        => 'btn-no-round',
				'right-choice' => array(
					'value' => 'btn-round',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'left-choice'  => array(
					'value' => 'btn-no-round',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
			),
			'target'      => array(
				'type'         => 'switch',
				'label'        => esc_html__( 'Target', 'flyfood' ),
				'desc'         => esc_html__( 'Open link in new window?', 'flyfood' ),
				'value'        => '_self',
				'right-choice' => array(
					'value' => '_blank',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'left-choice'  => array(
					'value' => '_self',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
			),
			'class'       => array(
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS.', 'flyfood' ),
				'type'  => 'text',
				'value' => '',
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'label_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Label Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
		)
	)
);