<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

if ( empty( $atts['category'] ) ) {
	return;
}

$posts_per_page = (int) $atts['posts_per_page'];

$the_query = new WP_Query( array(
	'posts_per_page' => $posts_per_page,
	'post_type'      => 'post',
	'tax_query'      => array(
		array(
			'taxonomy' => 'category',
			'field'    => 'id',
			'terms'    => $atts['category'],
		),
	),
) );
?>
<!-- Posts Slider -->
<div class="fly-posts-carousel-shortcode related-posts <?php echo esc_attr( $atts['class'] ); ?>">
	<div class="owl-carousel related-posts-slider2">
		<?php if ( $the_query->have_posts() ) :
			while ( $the_query->have_posts() ) : $the_query->the_post();
				$post_id = get_the_ID(); ?>
				<div class="item">
					<!-- Post -->
					<article class="article" itemscope itemtype="http://schema.org/Article">
						<?php $thumbnail_id = get_post_thumbnail_id( $post_id ); ?>
						<?php if ( ! empty($thumbnail_id) ) : ?>
							<div class="post-media">
								<div class="text-center">
									<div class="position-relative inline-block">
										<img alt="<?php the_title(); ?>" src="<?php echo fw_resize( $thumbnail_id, 540, 300 ); ?>" itemprop="image"/>
										<div class="post-label"><i class="icon-photo"></i></div>
									</div>
								</div>
							</div>
						<?php endif; ?>

						<?php if ( $atts['enable_post_category'] == 'yes' ) : ?>
							<div class="post-meta">
								<?php flyfood_theme_get_one_post_category( $post_id ); ?>
							</div>
						<?php endif; ?>

						<h3 class="post-title"><a href="<?php the_permalink(); ?>"
												  itemprop="name"><?php the_title(); ?></a></h3>

						<div class="post-meta font2">
							<?php if ( $atts['enable_post_author'] == 'yes' ) : ?>
								<span class="post-author"
									  itemprop="author"><?php esc_html_e( 'written by', 'flyfood' ); ?> <a
											href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php echo esc_html( get_the_author() ); ?></a></span>
							<?php endif; ?>
							<?php if ( $atts['enable_post_date'] == 'yes' ) : ?>
								<a href="<?php the_permalink(); ?>"
								   class="post-date"><?php echo esc_html( get_the_date() ); ?></a>
							<?php endif; ?>
						</div>
					</article>
					<!--/ Post -->
				</div>
			<?php endwhile;
		else :
			// If no content, include the "No posts found" template.
			get_template_part( 'content', 'none' );
		endif;
		wp_reset_postdata(); ?>
	</div>
</div>
<!--/ Posts Slider -->