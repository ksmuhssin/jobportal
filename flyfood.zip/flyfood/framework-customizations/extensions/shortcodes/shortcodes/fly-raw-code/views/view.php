<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
?>
<div class="fly-raw-code">
	<?php echo do_shortcode( $atts['text'] ); ?>
</div>