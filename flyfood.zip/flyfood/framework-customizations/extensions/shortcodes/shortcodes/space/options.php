<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$template_directory = get_template_directory_uri();
$options            = array(
	'unique_id' => array(
		'type' => 'unique'
	),
	'height'    => array(
		'label'   => esc_html__( 'Height', 'flyfood' ),
		'desc'    => esc_html__( 'Select the space height in px', 'flyfood' ),
		'type'    => 'radio-text',
		'choices' => array(
			'space-sm' => esc_html__( 'Small', 'flyfood' ),
			'space-md' => esc_html__( 'Medium', 'flyfood' ),
			'space-lg' => esc_html__( 'Large', 'flyfood' ),
		),
		'value'   => 'space-md',
		'custom'  => 'custom_height',
	),
	'class'     => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);