<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Space', 'flyfood' ),
		'description' => esc_html__( 'Add a Space', 'flyfood' ),
		'tab'         => esc_html__( 'Content Elements', 'flyfood' ),
	)
);