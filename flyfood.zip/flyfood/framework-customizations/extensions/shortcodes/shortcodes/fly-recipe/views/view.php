<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
?>
<div class="fly-recipe sh-<?php echo esc_attr( $atts['unique_id'] ); ?> <?php echo esc_attr( $atts['class'] ); ?>">
	<?php if ( ! empty( $atts['title'] ) ) : ?>
		<h4 class="fly-recipe-title"><?php echo( $atts['title'] ); ?></h4>
	<?php endif; ?>

	<?php if ( ! empty( $atts['description'] ) ) : ?>
		<div class="fly-recipe-description"><?php echo do_shortcode( $atts['description'] ); ?></div>
	<?php endif; ?>

	<?php if ( ! empty( $atts['ingredients'] ) ) : ?>
		<div class="fly-recipe-ingredients">
			<?php esc_html_e( 'Ingredients:', 'flyfood' ); ?>
			<ul>
				<?php foreach ( $atts['ingredients'] as $item ) : ?>
					<li><?php echo( $item ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $atts['method'] ) ) : ?>
		<div class="fly-recipe-method"><?php echo do_shortcode( $atts['method'] ); ?></div>
	<?php endif; ?>
</div>