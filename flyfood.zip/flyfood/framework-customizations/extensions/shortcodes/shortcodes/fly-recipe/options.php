<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main' => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id'   => array(
				'type' => 'unique'
			),
			'title'       => array(
				'type'  => 'text',
				'value' => '',
				'label' => esc_html__( 'Title', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the title', 'flyfood' ),
			),
			'description' => array(
				'type'  => 'wp-editor',
				'value' => '',
				'label' => esc_html__( 'Description', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the description text', 'flyfood' ),
			),
			'ingredients' => array(
				'type'            => 'addable-option',
				'label'           => esc_html__( 'Ingredients', 'flyfood' ),
				'desc'            => esc_html__( 'Add/Edit Ingredient', 'flyfood' ),
				'option'          => array( 'type' => 'text' ),
				'add-button-text' => esc_html__( 'Add', 'flyfood' ),
				'sortable'        => true,
			),
			'method'      => array(
				'type'  => 'wp-editor',
				'value' => '',
				'label' => esc_html__( 'Method', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the method text', 'flyfood' ),
			),
			'class'       => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
);