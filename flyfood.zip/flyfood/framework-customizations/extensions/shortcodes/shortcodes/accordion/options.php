<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id' => array(
				'type' => 'unique'
			),
			'title'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Title', 'flyfood' ),
				'desc'  => esc_html__( 'Enter accordion title', 'flyfood' )
			),
			'accordion' => array(
				'type'          => 'addable-popup',
				'label'         => esc_html__( 'Accordion', 'flyfood' ),
				'popup-title'   => esc_html__( 'Add/Edit panel', 'flyfood' ),
				'desc'          => esc_html__( 'Add accordion panel', 'flyfood' ),
				'template'      => '{{=title}}',
				'popup-options' => array(
					'title'   => array(
						'type'  => 'text',
						'label' => esc_html__( 'Title', 'flyfood' ),
						'desc'  => esc_html__( 'Enter accordion panel title', 'flyfood' )
					),
					'content' => array(
						'type'  => 'wp-editor',
						'label' => esc_html__( 'Content', 'flyfood' ),
						'desc'  => esc_html__( 'Enter accordion panel content', 'flyfood' )
					)

				)
			),
			'class'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'title_styling'       => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'General Title Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'tab_title_styling'   => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Tab Title Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font'        => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
						'hover_color' => array(
							'type'  => 'color-picker',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the hover color', 'flyfood' ),
						),
					),
					'no'  => array(),
				),
			),
			'tab_content_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Tab Content Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
		)
	)
);