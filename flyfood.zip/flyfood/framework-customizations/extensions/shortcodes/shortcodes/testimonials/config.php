<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Testimonials', 'flyfood' ),
	'description' => esc_html__( 'Add some Testimonials', 'flyfood' ),
	'tab'         => esc_html__( 'Content Elements', 'flyfood' ),
);