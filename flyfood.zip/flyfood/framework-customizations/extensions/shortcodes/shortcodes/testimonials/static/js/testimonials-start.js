jQuery(document).ready(function ($) {
    jQuery('.fw-testimonials-list').each(function () {
        var testimonial_id = jQuery(this).attr('id');
        console.log(testimonial_id);
        jQuery('#' + testimonial_id).carouFredSel({
            swipe: {
                onTouch: true
            },
            next: "#" + testimonial_id + "-next",
            prev: "#" + testimonial_id + "-prev",
            pagination: "#" + testimonial_id + "-controls",
            responsive: true,
            infinite: false,
            items: 1,
            auto: false,
            scroll: {
                items: 1,
                fx: "crossfade",
                easing: "linear",
                duration: 300
            }
        });
    });
});