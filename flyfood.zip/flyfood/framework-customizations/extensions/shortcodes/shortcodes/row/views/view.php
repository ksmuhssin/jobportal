<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
} ?>

<div class="row">
	<?php echo do_shortcode( $content ); ?>
</div>

