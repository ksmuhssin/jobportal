<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Basic Information', 'flyfood' ),
		'description' => esc_html__( 'Add a basic information shortcode', 'flyfood' ),
		'tab'         => esc_html__( 'Content Elements', 'flyfood' ),
		'popup_size'  => 'medium',
	)
);
