<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
?>
<div class="fly-basic-information sh-<?php echo esc_attr( $atts['unique_id'] ); ?> <?php echo esc_attr( $atts['class'] ); ?>">
	<?php if ( ! empty( $atts['title'] ) ) : ?>
		<h4 class="title"><?php echo( $atts['title'] ); ?></h4>
	<?php endif; ?>
	<?php if ( ! empty( $atts['info_list'] ) ) : ?>
		<div class="widget-info">
			<ul>
				<?php foreach ( $atts['info_list'] as $item ) : ?>
					<li>
						<strong><?php echo( $item['label'] ); ?></strong>
						<span><?php echo( $item['text'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $atts['socials'] ) ) : ?>
		<ul class="post-social">
			<?php foreach ( $atts['socials'] as $item ) : ?>
				<li><a target="_blank" href="<?php echo esc_url( $item['social_link'] ); ?>"><i
								class="<?php echo esc_attr( $item['social_icon'] ); ?>"></i></a></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php if ( $atts['download_cv']['selected'] == 'yes' ) : ?>
		<div class="<?php echo esc_attr( $atts['download_cv']['yes']['align'] ); ?>"><a class="link"
																						href="<?php echo esc_url( $atts['download_cv']['yes']['url'] ); ?>"><?php echo( $atts['download_cv']['yes']['label'] ); ?></a>
		</div>
	<?php endif; ?>
</div>