<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id'   => array(
				'type' => 'unique'
			),
			'title'       => array(
				'type'  => 'text',
				'value' => '',
				'label' => esc_html__( 'Title', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the title', 'flyfood' ),
			),
			'info_list'   => array(
				'type'          => 'addable-popup',
				'label'         => esc_html__( 'Information List', 'flyfood' ),
				'popup-title'   => esc_html__( 'Add/Edit Information', 'flyfood' ),
				'desc'          => esc_html__( 'Create your information', 'flyfood' ),
				'template'      => '{{=label}}',
				'popup-options' => array(
					'label' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Info Label', 'flyfood' ),
					),
					'text'  => array(
						'type'  => 'textarea',
						'label' => esc_html__( 'Info Text', 'flyfood' ),
					),
				),
			),
			'socials'     => array(
				'type'          => 'addable-popup',
				'label'         => esc_html__( 'Social Links', 'flyfood' ),
				'desc'          => esc_html__( 'Add your social profiles', 'flyfood' ),
				'template'      => '{{=social_name}}',
				'popup-options' => array(
					'social_name' => array(
						'label' => esc_html__( 'Name', 'flyfood' ),
						'desc'  => esc_html__( 'Enter social name', 'flyfood' ),
						'type'  => 'text',
					),
					'social_icon' => array(
						'label' => esc_html__( 'Icon', 'flyfood' ),
						'desc'  => esc_html__( 'Select social icon', 'flyfood' ),
						'type'  => 'icon',
						'value' => 'fa fa-adn',
					),
					'social_link' => array(
						'label' => esc_html__( 'Link', 'flyfood' ),
						'desc'  => esc_html__( 'Enter your social URL link', 'flyfood' ),
						'type'  => 'text',
						'value' => '#',
					)
				),
			),
			'download_cv' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Download CV', 'flyfood' ),
						'desc'         => esc_html__( 'Enable the download CV link?', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'label' => array(
							'type'  => 'text',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Enter the link text', 'flyfood' ),
						),
						'url'   => array(
							'type'  => 'text',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Enter the link URL', 'flyfood' ),
						),
						'align' => array(
							'type'    => 'short-select',
							'value'   => 'text-left',
							'label'   => esc_html__( '', 'flyfood' ),
							'desc'    => esc_html__( 'Select the link alignment', 'flyfood' ),
							'choices' => array(
								'text-left'   => esc_html__( 'Left', 'flyfood' ),
								'text-center' => esc_html__( 'Center', 'flyfood' ),
								'text-right'  => esc_html__( 'Right', 'flyfood' ),
							),
						),
					),
					'no'  => array(),
				),
			),
			'class'       => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'title_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Title Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'label_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Label Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'text_styling'  => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Text Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'link_styling'  => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Link Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font'  => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
						'hover' => array(
							'type'  => 'color-picker',
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Select the hover color', 'flyfood' ),
						),
					),
					'no'  => array(),
				),
			),
		)
	)
);