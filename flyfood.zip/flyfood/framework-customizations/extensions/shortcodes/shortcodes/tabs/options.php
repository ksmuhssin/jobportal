<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id' => array(
				'type' => 'unique'
			),
			'tabs'      => array(
				'type'          => 'addable-popup',
				'label'         => esc_html__( 'Tabs', 'flyfood' ),
				'popup-title'   => esc_html__( 'Add/Edit Tab', 'flyfood' ),
				'desc'          => esc_html__( 'Create your tabs', 'flyfood' ),
				'template'      => '{{=tab_title}}',
				'popup-options' => array(
					'tab_title'   => array(
						'type'  => 'text',
						'label' => esc_html__( 'Title', 'flyfood' )
					),
					'icon_type'   => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'selected' => array(
								'label'   => esc_html__( 'Icon', 'flyfood' ),
								'desc'    => esc_html__( 'Select icon type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'icon_class',
								'choices' => array(
									'icon_class'  => esc_html__( 'Font Awesome', 'flyfood' ),
									'upload_icon' => esc_html__( 'Custom Upload', 'flyfood' ),
								),
							),
						),
						'choices' => array(
							'icon_class'  => array(
								'class' => array(
									'type'  => 'icon',
									'value' => '',
									'label' => '',
								),
							),
							'upload_icon' => array(
								'img' => array(
									'label' => '',
									'type'  => 'upload',
								),
							),
						)
					),
					'tab_content' => array(
						'type'  => 'wp-editor',
						'label' => esc_html__( 'Content', 'flyfood' )
					)
				),
			),
			'class'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'title_styling'   => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Title Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'content_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Content Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
		)
	)
);