<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main'     => array(
		'title'   => esc_html__( 'Main Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'unique_id' => array(
				'type' => 'unique'
			),
			'image'     => array(
				'label' => esc_html__( 'Image', 'flyfood' ),
				'desc'  => esc_html__( 'Upload an image', 'flyfood' ),
				'type'  => 'upload',
			),
			'name'      => array(
				'label' => esc_html__( 'Name', 'flyfood' ),
				'desc'  => esc_html__( 'Enter team member name', 'flyfood' ),
				'type'  => 'text',
			),
			'position'  => array(
				'label' => esc_html__( 'Position', 'flyfood' ),
				'desc'  => esc_html__( 'Enter team member position', 'flyfood' ),
				'type'  => 'text',
			),
			'text'      => array(
				'type'  => 'wp-editor',
				'teeny' => true,
				'label' => esc_html__( 'Content', 'flyfood' ),
				'desc'  => esc_html__( 'Enter the content', 'flyfood' )
			),
			'class'     => array(
				'type'  => 'text',
				'label' => esc_html__( 'Custom Class', 'flyfood' ),
				'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
				'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
			),
		)
	),
	'advanced' => array(
		'title'   => esc_html__( 'Advanced Options', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'name_styling'     => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Name Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'position_styling' => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Position Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'content_styling'  => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'label'        => esc_html__( 'Content Styling', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'font' => array(
							'type'  => 'typography-v2',
							'value' => array(
								'family'         => 'Arial',
								'size'           => 16,
								'line-height'    => 26,
								'letter-spacing' => 1,
								'color'          => ''
							),
							'label' => esc_html__( '', 'flyfood' ),
							'desc'  => esc_html__( 'Choose the custom font', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'border'           => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'selected' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Border', 'flyfood' ),
						'desc'         => esc_html__( 'Enable border to image?', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'border_width' => array(
							'type'  => 'short-text',
							'value' => '3',
							'label' => '',
							'desc'  => esc_html__( 'Enter the border width in pixels. Ex: 4', 'flyfood' ),
						),
						'border_color' => array(
							'type'  => 'color-picker',
							'label' => '',
							'desc'  => esc_html__( 'Select the border color', 'flyfood' ),
						),
					),
					'no'  => array(),
				),
			),
		)
	)
);