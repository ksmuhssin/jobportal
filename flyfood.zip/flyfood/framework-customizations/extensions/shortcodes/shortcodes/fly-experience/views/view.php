<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
?>
<div class="fly-experince sh-<?php echo esc_attr( $atts['unique_id'] ); ?> <?php echo esc_attr( $atts['class'] ); ?>">
	<?php if ( ! empty( $atts['title'] ) ) : ?>
		<h4 class="title"><?php echo( $atts['title'] ); ?></h4>
	<?php endif; ?>
	<?php if ( ! empty( $atts['experience_list'] ) ) : ?>
		<div class="widget-info style2">
			<ul>
				<?php foreach ( $atts['experience_list'] as $item ) : ?>
					<li>
						<strong><?php echo( $item['period'] ); ?></strong>
						<span><?php echo( $item['description'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
</div>