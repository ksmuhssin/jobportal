<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$bg_color = $atts['bg_color'];
$bg_image = $atts['bg_image'];
$class    = $atts['class'];

// full width
if ( $atts['is_fullwidth']['selected'] == 'yes' ) {
	$container_class = 'container-fluid';
} else {
	$container_class = 'container';
}

// first section in builder
if ( isset( $atts['first_in_builder'] ) && $atts['first_in_builder'] ) {
	$class .= ' section-header-styled';
}

// background color and image
$style = '';
if ( ! empty( $bg_image ) && ! empty( $bg_color ) ) {
	$style = 'background-image: url(' . esc_url( $bg_image['url'] ) . '); background-size:cover; background-color: ' . ( $bg_color ) . ';';
	$class .= ' section-text-white';
} elseif ( ! empty( $bg_image ) ) {
	$style = 'background-image: url(' . esc_url( $bg_image['url'] ) . ');';
	$class .= ' section-text-white';
} elseif ( ! empty( $bg_color ) ) {
	$style = 'background-color: ' . ( $bg_color ) . ';';
	$class .= ' section-text-white';
}

// section height
if ( $atts['height'] != 'auto' && $atts['height'] != 'section-height-sm' && $atts['height'] != 'section-height-md' && $atts['height'] != 'section-height-lg' ) {
	$height      = (int) $atts['height'];
	$data_height = 'height: ' . $height . 'px;';
	$class       .= ' section-height-custom';
} else {
	$class       .= ' ' . $atts['height'];
	$data_height = '';
}

// parallax
if ( $atts['parallax']['selected'] == 'yes' ) {
	$class .= ' parallax filter';
}

$link_id = '';
if ( ! empty( $atts['link_id'] ) ) {
	$link_id = 'id="' . $atts['link_id'] . '"';
}

if ( isset( $atts['video_bg']['selected'] ) && $atts['video_bg']['selected'] == 'yes' ) {
	$version = defined( 'FW' ) ? fw()->theme->manifest->get_version() : '1.0';
	wp_enqueue_script(
		'froogaloop2',
		'https://f.vimeocdn.com/js/froogaloop2.min.js',
		array(),
		$version,
		true
	);

	wp_enqueue_script(
		'flyfood-start-video',
		flyfood_include_file_from_child( '/js/start-video.js' ),
		array( 'jquery' ),
		$version,
		true
	);
}
?>
<section <?php echo( $link_id ); ?>
		class="section <?php echo esc_attr( $class ); ?> sh-<?php echo esc_attr( $atts['unique_id'] ); ?>" <?php echo 'style="' . $style . ' ' . $data_height . '"'; ?>>
	<?php if ( isset( $atts['video_bg']['selected'] ) && $atts['video_bg']['selected'] == 'yes' ) : ?>
		<?php if ( $atts['video_bg']['yes']['video_type']['selected'] == 'uploaded' && isset( $atts['video_bg']['yes']['video_type']['uploaded']['video']['url'] ) && ! empty( $atts['video_bg']['yes']['video_type']['uploaded']['video']['url'] ) ) : ?>
			<div class="video-container hidden-xs">
				<video autoplay loop muted width="1920" height="1080">
					<source src="<?php echo esc_url( $atts['video_bg']['yes']['video_type']['uploaded']['video']['url'] ); ?>" type='video/mp4; codecs="avc1.4D401E, mp4a.40.2"'/>
				</video>
			</div>
		<?php elseif ( $atts['video_bg']['yes']['video_type']['selected'] == 'vimeo' && isset( $atts['video_bg']['yes']['video_type']['vimeo']['video'] ) && ! empty( $atts['video_bg']['yes']['video_type']['vimeo']['video'] ) ) : ?>
			<div class="video-container hidden-xs">
				<?php $vimeo_id = (int) substr( parse_url( $atts['video_bg']['yes']['video_type']['vimeo']['video'], PHP_URL_PATH ), 1 ); ?>
				<<?php echo 'i'; ?>frame id="vimeo-<?php echo esc_attr( $vimeo_id ); ?>" class="video vimeo-video" src="//player.vimeo.com/video/<?php echo esc_attr( $vimeo_id ); ?>?api=1;title=0&amp;byline=0&amp;portrait=0&amp;color=d01e2f" width="500" height="281" webkitAllowFullScreen mozallowfullscreen allowFullScreen>
				</iframe>
			</div>
		<?php elseif ( $atts['video_bg']['yes']['video_type']['selected'] == 'youtube' && isset( $atts['video_bg']['yes']['video_type']['youtube']['video'] ) && ! empty( $atts['video_bg']['yes']['video_type']['youtube']['video'] ) ) : ?>
		<?php $youtube_id = flyfood_get_youtube_id( $atts['video_bg']['yes']['video_type']['youtube']['video'] ); ?>
			<div class="video-container hidden-xs">
				<div id="youtube-<?php echo esc_attr( $youtube_id ); ?>" data-id="<?php echo esc_attr( $youtube_id ); ?>" class="video youtube-video"></div>
			</div>
		<?php endif; ?>
	<?php endif; ?>
	<?php /* for section overlay */ ?>
	<?php if ( isset( $atts['overlay']['selected'] ) && $atts['overlay']['selected'] == 'yes' ) : ?>
		<?php if ( ! empty( $atts['overlay']['yes']['color'] ) ) : ?>
			<div class="fly-overlay" style="background-color: <?php echo( $atts['overlay']['yes']['color'] ); ?>"></div>
		<?php endif; ?>
	<?php endif; ?>
	<div class="<?php echo esc_attr( $container_class ); ?>">
		<?php echo do_shortcode( $content ); ?>
	</div>
</section>