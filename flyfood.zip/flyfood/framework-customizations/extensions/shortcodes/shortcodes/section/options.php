<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id'    => array(
		'type' => 'unique'
	),
	'section_name' => array(
		'label' => esc_html__( 'Section Name', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a name (it is for internal use and will not appear on the front end)', 'flyfood' ),
		'type'  => 'text',
	),
	'is_fullwidth' => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Full Width', 'flyfood' ),
				'type'         => 'switch',
				'desc'         => esc_html__( 'Make the content inside this section full width?', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'value'        => 'no',
			),
		),
		'choices' => array(),
	),
	'bg_color'     => array(
		'type'  => 'rgba-color-picker',
		'value' => '',
		'label' => esc_html__( 'Bg Color', 'flyfood' ),
		'desc'  => esc_html__( 'Choose section background color', 'flyfood' ),
	),
	'bg_image'     => array(
		'label' => esc_html__( 'Bg Image', 'flyfood' ),
		'desc'  => esc_html__( 'Upload section background image', 'flyfood' ),
		'type'  => 'upload',
		'value' => ''
	),
	'overlay'      => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Overlay', 'flyfood' ),
				'type'         => 'switch',
				'desc'         => esc_html__( 'Enable the overlay for this section?', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'value'        => 'no',
			),
		),
		'choices' => array(
			'yes' => array(
				'color' => array(
					'type'  => 'rgba-color-picker',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Choose the section overlay color', 'flyfood' ),
				),
			)
		),
	),
	'video_bg'     => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'attr'    => array( 'class' => 'fw-video-background-image' ),
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Video Background', 'flyfood' ),
				'type'         => 'switch',
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'value'        => 'no'
			),
		),
		'choices' => array(
			'yes' => array(
				'video_type' => array(
					'type'         => 'multi-picker',
					'label'        => false,
					'desc'         => false,
					'attr'         => array( 'class' => 'fw-video-background-image' ),
					'picker'       => array(
						'selected' => array(
							'label'   => esc_html__( '', 'flyfood' ),
							'desc'    => esc_html__( 'Select the video type', 'flyfood' ),
							'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
							'type'    => 'radio',
							'choices' => array(
								'youtube'  => esc_html__( 'Youtube', 'flyfood' ),
								'vimeo'    => esc_html__( 'Vimeo', 'flyfood' ),
								'uploaded' => esc_html__( 'Upload', 'flyfood' ),
							),
							'value'   => 'youtube'
						),
					),
					'choices'      => array(
						'youtube'  => array(
							'video' => array(
								'label' => esc_html__( '', 'flyfood' ),
								'desc'  => esc_html__( 'Insert a YouTube video URL', 'flyfood' ),
								'type'  => 'text',
							),
						),
						'vimeo'    => array(
							'video' => array(
								'label' => esc_html__( '', 'flyfood' ),
								'desc'  => esc_html__( 'Insert a Vimeo video URL', 'flyfood' ),
								'type'  => 'text',
							),
						),
						'uploaded' => array(
							'video' => array(
								'label'       => esc_html__( '', 'flyfood' ),
								'desc'        => esc_html__( 'Upload a video', 'flyfood' ),
								'images_only' => false,
								'type'        => 'upload',
							),
						),
					),
					'show_borders' => false,
				),
			)
		)
	),
	'height'       => array(
		'label'   => esc_html__( 'Height', 'flyfood' ),
		'desc'    => esc_html__( "Select the section's height in px (Ex: 400)", "flyfood" ),
		'type'    => 'radio-text',
		'value'   => 'auto',
		'choices' => array(
			'auto'              => esc_html__( 'auto', 'flyfood' ),
			'section-height-sm' => esc_html__( 'small', 'flyfood' ),
			'section-height-md' => esc_html__( 'medium', 'flyfood' ),
			'section-height-lg' => esc_html__( 'large', 'flyfood' ),
		),
		'custom'  => 'custom_height',
	),
	'parallax'     => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Parallax', 'flyfood' ),
				'type'         => 'switch',
				'desc'         => esc_html__( 'Enable the parallax effect?', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'value'        => 'no',
			),
		),
		'choices' => array(),
	),
	'border'       => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'selected' => array(
				'label'        => esc_html__( 'Border', 'flyfood' ),
				'type'         => 'switch',
				'desc'         => esc_html__( 'Enable the section border?', 'flyfood' ),
				'left-choice'  => array(
					'value' => 'no',
					'label' => esc_html__( 'No', 'flyfood' ),
				),
				'right-choice' => array(
					'value' => 'yes',
					'label' => esc_html__( 'Yes', 'flyfood' ),
				),
				'value'        => 'no',
			),
		),
		'choices' => array(
			'yes' => array(
				'width' => array(
					'type'  => 'short-text',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Enter the border width in pixels (Ex: 2)', 'flyfood' ),
					'value' => '1',
				),
				'color' => array(
					'type'  => 'color-picker',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Choose the border color', 'flyfood' ),
					'value' => '#f2f2f2',
				),
			)
		),
	),
	'link_id'      => array(
		'type'  => 'text',
		'label' => esc_html__( 'Link ID', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS ID for this section (Ex: example-id)', 'flyfood' ),
		'help'  => sprintf( "%s", esc_html__( 'Use this ID in any URL link in the page in order to anchor link to this section: (Ex: http://www.your-domain.com/#example-id)', 'flyfood' ) ),
		'value' => '',
	),
	'class'        => array(
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS.', 'flyfood' ),
		'type'  => 'text',
		'value' => '',
	),
);