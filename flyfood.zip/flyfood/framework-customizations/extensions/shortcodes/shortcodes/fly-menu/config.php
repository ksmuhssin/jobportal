<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Menu', 'flyfood' ),
		'description' => esc_html__( 'Add a menu shortcode', 'flyfood' ),
		'tab'         => esc_html__( 'Content Elements', 'flyfood' ),
	)
);
