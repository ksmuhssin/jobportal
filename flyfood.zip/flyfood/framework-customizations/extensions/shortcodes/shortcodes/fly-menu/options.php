<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id' => array(
		'type' => 'unique'
	),
	'menus'     => array(
		'type'          => 'addable-popup',
		'label'         => esc_html__( 'Menu', 'flyfood' ),
		'popup-title'   => esc_html__( 'Add/Edit Menu', 'flyfood' ),
		'desc'          => esc_html__( 'Create your menu', 'flyfood' ),
		'template'      => '{{=menu_title}}',
		'popup-options' => array(
			'img'        => array(
				'label' => esc_html__( 'Image', 'flyfood' ),
				'type'  => 'upload',
			),
			'menu_title' => array(
				'type'  => 'text',
				'label' => esc_html__( 'Title', 'flyfood' )
			),
			'price'      => array(
				'type'  => 'short-text',
				'label' => esc_html__( 'Price', 'flyfood' )
			),
			'content'    => array(
				'type'  => 'wp-editor',
				'label' => esc_html__( 'Content', 'flyfood' )
			)
		),
	),
	'class'     => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);
