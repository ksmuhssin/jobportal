<div class="section-menu fly-shortcode-menu sh-<?php echo esc_attr( $atts['unique_id'] ); ?> <?php echo esc_attr( $atts['class'] ); ?>">
	<?php if( !empty( $atts['menus'] ) ) : ?>
		<ul class="menu-items">
			<?php foreach ( $atts['menus'] as $item ) : ?>
				<li>
					<?php if( !empty( $item['img'] ) && isset( $item['img']['attachment_id'] ) ) : ?>
						<?php $image_alt = get_post_meta( $item['img']['attachment_id'], '_wp_attachment_image_alt', true); ?>
						<div class="image"><img src="<?php echo fw_resize( $item['img']['attachment_id'], 150, 150 ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" /></div>
					<?php endif; ?>

					<div class="item-header">
						<?php if( !empty( $item['price'] ) ) : ?>
							<div class="item-price"><?php echo ( $item['price'] ); ?></div>
						<?php endif; ?>
						<?php if( !empty( $item['menu_title'] ) ) : ?>
							<div class="item-title"><?php echo ( $item['menu_title'] ); ?></div>
						<?php endif; ?>
					</div>

					<?php if( !empty( $item['content'] ) ) : ?>
						<div class="item-description">
							<?php echo do_shortcode( $item['content'] ); ?>
						</div>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>