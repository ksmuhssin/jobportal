<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'unique_id'      => array(
		'type' => 'unique'
	),
	'category'       => array(
		'type'    => 'select',
		'value'   => '',
		'label'   => esc_html__( 'Portfolio Category', 'flyfood' ),
		'desc'    => esc_html__( 'Select portfolio category to get posts from', 'flyfood' ),
		'choices' => flyfood_theme_list_portfolios(),
	),
	'filter'         => array(
		'type'         => 'switch',
		'label'        => esc_html__( 'Top Filter', 'flyfood' ),
		'desc'         => esc_html__( 'Enable top filter?', 'flyfood' ),
		'value'        => 'yes',
		'right-choice' => array(
			'value' => 'yes',
			'label' => esc_html__( 'Yes', 'flyfood' ),
		),
		'left-choice'  => array(
			'value' => 'no',
			'label' => esc_html__( 'No', 'flyfood' ),
		),
	),
	'columns'        => array(
		'label'   => esc_html__( 'Columns', 'flyfood' ),
		'desc'    => esc_html__( 'Choose the number of columns', 'flyfood' ),
		'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
		'type'    => 'radio',
		'value'   => '2',
		'choices' => array(
			'2'       => esc_html__( '2 Columns', 'flyfood' ),
			'3'       => esc_html__( '3 Columns', 'flyfood' ),
			'4'       => esc_html__( '4 Columns', 'flyfood' ),
			'masonry' => esc_html__( 'Masonry', 'flyfood' ),
		)
	),
	'posts_per_page' => array(
		'type'  => 'text',
		'value' => '12',
		'label' => esc_html__( 'Posts Per Page', 'flyfood' ),
		'desc'  => esc_html__( 'Posts per page to display', 'flyfood' )
	),
	'class'          => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);