<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$taxonomy = 'fw-portfolio-category';
$term     = get_term( $atts['category'], $taxonomy );
$cat_id   = $atts['category'];
if ( ! empty( $term ) && ! is_wp_error( $term ) ) {
	if ( $term->parent == 0 ) {
		$cat_id = $atts['category'];
	} else {
		$cat_id = $term->parent;
	}
}

$the_query = new WP_Query( array(
	'posts_per_page' => $atts['posts_per_page'],
	'post_type'      => 'fw-portfolio',
	'tax_query'      => array(
		array(
			'taxonomy' => $taxonomy,
			'field'    => 'id',
			'terms'    => array( $cat_id ),
		),
	),
) );

$ext_portfolio_instance = fw()->extensions->get( 'portfolio' );
$ext_portfolio_settings = $ext_portfolio_instance->get_settings();

if ( $atts['columns'] == '3' ) {
	$portfolio_class = 'columns3';
	$data_ratio      = '4/3';
} elseif ( $atts['columns'] == '4' ) {
	$portfolio_class = 'columns4';
	$data_ratio      = '1/1';
} elseif ( $atts['columns'] == 'masonry' ) {
	$portfolio_class = '';
	$data_ratio      = '1/1';
} else {
	$portfolio_class = 'columns2';
	$data_ratio      = '16/9';
}

flyfood_theme_portfolio_filter( $atts['filter'], false, $atts['category'] );
?>
<!-- Portfolio Items -->
<div class="fly-portfolio-shortcode portfolio <?php echo esc_attr( $atts['class'] ); ?> <?php echo esc_attr( $portfolio_class ); ?>">
	<ul class="portfolio-items" data-ratio="<?php echo esc_attr( $data_ratio ); ?>">
		<?php if ( $the_query->have_posts() ) :
			while ( $the_query->have_posts() ) : $the_query->the_post();
				$post_id = get_the_ID();

				// item class (used for masonry style)
				$flyfood_item_class = '';
				if ( $atts['columns'] == 'masonry' ) {
					$portfolio_class = '';
					$data_ratio      = '1/1';
					// item class (used for masonry style)
					$flyfood_item_class .= ' ' . fw_get_db_post_option( $post_id, 'image_width', 'default-width' );
					$flyfood_item_class .= ' ' . fw_get_db_post_option( $post_id, 'image_height', 'default-height' );
				}

				$flyfood_thumbnail_id = get_post_thumbnail_id();
				if ( ! empty( $flyfood_thumbnail_id ) ) {
					$flyfood_featured_image  = wp_get_attachment_image_src( $flyfood_thumbnail_id, 'full' );
					$flyfood_thumbnail       = get_post( $flyfood_thumbnail_id );
					$flyfood_image           = $flyfood_featured_image[0];
					$flyfood_thumbnail_title = $flyfood_thumbnail->post_title;
				} else {
					$flyfood_image           = fw()->extensions->get( 'portfolio' )->locate_URI( '/static/img/no-photo.jpg' );
					$flyfood_thumbnail_title = get_the_title();
				}

				$flyfood_data_category = 'data-category="' . flyfood_theme_portfolio_post_taxonomies( $post_id, true ) . '"';
				?>
				<li class="portfolio-item <?php echo esc_attr( $flyfood_item_class ); ?>" <?php echo( $flyfood_data_category ); ?>>
					<a href="<?php echo esc_url( get_permalink() ); ?>" class="item-link js-action-delay">
						<span class="item-image"
							  style="background-image: url(<?php echo esc_url( $flyfood_image ); ?>);"></span>

						<div class="item-hover">
							<div class="item-inner">
								<h4 class="item-title"><?php the_title(); ?></h4>
								<div class="item-description"><?php esc_html_e( 'in', 'flyfood' ); ?><?php flyfood_theme_portfolio_post_terms( $post_id ); ?></div>
							</div>
						</div>
					</a>
				</li>
			<?php endwhile; ?>
		<?php else :
			// If no content, include the "No posts found" template.
			get_template_part( 'content', 'none' );
		endif;
		wp_reset_postdata(); ?>
	</ul>
</div>
<!--/ Portfolio Items -->