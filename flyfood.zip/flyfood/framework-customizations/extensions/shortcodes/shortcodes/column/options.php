<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}


$options = array(
	'unique_id' => array(
		'type' => 'unique'
	),
	'tablet'    => array(
		'label'   => esc_html__( 'Tablet Display', 'flyfood' ),
		'desc'    => esc_html__( 'Choose the responsive tablet display for this column', 'flyfood' ),
		'help'    => esc_html__( 'Use this option in order to control how this column behaves on devices with the resolution between 768px - 991px (tablet portrait). Note that on phones all the columns are 1/1 by default.', 'flyfood' ),
		'type'    => 'select',
		'value'   => '',
		'choices' => array(
			'same'       => esc_html__( 'Automatically inherit default layout', 'flyfood' ),
			'col-sm-2'   => esc_html__( 'Make it a 1/6 column', 'flyfood' ),
			'col-sm-1-5' => esc_html__( 'Make it a 1/5 column', 'flyfood' ),
			'col-sm-3'   => esc_html__( 'Make it a 1/4 column', 'flyfood' ),
			'col-sm-4'   => esc_html__( 'Make it a 1/3 column', 'flyfood' ),
			'col-sm-6'   => esc_html__( 'Make it a 1/2 column', 'flyfood' ),
			'col-sm-8'   => esc_html__( 'Make it a 2/3 column', 'flyfood' ),
			'col-sm-9'   => esc_html__( 'Make it a 3/4 column', 'flyfood' ),
			'col-sm-12'  => esc_html__( 'Make it a 1/1 column', 'flyfood' ),
		)
	),
	'bg_color'  => array(
		'type'  => 'rgba-color-picker',
		'value' => '',
		'label' => esc_html__( 'Bg Color', 'flyfood' ),
		'desc'  => esc_html__( 'Choose column background color', 'flyfood' ),
	),
	'bg_image'  => array(
		'label' => esc_html__( 'Bg Image', 'flyfood' ),
		'desc'  => esc_html__( 'Upload column background image', 'flyfood' ),
		'type'  => 'upload',
		'value' => ''
	),
	'align'     => array(
		'label'   => esc_html__( 'Alignment', 'flyfood' ),
		'desc'    => esc_html__( 'Choose the text alignment', 'flyfood' ),
		'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
		'type'    => 'radio',
		'value'   => 'none',
		'choices' => array(
			'none'        => esc_html__( 'None', 'flyfood' ),
			'text-left'   => esc_html__( 'Left', 'flyfood' ),
			'text-center' => esc_html__( 'Center', 'flyfood' ),
			'text-right'  => esc_html__( 'Right', 'flyfood' ),
		)
	),
	'margin'    => array(
		'type'  => 'text',
		'label' => esc_html__( 'Margin', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom margin. Ex: 15px or 10px 15px 10px 20px', 'flyfood' ),
	),
	'class'     => array(
		'type'  => 'text',
		'label' => esc_html__( 'Custom Class', 'flyfood' ),
		'desc'  => esc_html__( 'Enter a custom CSS class', 'flyfood' ),
		'help'  => esc_html__( 'You can use this class to further style this shortcode by adding your custom CSS', 'flyfood' ),
	),
);