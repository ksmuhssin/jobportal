<?php
get_header();

$flyfood_ext_portfolio_instance = fw()->extensions->get( 'portfolio' );
$flyfood_ext_portfolio_settings = $flyfood_ext_portfolio_instance->get_settings();

$flyfood_filter_enabled = fw_get_db_settings_option( 'filter', 'yes' );
$flyfood_columns        = fw_get_db_settings_option( 'columns', '2' );

if ( $flyfood_columns == '3' ) {
	$portfolio_class = 'columns3';
	$data_ratio      = '4/3';
} elseif ( $flyfood_columns == '4' ) {
	$portfolio_class = 'columns4';
	$data_ratio      = '1/1';
} elseif ( $flyfood_columns == 'masonry' ) {
	$portfolio_class = '';
	$data_ratio      = '1/1';
} else {
	$portfolio_class = 'columns2';
	$data_ratio      = '16/9';
}

$flyfood_taxonomy   = $flyfood_ext_portfolio_settings['taxonomy_name'];
$flyfood_term       = get_term_by( 'slug', get_query_var( 'term' ), $flyfood_taxonomy );
$flyfood_term_id    = ( ! empty( $flyfood_term->term_id ) ) ? $flyfood_term->term_id : 0;
$flyfood_categories = fw_ext_portfolio_get_listing_categories( $flyfood_term_id, $flyfood_taxonomy );
$flyfood_loop_data  = array(
	'settings'        => $flyfood_ext_portfolio_settings,
	'categories'      => $flyfood_categories,
	'listing_classes' => 'fw-portfolio-item',
	'columns'         => $flyfood_columns,
);
set_query_var( 'fw_portfolio_loop_data', $flyfood_loop_data );

flyfood_theme_header_image();
?>
	<div class="page-wrapper">
		<div class="container">
			<div class="row">
				<!-- Content -->
				<main class="content">
					<?php if ( isset( $flyfood_term->description ) && ! empty( $flyfood_term->description ) ) : ?>
						<h1 class="page-title"><?php echo esc_attr( $flyfood_term->description ); ?></h1>
					<?php endif; ?>
					<?php flyfood_theme_portfolio_filter( $flyfood_filter_enabled, true ); ?>
					<!-- Portfolio Items -->
					<section class="portfolio <?php echo esc_attr( $portfolio_class ); ?>">
						<ul class="portfolio-items" data-ratio="<?php echo esc_attr( $data_ratio ); ?>">
							<!-- data-ratio is portfolio images ratio, default is 4/3 -->
							<?php if ( have_posts() ) :
								while ( have_posts() ) : the_post();
									get_template_part( 'framework-customizations/extensions' . $flyfood_ext_portfolio_instance->get_rel_path() . '/views/loop', 'projects' );
								endwhile;
							else :
								// If no content, include the "No posts found" template.
								get_template_part( 'content', 'none' );
							endif; ?>
						</ul>
					</section>
					<?php echo flyfood_theme_pagination(); ?>
				</main><!--/ content -->
			</div><!--/ row -->
		</div><!--/ container -->
	</div><!--/ page-wrapper -->
<?php
// free memory
unset( $flyfood_ext_portfolio_instance );
unset( $flyfood_ext_portfolio_settings );
set_query_var( 'fw_portfolio_loop_data', '' );
get_footer();