<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$post_id              = get_the_ID();
$flyfood_loop_data    = get_query_var( 'fw_portfolio_loop_data' );
$flyfood_thumbnail_id = get_post_thumbnail_id();

if ( ! empty( $flyfood_thumbnail_id ) ) {
	$flyfood_featured_image  = wp_get_attachment_image_src( $flyfood_thumbnail_id, 'full' );
	$flyfood_image           = $flyfood_featured_image[0];
	$flyfood_thumbnail       = get_post( $flyfood_thumbnail_id );
	$flyfood_thumbnail_title = $flyfood_thumbnail->post_title;
} else {
	$flyfood_image           = fw()->extensions->get( 'portfolio' )->locate_URI( '/static/img/no-photo.jpg' );
	$flyfood_thumbnail_title = get_the_title();
}

// item class (used for masonry style)
$flyfood_item_class = '';
if ( $flyfood_loop_data['columns'] == 'masonry' ) {
	$flyfood_item_class .= ' ' . fw_get_db_post_option( $post_id, 'image_width', 'default-width' );
	$flyfood_item_class .= ' ' . fw_get_db_post_option( $post_id, 'image_height', 'default-height' );
}

$flyfood_data_category = ( is_tax() ) ? '' : 'data-category="' . flyfood_theme_portfolio_post_taxonomies( $post_id, true ) . '"';
?>
<li class="portfolio-item <?php echo esc_attr( $flyfood_item_class ); ?>" <?php echo( $flyfood_data_category ); ?>>
	<a href="<?php echo esc_url( get_permalink() ); ?>" class="item-link js-action-delay">
		<span class="item-image" style="background-image: url(<?php echo esc_url( $flyfood_image ); ?>);"></span>

		<div class="item-hover">
			<div class="item-inner">
				<h4 class="item-title"><?php the_title(); ?></h4>
				<div class="item-description"><?php esc_html_e( 'in', 'flyfood' ); ?><?php flyfood_theme_portfolio_post_terms( $post_id ); ?></div>
			</div>
		</div>
	</a>
</li>