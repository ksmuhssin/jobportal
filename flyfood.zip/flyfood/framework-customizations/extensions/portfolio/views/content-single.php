<?php
/**
 * The default template for displaying project post details
 */

// portfolio post general settings
$flyfood_post_share      = fw_get_db_settings_option( 'enable_portfolio_share', 'yes' );
$flyfood_post_pagination = fw_get_db_settings_option( 'enable_portfolio_pagination', 'yes' );
$flyfood_post_author_box = fw_get_db_settings_option( 'enable_portfolio_author_box', 'yes' );
$flyfood_post_categories = fw_get_db_settings_option( 'enable_portfolio_categories', 'yes' );
$flyfood_related_posts   = fw_get_db_settings_option( 'enable_portfolio_related', 'yes' );

// portfolio post specific settings
$flyfood_thumbnails      = flyfood_theme_ext_portfolio_get_gallery_images();
$flyfood_additional_info = fw_get_db_post_option( $post->ID, 'additional_info' );
?>
	<!-- Post -->
	<article class="article" itemscope itemtype="http://schema.org/Article">
		<?php if ( ! empty( $flyfood_thumbnails ) ) : ?>
			<div class="post-media">
				<!-- Thumbnail Slider -->
				<div class="thumbnail-slider clearfix" data-height="400">
					<div class="slider-images-wrap">
						<ul class="slider-images">
							<?php $flyfood_slider_thumbs = ''; ?>
							<?php foreach ( $flyfood_thumbnails as $item ) : ?>
								<?php $flyfood_attachment_metadata = get_post( $item['attachment_id'] ); ?>
								<li style="background-image: url(<?php echo esc_url( $item['url'] ); ?>)">
									<a class="swipebox overlay" data-rel="gallery-<?php echo esc_attr( $post->ID ); ?>"
									   href="<?php echo esc_url( $item['url'] ); ?>"
									   title="<?php echo( $flyfood_attachment_metadata->post_title ); ?>"></a>

									<div class="description">
										<h4 class="title">
											<span><?php echo( $flyfood_attachment_metadata->post_title ); ?></span></h4>
										<?php if ( ! empty( $flyfood_attachment_metadata->post_content ) ) : ?>
											<div class="subtitle">
												<span><?php echo( $flyfood_attachment_metadata->post_content ); ?></span>
											</div>
										<?php endif; ?>
										<a href="#" class="description-close fa fa-times"></a>
									</div>
								</li>
								<?php $flyfood_slider_thumbs .= '<li style="background-image: url(' . esc_url( $item['url'] ) . ')"></li>'; ?>
							<?php endforeach; ?>
						</ul>

						<a href="#" class="prev icon-arrow-left"></a>
						<a href="#" class="next icon-arrow-right"></a>
					</div>

					<div class="slider-thumbs-wrap">
						<ul class="slider-thumbs">
							<?php echo( $flyfood_slider_thumbs ); ?>
						</ul>
						<a href="#" class="prev icon-arrow-up"></a>
						<a href="#" class="next icon-arrow-down"></a>
					</div>

					<a class="description-open fa fa-info-circle active" href="#"></a>
				</div>
				<!--/ Thumbnail Slider -->
			</div>
		<?php endif; ?>

		<div class="post-content" itemprop="articleBody">
			<?php if ( $flyfood_additional_info['selected'] == 'yes' ) : ?>
				<div class="project-info row">
					<?php if ( ! empty( $flyfood_additional_info['yes']['client'] ) ) : ?>
						<div class="item col-sm-6 col-lg-3">
							<strong><?php esc_html_e( 'Client', 'flyfood' ); ?></strong>
							<span><?php echo( $flyfood_additional_info['yes']['client'] ); ?></span>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $flyfood_additional_info['yes']['production_date'] ) ) : ?>
						<div class="item col-sm-6 col-lg-3">
							<strong><?php esc_html_e( 'Production Date', 'flyfood' ); ?></strong>
							<span><?php echo( $flyfood_additional_info['yes']['production_date'] ); ?></span>
						</div>
					<?php endif; ?>

					<?php if ( ! empty( $flyfood_additional_info['yes']['skills'] ) ) : ?>
						<div class="item col-sm-6 col-lg-3">
							<strong><?php esc_html_e( 'Used Skills', 'flyfood' ); ?></strong>
							<span><?php echo( $flyfood_additional_info['yes']['skills'] ); ?></span>
						</div>
					<?php endif; ?>

					<?php if ( $flyfood_post_categories == 'yes' ) : ?>
						<div class="item col-sm-6 col-lg-3">
							<strong><?php esc_html_e( 'Categories', 'flyfood' ); ?></strong>
							<span>
							<?php echo flyfood_get_portfolio_categories( ', ' ); ?>
						</span>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<h1 class="portfolio-title" itemprop="name"><?php the_title(); ?></h1>

			<?php the_content();
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'flyfood' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
			) ); ?>
		</div>

		<?php if ( $flyfood_post_share == 'yes' ): ?>
			<div class="post-bottom clearfix">
				<div class="post-taglist"></div>
				<div class="row">
					<div class="col-sm-6">
						<?php flyfood_theme_share_post(); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</article>
	<!--/ Post -->

<?php if ( $flyfood_post_author_box == 'yes' ) : ?>
	<?php get_template_part( 'content', 'author' ); ?>
<?php endif; ?>

<?php if ( $flyfood_related_posts == 'yes' ) :
	get_template_part( 'framework-customizations/extensions' . fw()->extensions->get( 'portfolio' )->get_rel_path() . '/views/related-projects' );
endif; ?>

<?php if ( $flyfood_post_pagination == 'yes' ) : ?>
	<div class="pager">
		<?php previous_post_link( '%link', '<i class="icon-arrow-left"></i>' . esc_html__( 'Previous Story', 'flyfood' ) . '<br /><span>%title</span>' ); ?>
		<?php next_post_link( '%link', esc_html__( 'Next Story', 'flyfood' ) . '<i class="icon-arrow-right"></i><br /><span>%title</span>' ); ?>
	</div>
<?php endif;