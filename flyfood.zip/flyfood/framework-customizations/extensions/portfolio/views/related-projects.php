<?php
$flyfood_related_posts    = flyfood_related_projects();
$flyfood_sidebar_position = function_exists( 'fw_ext_sidebars_get_current_position' ) ? fw_ext_sidebars_get_current_position() : 'right';

if ( ! empty( $flyfood_related_posts ) ) : ?>
	<!-- Related Posts -->
	<div class="related-posts">
		<h4 class="title"><?php esc_html_e( 'Related Projects', 'flyfood' ); ?></h4>

		<div class="related-posts-slider">
			<?php foreach ( $flyfood_related_posts as $item ) : ?>
				<div class="item">
					<article class="article" itemscope itemtype="http://schema.org/Article">
						<?php $thumbnail_id = get_post_thumbnail_id( $item->ID ); ?>
						<?php if ( ! empty($thumbnail_id) ) : ?>
							<div class="post-media">
								<div class="text-center">
									<div class="position-relative inline-block">
										<img alt="<?php the_title(); ?>" src="<?php echo fw_resize( $thumbnail_id, 540, 300 ); ?>" itemprop="image"/>
										<div class="post-label"><i class="icon-photo"></i></div>
									</div>
								</div>
							</div>
						<?php endif; ?>

						<div class="post-meta">
							<?php flyfood_theme_get_one_post_category( $item->ID ); ?>
						</div>

						<h3 class="post-title"><a href="<?php echo esc_url( get_permalink( $item->ID ) ); ?>" itemprop="name"><?php echo( $item->post_title ); ?></a></h3>
					</article>
				</div><!--/ item -->
			<?php endforeach; ?>
			<?php wp_reset_postdata(); ?>
		</div><!--/ related-posts-slider -->
	</div><!--/ related-posts -->
<?php endif;