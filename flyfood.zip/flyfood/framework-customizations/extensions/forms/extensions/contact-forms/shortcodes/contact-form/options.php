<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main' => array(
		'type'    => 'box',
		'title'   => '',
		'options' => array(
			'id'       => array(
				'type' => 'unique',
			),
			'builder'  => array(
				'type'    => 'tab',
				'title'   => esc_html__( 'Form Fields', 'flyfood' ),
				'options' => array(
					'form' => array(
						'label'        => false,
						'type'         => 'form-builder',
						'value'        => array(
							'json' => apply_filters( 'fw:ext:forms:builder:load-item:form-header-title', true )
								? json_encode( array(
									array(
										'type'      => 'form-header-title',
										'shortcode' => 'form_header_title',
										'width'     => '',
										'options'   => array(
											'title'    => '',
											'subtitle' => '',
										)
									)
								) )
								: '[]'
						),
						'fixed_header' => true,
					),
				),
			),
			'settings' => array(
				'type'    => 'tab',
				'title'   => esc_html__( 'Settings', 'flyfood' ),
				'options' => array(
					'settings-options' => array(
						'title'   => esc_html__( 'Options', 'flyfood' ),
						'type'    => 'tab',
						'options' => array(
							'form_email_settings' => array(
								'type'    => 'group',
								'options' => array(
									'email_to' => array(
										'type'  => 'text',
										'label' => esc_html__( 'Email To', 'flyfood' ),
										'help'  => esc_html__( 'We recommend you to use an email that you verify often', 'flyfood' ),
										'desc'  => esc_html__( 'The form will be sent to this email address.', 'flyfood' ),
									),
								),
							),
							'form_text_settings'  => array(
								'type'    => 'group',
								'options' => array(
									'subject-group'       => array(
										'type'    => 'group',
										'options' => array(
											'subject_message' => array(
												'type'  => 'text',
												'label' => esc_html__( 'Subject Message', 'flyfood' ),
												'desc'  => esc_html__( 'This text will be used as subject message for the email', 'flyfood' ),
												'value' => esc_html__( 'Contact Form', 'flyfood' ),
											),
										)
									),
									'submit-button-group' => array(
										'type'    => 'group',
										'options' => array(
											'submit_button_text' => array(
												'type'  => 'text',
												'label' => esc_html__( 'Submit Button', 'flyfood' ),
												'desc'  => esc_html__( 'This text will appear in submit button', 'flyfood' ),
												'value' => esc_html__( 'Send', 'flyfood' ),
											),
										)
									),
									'success-group'       => array(
										'type'    => 'group',
										'options' => array(
											'success_message' => array(
												'type'  => 'text',
												'label' => esc_html__( 'Success Message', 'flyfood' ),
												'desc'  => esc_html__( 'This text will be displayed when the form will successfully send', 'flyfood' ),
												'value' => esc_html__( 'Message sent!', 'flyfood' ),
											),
										)
									),
									'failure_message'     => array(
										'type'  => 'text',
										'label' => esc_html__( 'Failure Message', 'flyfood' ),
										'desc'  => esc_html__( 'This text will be displayed when the form will fail to be sent', 'flyfood' ),
										'value' => esc_html__( 'Oops something went wrong.', 'flyfood' ),
									),
								),
							),
						)
					),
					'mailer-options'   => array(
						'title'   => esc_html__( 'Mailer', 'flyfood' ),
						'type'    => 'tab',
						'options' => array(
							'mailer' => array(
								'label' => false,
								'type'  => 'mailer'
							)
						)
					)
				),
			),
		),
	)
);