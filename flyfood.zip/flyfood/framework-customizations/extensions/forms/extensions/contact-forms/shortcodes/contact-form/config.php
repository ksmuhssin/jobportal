<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Contact form', 'flyfood' ),
	'description' => esc_html__( 'Build contact forms', 'flyfood' ),
	'tab'         => esc_html__( 'Content Elements', 'flyfood' ),
	'popup_size'  => 'large',
	'type'        => 'special'
);