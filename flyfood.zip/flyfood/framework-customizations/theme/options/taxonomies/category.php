<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$choices = ( fw()->extensions->get( 'slider' ) ) ? fw()->extensions->get( 'slider' )->get_populated_sliders_choices() : array();
$options = array(
	'blog_header_type' => array(
		'type'    => 'multi-picker',
		'label'   => false,
		'desc'    => false,
		'picker'  => array(
			'header_type' => array(
				'label'   => esc_html__( 'Header Type', 'flyfood' ),
				'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
				'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
				'type'    => 'radio',
				'value'   => 'none',
				'choices' => array(
					'none'   => esc_html__( 'None', 'flyfood' ),
					'image'  => esc_html__( 'Header Image', 'flyfood' ),
					'slider' => esc_html__( 'Header Slider', 'flyfood' )
				)
			),
		),
		'choices' => array(
			'image'  => array(
				'img'          => array(
					'type'  => 'upload',
					'value' => '',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
				),
				'before_title' => array(
					'type'  => 'text',
					'value' => '',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
				),
				'title'        => array(
					'type'  => 'text',
					'value' => '',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
				),
				'desc'         => array(
					'type'  => 'textarea',
					'value' => '',
					'label' => esc_html__( '', 'flyfood' ),
					'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
				),
			),
			'slider' => array(
				'slider_id' => array(
					'type'    => 'select',
					'value'   => '',
					'label'   => '',
					'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
					'choices' => $choices
				),
			)
		)
	)
);