<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$choices = ( fw()->extensions->get( 'slider' ) ) ? fw()->extensions->get( 'slider' )->get_populated_sliders_choices() : array();
$options = array(
	'main' => array(
		'title'    => false,
		'type'     => 'box',
		'priority' => 'high',
		'context'  => 'normal',
		'options'  => array(
			'types'    => array(
				'title'   => esc_html__( 'Post View Type', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'post_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'post_type' => array(
								'label'   => esc_html__( 'Post Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose post view type', 'flyfood' ),
								'type'    => 'select',
								'value'   => '',
								'choices' => array(
									'default' => esc_html__( 'Default', 'flyfood' ),
									'slider'  => esc_html__( 'Slider', 'flyfood' ),
									'video'   => esc_html__( 'Video', 'flyfood' ),
									'audio'   => esc_html__( 'Soundcloud Audio', 'flyfood' ),
									'link'    => esc_html__( 'Link', 'flyfood' ),
									'quote'   => esc_html__( 'Quote', 'flyfood' ),
								)
							),
						),
						'choices' => array(
							'slider' => array(
								'images' => array(
									'type'        => 'multi-upload',
									'value'       => '',
									'images_only' => true,
									'label'       => esc_html__( '', 'flyfood' ),
									'desc'        => esc_html__( 'Upload slider images.', 'flyfood' ),
								),
							),
							'video'  => array(
								'video' => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Add here the youtube, vimeo video link or a video iframe.', 'flyfood' ),
								),
							),
							'audio'  => array(
								'audio' => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Add here soundcloud iframe.', 'flyfood' ),
								),
							),
							'link'   => array(
								'link' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Add post external link.', 'flyfood' ),
								),
								'text' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Add post link text.', 'flyfood' ),
								),
							),
							'quote'  => array(
								'quote' => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Add post quote text.', 'flyfood' ),
								),
							),
						)
					)
				)
			),
			'settings' => array(
				'title'   => esc_html__( 'Header Settings', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'post_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'general',
								'choices' => array(
									'general' => esc_html__( 'General', 'flyfood' ),
									'none'    => esc_html__( 'None', 'flyfood' ),
									'image'   => esc_html__( 'Header Image', 'flyfood' ),
									'slider'  => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			),
		)
	)
);