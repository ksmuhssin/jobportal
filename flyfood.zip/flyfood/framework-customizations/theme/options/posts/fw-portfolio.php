<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$flyfood_template_directory = get_template_directory_uri();
$choices                    = ( fw()->extensions->get( 'slider' ) ) ? fw()->extensions->get( 'slider' )->get_populated_sliders_choices() : array();
$options                    = array(
	'main' => array(
		'title'    => false,
		'type'     => 'box',
		'priority' => 'high',
		'context'  => 'normal',
		'options'  => array(
			'meta'     => array(
				'title'   => esc_html__( 'Meta Settings', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'additional_info' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'selected' => array(
								'type'         => 'switch',
								'value'        => 'no',
								'label'        => esc_html__( 'Additional Info', 'flyfood' ),
								'desc'         => esc_html__( 'Enable the additional info?', 'flyfood' ),
								'left-choice'  => array(
									'value' => 'no',
									'label' => esc_html__( 'No', 'flyfood' ),
								),
								'right-choice' => array(
									'value' => 'yes',
									'label' => esc_html__( 'Yes', 'flyfood' ),
								),
							)
						),
						'choices' => array(
							'yes' => array(
								'client'          => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( 'Client', 'flyfood' ),
									'desc'  => esc_html__( 'Add the client.', 'flyfood' ),
								),
								'production_date' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( 'Date', 'flyfood' ),
									'desc'  => esc_html__( 'Add the production date.', 'flyfood' ),
								),
								'skills'          => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( 'Skills', 'flyfood' ),
									'desc'  => esc_html__( 'Add used skills.', 'flyfood' ),
								),
							)
						)
					)
				)
			),
			'masonry'  => array(
				'title'   => esc_html__( 'Masonry Settings', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'image_width'  => array(
						'label'   => esc_html__( 'Image Width', 'flyfood' ),
						'desc'    => esc_html__( "Select masonry post image width", 'flyfood' ),
						'value'   => 'default-width',
						'type'    => 'image-picker',
						'choices' => array(
							'default-width' => array(
								'small' => array(
									'height' => 70,
									'src'    => $flyfood_template_directory . '/images/image-picker/default-width.jpg'
								),
								'large' => array(
									'height' => 214,
									'src'    => $flyfood_template_directory . '/images/image-picker/default-width.jpg'
								),
							),
							'width2'        => array(
								'small' => array(
									'height' => 70,
									'src'    => $flyfood_template_directory . '/images/image-picker/width2.jpg'
								),
								'large' => array(
									'height' => 214,
									'src'    => $flyfood_template_directory . '/images/image-picker/width2.jpg'
								),
							),
						),
					),
					'image_height' => array(
						'label'   => esc_html__( 'Image Height', 'flyfood' ),
						'desc'    => esc_html__( "Select masonry post image height", 'flyfood' ),
						'value'   => 'default-height',
						'type'    => 'image-picker',
						'choices' => array(
							'default-height' => array(
								'small' => array(
									'height' => 70,
									'src'    => $flyfood_template_directory . '/images/image-picker/default-height.jpg'
								),
								'large' => array(
									'height' => 214,
									'src'    => $flyfood_template_directory . '/images/image-picker/default-height.jpg'
								),
							),
							'height2'        => array(
								'small' => array(
									'height' => 70,
									'src'    => $flyfood_template_directory . '/images/image-picker/height2.jpg'
								),
								'large' => array(
									'height' => 214,
									'src'    => $flyfood_template_directory . '/images/image-picker/height2.jpg'
								),
							),
							'height3'        => array(
								'small' => array(
									'height' => 70,
									'src'    => $flyfood_template_directory . '/images/image-picker/height3.jpg'
								),
								'large' => array(
									'height' => 214,
									'src'    => $flyfood_template_directory . '/images/image-picker/height3.jpg'
								),
							),
						),
					),
				)
			),
			'settings' => array(
				'title'   => esc_html__( 'Header Settings', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'post_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'general',
								'choices' => array(
									'general' => esc_html__( 'General', 'flyfood' ),
									'none'    => esc_html__( 'None', 'flyfood' ),
									'image'   => esc_html__( 'Header Image', 'flyfood' ),
									'slider'  => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			),
		)
	)
);