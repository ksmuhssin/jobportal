<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$choices = ( fw()->extensions->get( 'slider' ) ) ? fw()->extensions->get( 'slider' )->get_populated_sliders_choices() : array();

$options = array(
	'general'             => array(
		'title'   => esc_html__( 'General', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'general_options' => array(
				'title'   => esc_html__( 'General Tab Settings', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'general_box' => array(
						'title'   => esc_html__( 'General Settings', 'flyfood' ),
						'type'    => 'box',
						'options' => array(
							'logo_type'      => array(
								'type'    => 'multi-picker',
								'label'   => false,
								'desc'    => false,
								'picker'  => array(
									'selected' => array(
										'label'   => esc_html__( 'Logo Type', 'flyfood' ),
										'desc'    => esc_html__( 'Choose the logo type', 'flyfood' ),
										'type'    => 'short-select',
										'value'   => 'text',
										'choices' => array(
											'text'  => esc_html__( 'Text', 'flyfood' ),
											'image' => esc_html__( 'Image', 'flyfood' )
										)
									),
								),
								'choices' => array(
									'text'  => array(
										'logo_text' => array(
											'label' => esc_html__( 'Logo Text', 'flyfood' ),
											'desc'  => esc_html__( 'Enter logo text', 'flyfood' ),
											'value' => 'flyfood',
											'type'  => 'text'
										),
									),
									'image' => array(
										'logo'       => array(
											'label' => esc_html__( 'Logo', 'flyfood' ),
											'desc'  => esc_html__( 'Upload logo image', 'flyfood' ),
											'type'  => 'upload'
										),
										'logo_width' => array(
											'label' => esc_html__( 'Logo Width', 'flyfood' ),
											'desc'  => esc_html__( 'Enter the logo width in pixels. Ex: 144', 'flyfood' ),
											'type'  => 'short-text',
											'value' => '144'
										)
									),
								)
							),
							'header_type'    => array(
								'type'    => 'multi-picker',
								'label'   => false,
								'desc'    => false,
								'picker'  => array(
									'selected' => array(
										'type'    => 'short-select',
										'value'   => 'header-1',
										'attr'    => array(),
										'label'   => esc_html__( 'Header Type', 'flyfood' ),
										'desc'    => esc_html__( 'Select the header type', 'flyfood' ),
										'choices' => array(
											'header-1' => esc_html__( 'Header 1', 'flyfood' ),
											'header-2' => esc_html__( 'Header 2', 'flyfood' ),
										)
									),
								),
								'choices' => array()
							),
							'header_top_bar' => array(
								'type'    => 'multi-picker',
								'label'   => false,
								'desc'    => false,
								'picker'  => array(
									'selected' => array(
										'type'         => 'switch',
										'value'        => 'no',
										'attr'         => array(),
										'label'        => esc_html__( 'Header Top Bar', 'flyfood' ),
										'desc'         => esc_html__( 'Enable the header top bar?', 'flyfood' ),
										'left-choice'  => array(
											'value' => 'no',
											'label' => esc_html__( 'No', 'flyfood' ),
										),
										'right-choice' => array(
											'value' => 'yes',
											'label' => esc_html__( 'Yes', 'flyfood' ),
										),
									),
								),
								'choices' => array(
									'yes' => array(
										'enable_header_search' => array(
											'type'         => 'switch',
											'value'        => 'yes',
											'label'        => esc_html__( 'Header Search', 'flyfood' ),
											'desc'         => esc_html__( 'Enable header search?', 'flyfood' ),
											'left-choice'  => array(
												'value' => 'no',
												'label' => esc_html__( 'No', 'flyfood' ),
											),
											'right-choice' => array(
												'value' => 'yes',
												'label' => esc_html__( 'Yes', 'flyfood' ),
											),
										),
										'enable_header_rss'    => array(
											'type'         => 'switch',
											'value'        => 'yes',
											'label'        => esc_html__( 'Header RSS', 'flyfood' ),
											'desc'         => esc_html__( 'Enable header RSS?', 'flyfood' ),
											'left-choice'  => array(
												'value' => 'no',
												'label' => esc_html__( 'No', 'flyfood' ),
											),
											'right-choice' => array(
												'value' => 'yes',
												'label' => esc_html__( 'Yes', 'flyfood' ),
											),
										),
									),
								)
							),
						)
					),
				)
			),
			'social_options'  => array(
				'title'   => esc_html__( 'Social Profiles', 'flyfood' ),
				'type'    => 'tab',
				'options' => array(
					'social_box'   => array(
						'title'   => esc_html__( 'Social', 'flyfood' ),
						'type'    => 'box',
						'options' => array(
							'socials' => array(
								'type'          => 'addable-popup',
								'label'         => esc_html__( 'Social Links', 'flyfood' ),
								'desc'          => esc_html__( 'Add your social profiles', 'flyfood' ),
								'template'      => '{{=social_name}}',
								'popup-options' => array(
									'social_name' => array(
										'label' => esc_html__( 'Name', 'flyfood' ),
										'desc'  => esc_html__( 'Enter social name', 'flyfood' ),
										'type'  => 'text',
									),
									'social_icon' => array(
										'label' => esc_html__( 'Icon', 'flyfood' ),
										'desc'  => esc_html__( 'Select social icon', 'flyfood' ),
										'type'  => 'icon',
										'value' => 'fa fa-adn',
									),
									'social_link' => array(
										'label' => esc_html__( 'Link', 'flyfood' ),
										'desc'  => esc_html__( 'Enter your social URL link', 'flyfood' ),
										'type'  => 'text',
										'value' => '#',
									)
								),
							),
						)
					),
					'social_title' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'attr'         => array(),
						'label'        => esc_html__( 'Show Social Title', 'flyfood' ),
						'desc'         => esc_html__( 'Show social title in frontend?', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				)
			),

		)
	),
	'pages_settings'      => array(
		'title'   => esc_html__( 'Pages', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'page_header' => array(
				'title'   => esc_html__( 'Page Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'page_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'     => esc_html__( 'None', 'flyfood' ),
									'absolute' => esc_html__( 'Absolute', 'flyfood' ),
									'image'    => esc_html__( 'Header Image', 'flyfood' ),
									'slider'   => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			)
		)
	),
	'posts'               => array(
		'title'   => esc_html__( 'Blog Posts', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'posts_header'  => array(
				'title'   => esc_html__( 'Posts Header Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'post_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			),
			'post_settings' => array(
				'title'   => esc_html__( 'Blog Posts Settings', 'flyfood' ),
				'type'    => 'box',
				'attr'    => array( 'class' => 'prevent-auto-close' ),
				'options' => array(
					'posts_view_type'        => array(
						'type'    => 'short-select',
						'value'   => 'list',
						'label'   => esc_html__( 'Posts View Type', 'flyfood' ),
						'desc'    => esc_html__( 'Select the posts view type', 'flyfood' ),
						'choices' => array(
							'list' => esc_html__( 'List', 'flyfood' ),
							'grid' => esc_html__( 'Grid', 'flyfood' ),
						),
					),
					'enable_post_author'     => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Author', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts author.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_date'       => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Date', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts date.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					/*'enable_post_categories' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Categories', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts categories.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),*/
					'enable_post_share'      => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Share Buttons', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts share buttons.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_comments'   => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Comments', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts comments number.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_likes'      => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Likes', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts likes.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_categories' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Categories', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts categories.', 'flyfood' ),
						'help'         => esc_html__( 'Only in post details page.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_tags'       => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Tags', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts tags.', 'flyfood' ),
						'help'         => esc_html__( 'Only in post details page.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_author_box' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Author Box', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts author box.', 'flyfood' ),
						'help'         => esc_html__( 'Only in post details page.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_related_posts'   => array(
						'label'        => esc_html__( 'Related Posts', 'flyfood' ),
						'desc'         => esc_html__( 'Choose header type', 'flyfood' ),
						'help'         => esc_html__( 'Only in post details page.', 'flyfood' ),
						'type'         => 'switch',
						'value'        => 'yes',
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_post_pagination' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Pagination', 'flyfood' ),
						'desc'         => esc_html__( 'Enable posts pagination.', 'flyfood' ),
						'help'         => esc_html__( 'Only in post details page.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				)
			),
		)
	),
	'portfolio'           => array(
		'title'   => esc_html__( 'Portfolio Categories', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'portfolio_settings' => array(
				'title'   => esc_html__( 'Portfolio Categories Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'portfolio_posts_per_page' => array(
						'type'  => 'short-text',
						'value' => '12',
						'label' => esc_html__( 'Projects per page', 'flyfood' ),
						'desc'  => esc_html__( 'Enter the number of proects per page.', 'flyfood' ),
					),
					'filter'                   => array(
						'type'         => 'switch',
						'label'        => esc_html__( 'Top Filter', 'flyfood' ),
						'desc'         => esc_html__( 'Enable top filter?', 'flyfood' ),
						'value'        => 'yes',
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
					),
					'columns'                  => array(
						'label'   => esc_html__( 'Columns', 'flyfood' ),
						'desc'    => esc_html__( 'Choose the number of columns', 'flyfood' ),
						'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
						'type'    => 'radio',
						'value'   => '2',
						'choices' => array(
							'2'       => esc_html__( '2 Columns', 'flyfood' ),
							'3'       => esc_html__( '3 Columns', 'flyfood' ),
							'4'       => esc_html__( '4 Columns', 'flyfood' ),
							'masonry' => esc_html__( 'Masonry', 'flyfood' ),
						)
					),
				)
			),
		)
	),
	'portfolio_post'      => array(
		'title'   => esc_html__( 'Portfolio Posts', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'posts_header'       => array(
				'title'   => esc_html__( 'Portfolio Header Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'portfolio_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			),
			'portfolio_settings' => array(
				'title'   => esc_html__( 'Portfolio Posts Settings', 'flyfood' ),
				'type'    => 'box',
				'attr'    => array( 'class' => 'prevent-auto-close' ),
				'options' => array(
					'enable_portfolio_categories' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Categories', 'flyfood' ),
						'desc'         => esc_html__( 'Enable portfolio posts categories.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_portfolio_share'      => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Share Buttons', 'flyfood' ),
						'desc'         => esc_html__( 'Enable portfolio posts share buttons.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_portfolio_author_box' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Author Box', 'flyfood' ),
						'desc'         => esc_html__( 'Enable portfolio posts author box.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_portfolio_related'    => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Related Projects', 'flyfood' ),
						'desc'         => esc_html__( 'Enable portfolio related projects.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'enable_portfolio_pagination' => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Enable Pagination', 'flyfood' ),
						'desc'         => esc_html__( 'Enable portfolio posts pagination.', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				)
			),
		)
	),
	'homepage'            => array(
		'title'   => esc_html__( 'Home Page', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'homepage_header' => array(
				'title'   => esc_html__( 'Homepage Settings (Front page displays : Your latest posts)', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'homepage_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			)
		)
	),
	'blogpage'            => array(
		'title'   => esc_html__( 'Blog Page', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'homepage_header' => array(
				'title'   => esc_html__( 'Blog Page (When is selected a page as Blog Page)', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'blogpage_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			)
		)
	),
	'searchpage_settings' => array(
		'title'   => esc_html__( 'Search Page', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'search_header' => array(
				'title'   => esc_html__( 'Search Header Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'search_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			)
		)
	),
	'404_settings'        => array(
		'title'   => esc_html__( '404 Page', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'404_header' => array(
				'title'   => esc_html__( '404 Header Settings', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'404_header_type' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'header_type' => array(
								'label'   => esc_html__( 'Header Type', 'flyfood' ),
								'desc'    => esc_html__( 'Choose header type', 'flyfood' ),
								'attr'    => array( 'class' => 'fw-checkbox-float-left' ),
								'type'    => 'radio',
								'value'   => 'none',
								'choices' => array(
									'none'   => esc_html__( 'None', 'flyfood' ),
									'image'  => esc_html__( 'Header Image', 'flyfood' ),
									'slider' => esc_html__( 'Header Slider', 'flyfood' )
								)
							),
						),
						'choices' => array(
							'image'  => array(
								'img'          => array(
									'type'  => 'upload',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Upload header image.', 'flyfood' ),
								),
								'before_title' => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter before title.', 'flyfood' ),
								),
								'title'        => array(
									'type'  => 'text',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter title.', 'flyfood' ),
								),
								'desc'         => array(
									'type'  => 'textarea',
									'value' => '',
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter a short description.', 'flyfood' ),
								),
							),
							'slider' => array(
								'slider_id' => array(
									'type'    => 'select',
									'value'   => '',
									'label'   => '',
									'desc'    => esc_html__( 'Select header slider', 'flyfood' ),
									'choices' => $choices
								),
							)
						)
					)
				)
			)
		)
	),
	'footer'              => array(
		'title'   => esc_html__( 'Footer', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'footer_info' => array(
				'title'   => esc_html__( 'Footer Info', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'enable_footer_instagram' => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'selected' => array(
								'type'         => 'switch',
								'value'        => 'no',
								'label'        => esc_html__( 'Enable Instagram', 'flyfood' ),
								'desc'         => esc_html__( 'Enable instagram in footer?', 'flyfood' ),
								'left-choice'  => array(
									'value' => 'no',
									'label' => esc_html__( 'No', 'flyfood' ),
								),
								'right-choice' => array(
									'value' => 'yes',
									'label' => esc_html__( 'Yes', 'flyfood' ),
								),
							),
						),
						'choices' => array(
							'yes' => array(
								'username' => array(
									'label' => esc_html__( '', 'flyfood' ),
									'desc'  => esc_html__( 'Enter the instagram username (Ex flytemplates)', 'flyfood' ),
									'type'  => 'text',
									'value' => 'flytemplates'
								),
							)
						)
					),
					'enable_footer_logo'      => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'selected' => array(
								'type'         => 'switch',
								'value'        => 'no',
								'label'        => esc_html__( 'Enable Logo', 'flyfood' ),
								'desc'         => esc_html__( 'Enable footer logo?', 'flyfood' ),
								'left-choice'  => array(
									'value' => 'no',
									'label' => esc_html__( 'No', 'flyfood' ),
								),
								'right-choice' => array(
									'value' => 'yes',
									'label' => esc_html__( 'Yes', 'flyfood' ),
								),
							),
						),
						'choices' => array(
							'yes' => array(
								'logo'       => array(
									'label' => esc_html__( 'Logo', 'flyfood' ),
									'desc'  => esc_html__( 'Upload the logo image', 'flyfood' ),
									'type'  => 'upload',
								),
								'logo_width' => array(
									'label' => esc_html__( 'Logo Width', 'flyfood' ),
									'desc'  => esc_html__( 'Enter the logo width in pixels. Ex: 144', 'flyfood' ),
									'type'  => 'short-text',
									'value' => '144'
								),
							)
						)
					),
					'enable_footer_socials'   => array(
						'type'    => 'multi-picker',
						'label'   => false,
						'desc'    => false,
						'picker'  => array(
							'selected' => array(
								'type'         => 'switch',
								'value'        => 'yes',
								'label'        => esc_html__( 'Enable Socials', 'flyfood' ),
								'desc'         => esc_html__( 'Enable footer socials?', 'flyfood' ),
								'left-choice'  => array(
									'value' => 'no',
									'label' => esc_html__( 'No', 'flyfood' ),
								),
								'right-choice' => array(
									'value' => 'yes',
									'label' => esc_html__( 'Yes', 'flyfood' ),
								),
							),
						),
						'choices' => array()
					),
					'enable_go_to_top'        => array(
						'type'         => 'switch',
						'value'        => 'yes',
						'label'        => esc_html__( 'Go To Top', 'flyfood' ),
						'desc'         => esc_html__( 'Enable go to top button?', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
					'copyright'               => array(
						'label' => esc_html__( 'Copyright', 'flyfood' ),
						'desc'  => esc_html__( 'Footer Copyright', 'flyfood' ),
						'type'  => 'text',
					)
				)
			),
		)
	),
	'fonts'               => array(
		'title'   => esc_html__( 'Typography', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'site_color' => array(
				'type'  => 'color-picker',
				'value' => '',
				'label' => esc_html__( 'Color 1', 'flyfood' ),
				'desc'  => esc_html__( 'Choose the website color 1', 'flyfood' ),
			),
			'color_2'    => array(
				'type'  => 'color-picker',
				'value' => '',
				'label' => esc_html__( 'Color 2', 'flyfood' ),
				'desc'  => esc_html__( 'Choose the website color 2', 'flyfood' ),
			),
			'font1'      => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'font1' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Font 1', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom font 1', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'general_font_family' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'value' => array(
									'family' => 'Open Sans'
								),
							),
							'components' => array(
								'size'           => false,
								'line-height'    => false,
								'letter-spacing' => false,
								'color'          => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose theme font 1', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'font2'      => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'font2' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Font 2', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom font 2', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'general_font_family' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family' => 'Montserrat'
							),
							'components' => array(
								'size'           => false,
								'line-height'    => false,
								'letter-spacing' => false,
								'color'          => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose theme font 2', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'font3'      => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'font3' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Font 3', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom font 3', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'general_font_family' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family' => 'Muli'
							),
							'components' => array(
								'size'           => false,
								'line-height'    => false,
								'letter-spacing' => false,
								'color'          => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose theme font 3', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'font4'      => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'font4' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Font 4', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom font 4', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'general_font_family' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family' => 'Roboto Slab'
							),
							'components' => array(
								'size'           => false,
								'line-height'    => false,
								'letter-spacing' => false,
								'color'          => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose theme font 4', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'font5'      => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'font5' => array(
						'type'         => 'switch',
						'value'        => 'no',
						'attr'         => array(),
						'label'        => esc_html__( 'Font 5', 'flyfood' ),
						'desc'         => esc_html__( 'Enable custom font 5', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'general_font_family' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family' => 'Cookie'
							),
							'components' => array(
								'size'           => false,
								'line-height'    => false,
								'letter-spacing' => false,
								'color'          => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose theme font 5', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h1_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h1_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H1 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h1 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h1_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								//'weight' => 700,
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 24,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h1 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h2_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h2_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H2 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h2 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h2_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								//'weight' => 700,
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 21,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h2 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h3_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h3_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H3 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h3 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h3_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								//'weight' => 700,
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 20,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h3 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h4_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h4_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H4 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h4 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h4_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								//'weight' => 700,
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 16,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h4 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h5_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h5_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H5 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h5 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h5_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								//'weight' => 700,
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 14,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h5 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			),
			'h6_font'    => array(
				'type'    => 'multi-picker',
				'label'   => false,
				'desc'    => false,
				'picker'  => array(
					'h6_font' => array(
						'type'         => 'switch',
						'value'        => '',
						'attr'         => array(),
						'label'        => esc_html__( 'H6 Styles', 'flyfood' ),
						'desc'         => esc_html__( 'Enable h6 heading advanced styling', 'flyfood' ),
						'left-choice'  => array(
							'value' => 'no',
							'label' => esc_html__( 'No', 'flyfood' ),
						),
						'right-choice' => array(
							'value' => 'yes',
							'label' => esc_html__( 'Yes', 'flyfood' ),
						),
					),
				),
				'choices' => array(
					'yes' => array(
						'h6_font' => array(
							'type'       => 'typography-v2',
							'value'      => array(
								'family'         => 'Montserrat',
								'style'          => 'normal',
								'subset'         => 'latin',
								'variation'      => 'normal',
								'size'           => 13,
								'line-height'    => 1,
								'letter-spacing' => 0
							),
							'components' => array(
								'color' => false
							),
							'label'      => esc_html__( '', 'flyfood' ),
							'desc'       => esc_html__( 'Choose h6 heading styles', 'flyfood' )
						),
					),
					'no'  => array(),
				),
			)
		)
	),
	'tracking_script_tab' => array(
		'title'   => esc_html__( 'Tracking Script', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'script' => array(
				'title'   => esc_html__( 'Tracking', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'tracking_script' => array(
						'label' => esc_html__( 'Tracking Script', 'flyfood' ),
						'desc'  => esc_html__( 'Enter your tracking script code (google analytics, or other script)', 'flyfood' ),
						'type'  => 'textarea',
						'value' => ''
					),
				)
			)
		)
	),
	'custom_css_tab'      => array(
		'title'   => esc_html__( 'Custom CSS', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'styling' => array(
				'title'   => esc_html__( 'CSS', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'quick_css' => array(
						'label' => esc_html__( 'Custom CSS', 'flyfood' ),
						'desc'  => esc_html__( 'Enter your custom CSS styles', 'flyfood' ),
						'type'  => 'textarea',
						'value' => '',
					),
				)
			)
		)
	),
	'api_keys'            => array(
		'title'   => esc_html__( 'API Keys', 'flyfood' ),
		'type'    => 'tab',
		'options' => array(
			'api_keys_box' => array(
				'title'   => esc_html__( 'Google Maps', 'flyfood' ),
				'type'    => 'box',
				'options' => array(
					'gmap_key' => array(
						'label' => esc_html__( 'Google Maps', 'flyfood' ),
						'type'  => 'gmap-key',
						'desc'  => sprintf( esc_html__( 'Create an application in %sGoogle Console%s and add the API Key here.', 'flyfood' ), '<a target="_blank" href="https://console.developers.google.com/flows/enableapi?apiid=places_backend,maps_backend,geocoding_backend,directions_backend,distance_matrix_backend,elevation_backend&keyType=CLIENT_SIDE&reusekey=true">', '</a>' )
					),
				)
			),
		)
	),

);