<?php
/**
 * The default template for displaying post details
 */

$post_id                = get_the_ID();
$flyfood_post_view_type = ( defined( 'FW' ) ) ? fw_get_db_post_option( $post_id, 'post_type' ) : '';

$post_meta_options['enable_post_author']     = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_author' ) : 'yes';
$post_meta_options['enable_post_date']       = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_date' ) : 'yes';
$post_meta_options['enable_post_share']      = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_share' ) : 'no';
$post_meta_options['enable_post_comments']   = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_comments' ) : 'yes';
$post_meta_options['enable_post_likes']      = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_likes' ) : 'yes';
$post_meta_options['enable_related_posts']   = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_related_posts' ) : 'no';
$post_meta_options['enable_post_pagination'] = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_pagination' ) : 'yes';
$post_meta_options['enable_post_author_box'] = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_author_box' ) : 'yes';
$post_meta_options['enable_post_tags']       = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_tags' ) : 'yes';
$post_meta_options['enable_post_categories'] = ( defined( 'FW' ) ) ? fw_get_db_settings_option( 'enable_post_categories' ) : 'yes';
?>
	<!-- Post -->
	<article id="post-<?php the_ID(); ?>" class="article content-blog" itemscope itemtype="http://schema.org/Article">
		<div class="post-media">
			<?php if ( ! empty( $flyfood_post_view_type ) ) :
				flyfood_theme_get_post_view_type( $flyfood_post_view_type, $post_id );
			else :
				$image = wp_get_attachment_url( get_post_thumbnail_id( $post_id ), 'post-thumbnails' );
				flyfood_theme_show_default_post_image( $image, $post_id );
			endif; ?>
		</div>

		<h3 class="post-title" itemprop="name"><?php the_title(); ?></h3>

		<?php flyfood_theme_post_meta_1( $post_meta_options ); ?>

		<div class="post-content" itemprop="articleBody">
			<?php the_content();
			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'flyfood' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
			) ); ?>
		</div>

		<?php if ( $post_meta_options['enable_post_categories'] == 'yes' ) : ?>
			<?php esc_html_e( 'Categories:', 'flyfood' ); ?>
			<?php echo get_the_term_list( $post_id, 'category', '', ', ', '' ); ?>
		<?php endif; ?>

		<?php if ( $post_meta_options['enable_post_tags'] == 'yes' || $post_meta_options['enable_post_share'] == 'yes' ): ?>
			<div class="post-bottom clearfix">
				<?php if ( $post_meta_options['enable_post_tags'] == 'yes' ) : ?>
					<div class="post-taglist">
						<?php the_tags( '', ' ', '' ); ?>
					</div>
				<?php endif; ?>

				<div class="row">
					<?php if ( $post_meta_options['enable_post_share'] == 'yes' ) : ?>
						<div class="col-sm-6">
							<?php flyfood_theme_share_post(); ?>
						</div>
						<div class="col-sm-6">
							<?php flyfood_theme_post_meta_2( $post_meta_options ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endif; ?>
	</article>
	<!--/ Post -->

<?php if ( $post_meta_options['enable_post_author_box'] == 'yes' ) : ?>
	<?php get_template_part( 'content', 'author' ); ?>
<?php endif; ?>

<?php if ( $post_meta_options['enable_related_posts'] == 'yes' ) : ?>
	<?php get_template_part( 'related', 'posts' ); ?>
<?php endif; ?>

<?php if ( $post_meta_options['enable_post_pagination'] == 'yes' ) : ?>
	<div class="pager">
		<?php previous_post_link( '%link', '<i class="icon-arrow-left"></i>' . esc_html__( 'Previous Story', 'flyfood' ) . '<br /><span>%title</span>' ); ?>
		<?php next_post_link( '%link', esc_html__( 'Next Story', 'flyfood' ) . '<i class="icon-arrow-right"></i><br /><span>%title</span>' ); ?>
	</div>
<?php endif;