<?php
/**
 * The template for displaying Comments
 *
 * The area of the page that contains comments and the comment form.
 */

/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}

$flyfood_commenter = wp_get_current_commenter();
$flyfood_req       = get_option( 'require_name_email' );
$flyfood_aria_req  = ( $flyfood_req ? 'required' : '' );

if ( is_user_logged_in() ) {
	$flyfood_comment_field        = '<div class="form-group required"><label for="respondMessage">' . esc_html__( 'Comment', 'flyfood' ) . '</label><textarea class="form-control" id="respondMessage" name="comment" required></textarea></div>';
	$flyfood_textarea_field       = '';
	$flyfood_comment_notes_before = '';
	$flyfood_comment_notes_after  = '';
} else {
	$flyfood_comment_field        = '';
	$flyfood_comment_notes_before = '';
	$flyfood_comment_notes_after  = '';
	$flyfood_textarea_field       = '<div class="form-group required"><label for="respondMessage">' . esc_html__( 'message', 'flyfood' ) . '</label><textarea class="form-control" id="respondMessage" name="comment" required></textarea></div>';
}

$flyfood_args = array(
	'class_form'           => 'comment-form',
	'id_form'              => 'commentform',
	'id_submit'            => 'submit',
	'title_reply'          => esc_html__( 'Leave a Comment', 'flyfood' ),
	'title_reply_to'       => esc_html__( 'Leave Your Reply to %s', 'flyfood' ),
	'cancel_reply_link'    => esc_html__( 'Cancel Reply', 'flyfood' ),
	'label_submit'         => esc_html__( 'Post Comment', 'flyfood' ),
	'comment_field'        => $flyfood_comment_field,
	'comment_notes_before' => $flyfood_comment_notes_before,
	'comment_notes_after'  => $flyfood_comment_notes_after,
	'fields'               => apply_filters( 'comment_form_default_fields', array(
			'author'        => '<div class="row">
			 <div class="col-sm-4">
				 <div class="form-group required">
					 <label for="respondName">' . esc_html__( 'Name', 'flyfood' ) . '</label>
					 <input class="form-control" type="text" id="respondName" name="author" ' . $flyfood_aria_req . ' />
				 </div>
			 </div>',
			'email'         => '<div class="col-sm-4">
			<div class="form-group required">
				<label for="respondEmail">' . esc_html__( 'email', 'flyfood' ) . '</label>
				<input class="form-control" type="email" id="respondEmail" name="email" ' . $flyfood_aria_req . ' />
			</div>
		</div>',
			'url'           => '<div class="col-sm-4">
			<div class="form-group">
				<label for="respondWebsite">' . esc_html__( 'Website', 'flyfood' ) . '</label>
				<input class="form-control" type="url" id="url" name="respondWebsite" />
			</div>
		</div></div>',
			'comment_field' => $flyfood_textarea_field
		)
	)
);
?>
<!-- Comments -->
<section id="comments" class="comments">
	<?php if ( have_comments() ) : ?>
		<h4 class="title"><?php esc_html_e( 'Comments', 'flyfood' ); ?>
			(<?php comments_number( esc_html__( '0', 'flyfood' ), esc_html__( '1', 'flyfood' ), esc_html__( '%', 'flyfood' ) ); ?>
			)</h4>

		<ol class="comment-list">
			<?php get_template_part( 'comments', 'template' ); ?>
			<?php wp_list_comments( array( 'callback' => 'flyfood_theme_comment', 'style' => 'ol' ) ); ?>
		</ol>

		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
			<nav class="navigation paging-navigation" role="navigation">
				<div class="pagination loop-pagination">
					<?php
					$flyfood_args = array(
						'prev_text' => '<span> ' . esc_html__( 'PREV', 'flyfood' ) . '</span>',
						'next_text' => '<span>' . esc_html__( 'NEXT', 'flyfood' ) . '</span>',
					);
					paginate_comments_links( $flyfood_args ); ?>
				</div>
			</nav>
		<?php endif; // Check for comment navigation. ?>

		<?php if ( ! comments_open() ) : ?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'flyfood' ); ?></p>
		<?php endif; ?>

	<?php endif; // have_comments() ?>

	<?php comment_form( $flyfood_args ); ?>
</section>