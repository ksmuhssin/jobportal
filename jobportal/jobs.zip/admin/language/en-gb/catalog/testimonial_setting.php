<?php
// Heading
$_['heading_title']       = 'Testimonial Setting';

// Text
$_['text_success']      = 'Success: You have modified testmonials!';
$_['text_add']          = 'Add Testimonial Setting';


// Entry
$_['entry_bg_color']     = 'Country';



// Error
$_['error_permission']  = 'Warning: You do not have permission to modify Testmonials!';
$_['error_author']      = 'Author must be between 3 and 64 characters!';
$_['error_text']        = 'Testmonial text must be greater than  1 character!';
$_['error_rating']      = 'Review rating required!';
?>
