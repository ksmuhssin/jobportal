<?php
$_['text_dash']                     = 'Dashboard';
$_['text_blog']                    = 'Blogs';
$_['text_cate']                   = 'Category';
$_['text_comm']                    = 'Comment';
$_['text_sett']                    = 'Settings';
$_['text_addmodule']                    = 'Add Module';
