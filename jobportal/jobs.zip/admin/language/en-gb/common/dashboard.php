<?php
// Heading
$_['heading_title'] 	= 'Dashboard';
$_['heading_dashboard'] = 'Welcome To Job Portal';
$_['heading_job'] 		= 'Job Candidate';
$_['heading_available'] = 'Available Jobs';
$_['heading_resume'] 	= 'Company Profile';

// Text
$_['text_dashboard'] 	= 'Dashboard';

// Error
$_['error_install'] 	= 'Warning: Install folder still exists and should be deleted for security reasons!';