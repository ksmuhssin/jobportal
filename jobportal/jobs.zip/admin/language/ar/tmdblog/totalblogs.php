<?php
// Heading
$_['heading_title'] = '<b>مجموع المدونات</b>';

// Text
$_['text_view']     = 'عرض المزيد...';