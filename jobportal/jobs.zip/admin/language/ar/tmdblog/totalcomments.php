<?php
// Heading
$_['heading_title'] = '<b>مجموع التعليقات</b>';

// Text
$_['text_view'] = 'عرض المزيد...';