<?php
// Heading
$_['heading_title'] = '<b>مجموع فئات المدونة</b>';

// Text
$_['text_view']     = 'عرض المزيد...';