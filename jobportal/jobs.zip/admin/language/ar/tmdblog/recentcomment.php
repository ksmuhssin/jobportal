<?php
// Heading
$_['heading_title']                = 'احدث التعليقات';

// Column
$_['column_sr_no']  	 = 'الأب رقم.';
$_['column_post']  		 = 'بريد';
$_['column_author']      = 'مؤلف';
$_['column_status']     = 'الحالة';
$_['column_action']     = 'عمل';
