<?php
$_['text_dash']                     = 'لوحة القيادة';
$_['text_blog']                    = 'المدونات';
$_['text_cate']                   = 'الفئة';
$_['text_comm']                    = 'تعليق';
$_['text_sett']                    = 'الإعدادات';
$_['text_addmodule']                    = 'إضافة وحدة';
