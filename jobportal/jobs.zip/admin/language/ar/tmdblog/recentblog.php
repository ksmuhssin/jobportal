<?php
// Heading
$_['heading_title']      = 'المدونات الأخيرة';

// Column
$_['column_totalcoment'] = 'مجموع التعليقات';
$_['column_sr_no']  	 = 'معرف المدونة';
$_['column_post']  		 = 'مدونة';
$_['column_author']      = 'زبون';
$_['column_status']      = 'الحالة';
$_['column_action']      = 'عمل';

