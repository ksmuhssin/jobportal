<?php
// Heading
$_['heading_title']    = 'دعم &amp; استعادة';

// Text
$_['text_success']     = 'النجاح: لقد قمت باستيراد قاعدة البيانات الخاصة بك بنجاح!';

// Label
$_['label_import']     = 'استيراد';
$_['label_export']     = 'تصدير';

// Entry
$_['entry_import']     = 'استيراد';
$_['entry_export']     = 'تصدير';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن بتعديل النسخ الاحتياطي &amp; استعادة!';
$_['error_export']     = 'تحذير: يجب عليك تحديد جدول واحد على الأقل للتصدير!';
$_['error_empty']      = 'تحذير: الملف الذي قمت بتحميله فارغ!';