<?php
// Heading
$_['heading_title']	   = 'سجل الأخطاء';

// Text
$_['text_success']	   = 'النجاح: لقد قمت بمسح سجل الأخطاء بنجاح!';
$_['text_list']        = 'قائمة الأخطاء';

// Error
$_['error_warning']	   = 'تحذير: ملف سجل الأخطاء الخاص بك %s is %s!';
$_['error_permission'] = 'تحذير: ليس لديك إذن لمسح سجل الأخطاء!';