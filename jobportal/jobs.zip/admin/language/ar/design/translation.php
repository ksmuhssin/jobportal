<?php
// Heading
$_['heading_title']    = 'ترجمة لغوية';

// Text
$_['text_edit']        = 'تحرير الترجمة';
$_['text_list']        = 'قائمة الترجمة';
$_['text_translation'] = 'اختر ترجمة';
$_['text_translation'] = 'ترجمة';

// Column
$_['column_flag']      = 'علم';
$_['column_country']   = 'بلد';
$_['column_progress']  = 'تقدم الترجمة';
$_['column_action']    = 'عمل';

// button
$_['button_install']   = 'التثبت';
$_['button_uninstall'] = 'الغاء التثبيت';
$_['button_refresh']   = 'تحديث';

// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن بتعديل ترجمة اللغة!';
