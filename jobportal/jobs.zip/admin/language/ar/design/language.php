<?php
// Heading
$_['heading_title']    = 'محرر اللغة';
// Text
$_['text_success']     = 'النجاح: لديك تعديل محرر اللغة!';
$_['text_edit']        = 'تحرير الترجمة';
$_['text_default']     = 'افتراضي';
$_['text_store']       = 'متجر';
$_['text_language']    = 'لغة';
$_['text_translation'] = 'اختر ترجمة';
$_['text_translation'] = 'ترجمة';
// Entry
$_['entry_key']        = 'مفتاح';
$_['entry_value']      = 'القيمة';
$_['entry_default']    = 'افتراضي';
// Error
$_['error_permission'] = 'تحذير: ليس لديك إذن بتعديل محرر اللغة!';