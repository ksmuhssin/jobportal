<?php
// Heading
$_['heading_title']  = 'ملحقات';

// Text
$_['text_success']   = 'النجاح: لقد قمت بتعديل الامتدادات!';
$_['text_list']      = 'قائمة ملحق';
$_['text_type']      = 'اختر نوع التمديد';
$_['text_filter']    = 'منقي';
$_['text_analytics'] = 'تحليلات';
$_['text_captcha']   = 'كلمة التحقق';
$_['text_dashboard'] = 'لوحة القيادة';
$_['text_feed']      = 'يغذي';
$_['text_fraud']     = 'مكافحة الغش';
$_['text_module']    = 'وحدات';
$_['text_content']   = 'وحدات المحتوى';
$_['text_menu']      = 'وحدات القائمة';
$_['text_payment']   = 'المدفوعات';
$_['text_shipping']  = 'الشحن';
$_['text_theme']     = 'المواضيع';
$_['text_total']     = 'ترتيب المجاميع';