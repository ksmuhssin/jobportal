<?php
// Text
$_['text_footer']  = '<a href="http://themultimediadesigner.com/">Tmd</a> &copy; 2009-' . date('Y') . ' كل الحقوق محفوظة.';
$_['text_version'] = 'الإصدار %s';