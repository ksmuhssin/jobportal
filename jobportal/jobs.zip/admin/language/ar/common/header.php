<?php
// Heading
$_['heading_title']          = 'Jobportal';

// Text
$_['text_order']             = 'أوامر';
$_['text_processing_status'] = 'معالجة';
$_['text_complete_status']   = 'منجز';
$_['text_customer']          = 'الزبائن';
$_['text_online']            = 'العملاء عبر الإنترنت';
$_['text_approval']          = 'ما زال يحتاج بتصدير';
$_['text_product']           = 'منتجات';
$_['text_stock']             = 'إنتهى من المخزن';
$_['text_review']            = 'التعليقات';
$_['text_return']            = 'عائدات';
$_['text_affiliate']         = 'التابعون';
$_['text_store']             = 'مخازن';
$_['text_front']             = 'واجهة';
$_['text_help']              = 'مساعدة';
$_['text_homepage']          = 'Jobportal الصفحة الرئيسية';
$_['text_support']           = 'منتدى الدعم';
$_['text_documentation']     = 'كابل بيانات';
$_['text_logout']            = 'الخروج';
// Megaheader Starts
$_['text_megaheader1']       = 'ميجا رأس';
$_['text_megaheader']        = 'ميجا رأس';
// Megaheader Ends
//Testimonial
	$_['text_testimonial']   = 'شهادة';
//Testimonial