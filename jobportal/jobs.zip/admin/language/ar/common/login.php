<?php
// header
$_['heading_title']  = 'الادارة';

// Text
$_['text_heading']   = 'الادارة';
$_['text_login']     = 'يرجى إدخال تفاصيل تسجيل الدخول الخاصة بك.';
$_['text_forgotten'] = 'كلمة سر منسية';

// Entry
$_['entry_username'] = 'اسم المستخدم';
$_['entry_password'] = 'كلمه السر';

// Button
$_['button_login']   = 'تسجيل الدخول';

// Error
$_['error_login']    = 'لا تطابق لاسم المستخدم و / أو كلمة المرور.';
$_['error_token']    = 'جلسة رمزية غير صالحة.الرجاد الدخول على الحساب من جديد.'؛