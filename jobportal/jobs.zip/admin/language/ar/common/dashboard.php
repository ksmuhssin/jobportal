<?php
// Heading
$_['heading_title'] 	= 'لوحة القيادة';
$_['heading_dashboard'] = 'مرحبا بكم في بوابة الوظيفة';
$_['heading_job'] 		= 'مرشح لوظيفة';
$_['heading_available'] = 'اعمال متوفرة';
$_['heading_resume'] 	= 'ملف الشركة';

// Text
$_['text_dashboard'] 	= 'لوحة القيادة';

// Error
$_['error_install'] 	= 'تحذير: لا يزال مجلد التثبيت موجودًا ويجب حذفه لأسباب تتعلق بالأمان!';