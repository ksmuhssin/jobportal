<?php
// Heading
$_['heading_title']  		= 'تطبيق قائمة الوظائف';
$_['text_employname']  		= 'اسم الموظف';
$_['text_jobname']  		= 'اسم العمل';
$_['text_jobtype']  		= 'نوع الوظيفة';
$_['text_resume']  		    = 'استئناف تحميل';
$_['text_date']  		    = 'تاريخ';
$_['text_action']  		    = 'عمل';
$_['text_successdelete']    = 'بنجاح حذف قائمتك ';
$_['text_viewprofile']      = 'المرشح عرض الملف الشخصي';
