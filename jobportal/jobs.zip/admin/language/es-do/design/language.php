<?php
// Heading
$_['heading_title']    = 'Editor de lenguaje';
// Text
$_['text_success']     = 'Éxito: has modificado el editor de idiomas!';
$_['text_edit']        = 'Editar traducción';
$_['text_default']     = 'Defecto';
$_['text_store']       = 'Almacenar';
$_['text_language']    = 'Idioma';
$_['text_translation'] = 'Elija una traducción';
$_['text_translation'] = 'Traducciones';
// Entry
$_['entry_key']        = 'Llave';
$_['entry_value']      = 'Valor';
$_['entry_default']    = 'Defecto';
// Error
$_['error_permission'] = 'Advertencia: no tienes permiso para modificar el editor de idiomas!';