<?php
// Text
$_['text_subject']       = '%s - Actualización de devolución %s';
$_['text_return_id']     = 'ID de devolución:';
$_['text_date_added']    = 'Fecha de regreso:';
$_['text_return_status'] = 'Su devolución se ha actualizado al siguiente estado:';
$_['text_comment']       = 'Los comentarios para su devolución son:';
$_['text_footer']        = 'Responda a este correo electrónico si tiene alguna pregunta.';