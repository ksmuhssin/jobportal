<?php
// Text
$_['text_subject']  = '%s - Solicitud de restablecimiento de contraseña';
$_['text_greeting'] = 'Se solicitó una nueva contraseña para% s administration.';
$_['text_change']   = 'Para restablecer su contraseña, haga clic en el siguiente enlace:';
$_['text_ip']       = 'La IP utilizada para hacer esta solicitud era: %s';