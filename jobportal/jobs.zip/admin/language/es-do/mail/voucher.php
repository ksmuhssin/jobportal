<?php
// Text
$_['text_subject']  = 'Recibió un certificado de regalo de% s';
$_['text_greeting'] = 'Felicidades, has recibido un certificado de regalo por valor de% s';
$_['text_from']     = 'Este certificado de regalo ha sido enviado por% s';
$_['text_message']  = 'Con un mensaje que dice';
$_['text_redeem']   = 'Para canjear este Certificado de regalo, escriba el código de canje que es <b>% s </ b>, luego haga clic en el enlace a continuación y compre el producto en el que desea utilizar este certificado de regalo. Puede ingresar el código del certificado de regalo en la página del carrito de compras antes de hacer clic en Finalizar compra.';
$_['text_footer']   = 'Responda a este correo electrónico si tiene alguna pregunta.';
