<?php
// Text
$_['text_approve_subject']      = '%s - Su cuenta de afiliado ha sido activada!';
$_['text_approve_welcome']      = 'Bienvenido y gracias por registrarte en %s!';
$_['text_approve_login']        = 'Su cuenta ha sido creada y puede iniciar sesión usando su dirección de correo electrónico y contraseña visitando nuestro sitio web o en la siguiente URL:';
$_['text_approve_services']     = 'Al iniciar sesión, podrá generar códigos de seguimiento, realizar un seguimiento de los pagos de comisiones y editar la información de su cuenta.';
$_['text_approve_thanks']       = 'Gracias,';
$_['text_transaction_subject']  = '%s - Comisión afiliado';
$_['text_transaction_received'] = 'Has recibido% s comisión!';
$_['text_transaction_total']    = 'Su cantidad total de comisión es ahora% s.';