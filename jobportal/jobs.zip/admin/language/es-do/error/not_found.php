<?php
// Heading
$_['heading_title']  = 'Página no encontrada!';

// Text
$_['text_not_found'] = '¡La página que estás buscando no se pudo encontrar! Por favor, póngase en contacto con su administrador si el problema persiste.';