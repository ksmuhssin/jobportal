<?php
// Heading
$_['heading_title']   = 'Permiso denegado!';

// Text
$_['text_permission'] = 'No tiene permiso para acceder a esta página, consulte a su administrador de sistema.';