<?php
$_['text_dash']                   = 'Tablero';
$_['text_blog']                   = 'Blogs';
$_['text_cate']                   = 'Categoría';
$_['text_comm']                   = 'Comentario';
$_['text_sett']                   = 'Configuraciones';
$_['text_addmodule']              = 'Agregar módulo';
