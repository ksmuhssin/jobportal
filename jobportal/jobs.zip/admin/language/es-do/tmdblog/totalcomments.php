<?php
// Heading
$_['heading_title'] = '<b>Comentarios totales</b>';

// Text
$_['text_view']     = 'Ver más...';