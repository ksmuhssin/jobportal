<?php
// Heading
$_['heading_title']      = 'Comentarios Recientes';

// Column
$_['column_sr_no']  	 = 'No Señor.';
$_['column_post']  		 = 'Enviar';
$_['column_author']      = 'Autor';
$_['column_status']      = 'Estado';
$_['column_action']      = 'Acción';
