<?php
// Heading
$_['heading_title'] = '<b>Total Categorías de blog</b>';

// Text
$_['text_view']     = 'Ver más...';