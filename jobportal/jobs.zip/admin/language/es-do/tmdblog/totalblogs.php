<?php
// Heading
$_['heading_title'] = '<b>Total de blogs</b>';

// Text
$_['text_view']     = 'Ver más...';