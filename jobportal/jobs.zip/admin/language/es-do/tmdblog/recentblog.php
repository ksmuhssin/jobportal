<?php
// Heading
$_['heading_title']      = 'Blogs recientes';

// Column
$_['column_totalcoment'] = 'Comentario total';
$_['column_sr_no']  	 = 'ID del blog';
$_['column_post']  		 = 'Blog';
$_['column_author']      = 'Cliente';
$_['column_status']      = 'Estado';
$_['column_action']      = 'Acción';

