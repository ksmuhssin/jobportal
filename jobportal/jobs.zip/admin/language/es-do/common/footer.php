<?php
// Text
$_['text_footer']  = '<a href="http://themultimediadesigner.com/">Tmd</a> &copy; 2009-' . date('Y') . ' Todos los derechos reservados
.';
$_['text_version'] = 'Versión %s';