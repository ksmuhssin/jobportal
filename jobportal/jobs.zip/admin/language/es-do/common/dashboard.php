<?php
// Heading
$_['heading_title'] = 'Tablero';
$_['text_dashboard'] = 'Tablero';

// Error
$_['error_install'] = 'Advertencia: la carpeta de instalación todavía existe y debe eliminarse por razones de seguridad!';
$_['heading_dashboard'] = 'Bienvenido al portal de empleo';
$_['heading_job'] = 'Candidato laboral';
$_['heading_available'] = 'Trabajos disponibles';
$_['heading_resume'] = 'Perfil de la compañía';