<?php
// Heading
$_['heading_title']          = 'Portal de trabajo';

// Text
$_['text_order']             = 'Pedidos';
$_['text_processing_status'] = 'Tratamiento';
$_['text_complete_status']   = 'Terminado';
$_['text_customer']          = 'Clientes';
$_['text_online']            = 'Clientes en línea';
$_['text_approval']          = 'Aprobación pendiente';
$_['text_product']           = 'Productos';
$_['text_stock']             = 'Agotado';
$_['text_review']            = 'Comentarios';
$_['text_return']            = 'Devoluciones';
$_['text_affiliate']         = 'Afiliados';
$_['text_store']             = 'Víveres';
$_['text_front']             = 'Escaparate';
$_['text_help']              = 'Ayuda';
$_['text_homepage']          = 'Página de Jobportal';
$_['text_support']           = 'Foro de soporte';
$_['text_documentation']     = 'Documentación';
$_['text_logout']            = 'Cerrar sesión';
// Megaheader Starts
$_['text_megaheader1']              = 'Mega encabezado';
$_['text_megaheader']               = 'Mega encabezado';
// Megaheader Ends
//Testimonial
	$_['text_testimonial']                  = 'Testimonial';
//Testimonial