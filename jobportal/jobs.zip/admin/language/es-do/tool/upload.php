<?php
// Heading
$_['heading_title']     = 'Subidas';

// Text
$_['text_success']      = 'Éxito: ha modificado las cargas!';
$_['text_list']         = 'Lista de carga';

// Column
$_['column_name']       = 'Nombre de carga';
$_['column_filename']   = 'Nombre del archivo';
$_['column_date_added'] = 'Fecha Agregada';
$_['column_action']     = 'Acción';

// Entry
$_['entry_name']        = 'Nombre de carga';
$_['entry_filename']    = 'Nombre del archivo';
$_['entry_date_added'] 	= 'Fecha Agregada';

// Error
$_['error_permission']  = 'Advertencia: no tienes permiso para modificar cargas!';