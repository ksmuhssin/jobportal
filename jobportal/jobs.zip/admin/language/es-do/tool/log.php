<?php
// Heading
$_['heading_title']	   = 'Registro de errores';

// Text
$_['text_success']	   = 'Éxito: ha borrado correctamente su registro de errores!';
$_['text_list']        = 'Lista de errores';

// Error
$_['error_warning']	   = 'Advertencia: su archivo de registro de errores% s es% s!';
$_['error_permission'] = 'Advertencia: no tienes permiso para borrar el registro de errores!';