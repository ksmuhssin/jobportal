<?php
// Heading
$_['heading_title']  		= 'Aplicar lista de trabajos';
$_['text_employname']  		= 'Nombre de empleado';
$_['text_jobname']  		= 'Nombre del trabajo';
$_['text_jobtype']  		= 'Tipo de empleo';
$_['text_resume']  		    = 'Descarga hoja de vida';
$_['text_date']  		    = 'Fecha';
$_['text_action']  		    = 'Acción';
$_['text_successdelete']    = 'eliminar exitosamente su lista';
$_['text_viewprofile']      = 'Candidato Ver perfil';
