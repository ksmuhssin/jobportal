<?php
// Heading
$_['heading_title'] = 'Tablero';
$_['totaljob']      = 'Trabajo total';

// Error
$_['error_install'] = 'Advertencia: la carpeta de instalación todavía existe y debe eliminarse por razones de seguridad!';
?>