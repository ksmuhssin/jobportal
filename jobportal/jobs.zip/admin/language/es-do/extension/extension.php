<?php
// Heading
$_['heading_title']  = 'Extensiones';

// Text
$_['text_success']   = 'Éxito: ha modificado las extensiones!';
$_['text_list']      = 'Lista de extensiones';
$_['text_type']      = 'Elija el tipo de extensión';
$_['text_filter']    = 'Filtrar';
$_['text_analytics'] = 'Analítica';
$_['text_captcha']   = 'Captcha';
$_['text_dashboard'] = 'Tablero';
$_['text_feed']      = 'Feeds';
$_['text_fraud']     = 'Anti fraude';
$_['text_module']    = 'Módulos';
$_['text_content']   = 'Módulos de contenido';
$_['text_menu']      = 'Módulos de menú';
$_['text_payment']   = 'Pagos';
$_['text_shipping']  = 'Envío';
$_['text_theme']     = 'Temas';
$_['text_total']     = 'Totales de pedido';