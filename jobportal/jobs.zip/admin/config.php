<?php
// HTTP
define('HTTP_SERVER', 'http://oneteamjobs.com/admin/');
define('HTTP_CATALOG', 'http://oneteamjobs.com/');

// HTTPS
define('HTTPS_SERVER', 'http://oneteamjobs.com/admin/');
define('HTTPS_CATALOG', 'http://oneteamjobs.com/');

// DIR
define('DIR_APPLICATION','G:\PleskVhosts\oneteamjobs.com\httpdocs/admin/');
define('DIR_SYSTEM', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/');
define('DIR_IMAGE', 'G:/PleskVhosts/oneteamjobs.com/httpdocs/image/');
define('DIR_LANGUAGE','G:\PleskVhosts\oneteamjobs.com\httpdocs\admin/language/');
define('DIR_TEMPLATE', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\admin/view/template/');
define('DIR_CONFIG', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/config/');
define('DIR_CACHE', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/storage/cache/');
define('DIR_DOWNLOAD', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/storage/download/');
define('DIR_LOGS', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/storage/logs/');
define('DIR_MODIFICATION', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/storage/modification/');
define('DIR_UPLOAD', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\system/storage/upload/');
define('DIR_CATALOG', 'G:\PleskVhosts\oneteamjobs.com\httpdocs\catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', '182.50.133.85');
define('DB_USERNAME', 'jobportal2');
define('DB_PASSWORD', '#5oS6z6w');
define('DB_DATABASE', 'jobportal2');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');